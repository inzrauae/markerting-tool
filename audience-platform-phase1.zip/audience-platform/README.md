# Audience IQ: AI Audience Intelligence & Retargeting Platform

A multi-tenant SaaS **intelligence layer** that sits above Meta Pixel, Google Ads and Search Console:

**TRACK → UNDERSTAND → SCORE → SEGMENT → ACTIVATE → OPTIMIZE → CONVERT**

It is privacy-first by design: anonymous first-party behaviour, consent-gated processing, no fingerprinting, no sensitive-attribute inference. Ad platforms do their own identity matching.

## Status

| Phase | Scope | State |
|---|---|---|
| 1 | Foundation: auth, multi-tenancy (agency → client), roles & permissions, websites, API keys, audit log, retention policy, plans/limits, admin console, dashboard shell | **Built in this repo** |
| 2 | Tracking SDK, collection endpoint, visitors/sessions/events, consent | Designed ([ARCHITECTURE.md](docs/ARCHITECTURE.md), [TRACKING.md](docs/TRACKING.md)) |
| 3–10 | Analytics, audience engine, Google, Meta, AI, competitors, automation, billing/white label | Designed, see roadmap |

> **Before building on Phase 1, run the test suite.** The code was written in an environment that could not reach Packagist, so `composer install` and `php artisan test` were not executed there. See [Verification](#verification).

## Requirements

- PHP 8.3+ with `pdo_mysql`, `mbstring`, `intl`, `redis` (recommended), plus `pcntl` and `posix` for Horizon
- MySQL 8.0+
- Redis 6+
- Node.js 20+ (22 recommended)
- Composer 2

## Quick start (local)

```bash
cp .env.example .env              # then fill DB_* and REDIS_*
composer install
php artisan key:generate
php artisan migrate --seed         # creates tables + the 4 subscription plans
npm install && npm run build       # or `npm run dev` for hot reload
php artisan serve                  # http://localhost:8000
php artisan horizon                # queue workers (separate terminal)
```

Optional demo accounts (refuses to run in production):

```bash
php artisan db:seed --class=DemoSeeder
# agency@example.com / password   → agency admin of "Demo Agency" (2 clients)
# client@example.com / password   → client admin of "Lanka Builders"
```

Make yourself a platform super admin (only possible from the console):

```bash
php artisan aiq:super-admin you@example.com
```

Docker: `docker compose up -d --build` (see [DEPLOYMENT.md](docs/DEPLOYMENT.md)).

## Verification

```bash
composer install
php artisan test            # unit + feature suites (SQLite in-memory, no services needed)
./vendor/bin/pint --test    # code style
npm run build               # type-check + production build of the dashboard
```

The suite includes a **tenant-isolation matrix** (`tests/Feature/Tenancy/TenantIsolationTest.php`) that attacks every Phase 1 tenant route from another organization and asserts nothing leaks or changes. CI runs the same steps on every push (`.github/workflows/ci.yml`).

## Documentation

| Doc | Contents |
|---|---|
| [ARCHITECTURE.md](docs/ARCHITECTURE.md) | Repository analysis, system design, tenancy, modules, API design, security model, roadmap, external requirements, risks, blockers |
| [DATABASE.md](docs/DATABASE.md) | ERD, every table, indexes, partitioning & retention |
| [API.md](docs/API.md) | Phase 1 endpoints with examples |
| [TRACKING.md](docs/TRACKING.md) | Tracking SDK and collection design (Phase 2) |
| [META-INTEGRATION.md](docs/META-INTEGRATION.md) | Meta app, permissions, review, activation approach |
| [GOOGLE-INTEGRATION.md](docs/GOOGLE-INTEGRATION.md) | Google OAuth, Ads developer token, Search Console, remarketing lists |
| [AI.md](docs/AI.md) | Evidence-grounded AI design and anti-hallucination contract |
| [SECURITY.md](docs/SECURITY.md) | Controls, tenant isolation, secrets, reporting |
| [DEPLOYMENT.md](docs/DEPLOYMENT.md) | Docker, VPS, cPanel lite mode, workers, scheduler |
| [ENVIRONMENT.md](docs/ENVIRONMENT.md) | Every environment variable |
| [TROUBLESHOOTING.md](docs/TROUBLESHOOTING.md) | Common problems |

## Code map

```
app/
  Enums/                 OrganizationType, OrganizationRole (permission matrix), Permission
  Http/Controllers/Api/V1 Thin controllers (versioned API)
  Http/Middleware/       ResolveTenant, AuthenticateApiKey, EnsureClientOrganization, SecurityHeaders…
  Http/Requests/         Validation + authorization per endpoint
  Http/Resources/        API output (public ULIDs only, never internal ids or secrets)
  Models/Concerns/       BelongsToOrganization (fail-closed tenant scope), HasPublicId
  Policies/              Tenant-aware policies
  Services/              Tenancy (access, provisioning, membership), Audit, Billing limits
  Support/Tenancy/       TenantContext (scoped per request/job)
resources/js/            React + TypeScript dashboard (Vite, Tailwind)
tests/                   Unit + Feature (incl. tenant isolation)
docs/                    Architecture and operations docs
```
