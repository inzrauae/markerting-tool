<?php

declare(strict_types=1);

namespace App\Console\Commands;

use App\Models\User;
use App\Services\Audit\AuditLogger;
use Illuminate\Console\Command;

/**
 * The only way to grant platform super-admin rights (never via the API).
 */
class MakeSuperAdmin extends Command
{
    protected $signature = 'aiq:super-admin {email : E-mail of an existing user} {--revoke : Remove super-admin rights instead}';

    protected $description = 'Grant or revoke platform super-admin rights for a user';

    public function handle(AuditLogger $audit): int
    {
        $user = User::query()->where('email', strtolower((string) $this->argument('email')))->first();

        if ($user === null) {
            $this->error('No user with that e-mail. Register the account first.');

            return self::FAILURE;
        }

        $grant = ! $this->option('revoke');
        $user->forceFill(['is_super_admin' => $grant])->save();

        $audit->log($grant ? 'admin.super_admin_granted' : 'admin.super_admin_revoked', $user, ['email' => $user->email]);

        $this->info(($grant ? 'Granted' : 'Revoked')." super-admin rights for {$user->email}.");

        return self::SUCCESS;
    }
}
