<?php

declare(strict_types=1);

namespace App\Enums;

enum OrganizationRole: string
{
    case AgencyAdmin = 'agency_admin';
    case ClientAdmin = 'client_admin';
    case ClientUser = 'client_user';

    /**
     * @return list<Permission>
     */
    public function permissions(): array
    {
        return match ($this) {
            self::AgencyAdmin => Permission::cases(),
            self::ClientAdmin => array_values(array_filter(
                Permission::cases(),
                fn (Permission $p) => ! in_array($p, [Permission::ClientsManage, Permission::BillingManage], true),
            )),
            self::ClientUser => [
                Permission::OrganizationView,
                Permission::MembersView,
                Permission::WebsitesView,
                Permission::AudiencesView,
                Permission::ReportsView,
            ],
        };
    }

    public function can(Permission $permission): bool
    {
        return in_array($permission, $this->permissions(), true);
    }

    /**
     * Roles that can be held on an organization of the given type.
     *
     * @return list<self>
     */
    public static function assignableTo(OrganizationType $type): array
    {
        return match ($type) {
            OrganizationType::Agency => [self::AgencyAdmin],
            OrganizationType::Client => [self::ClientAdmin, self::ClientUser],
        };
    }

    /**
     * Whether a holder of $this may grant $role to someone else.
     * Nobody can grant a role more powerful than their own.
     */
    public function canGrant(self $role): bool
    {
        return $this->rank() >= $role->rank();
    }

    public function rank(): int
    {
        return match ($this) {
            self::AgencyAdmin => 3,
            self::ClientAdmin => 2,
            self::ClientUser => 1,
        };
    }
}
