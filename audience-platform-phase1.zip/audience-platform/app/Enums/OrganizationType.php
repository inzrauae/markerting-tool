<?php

declare(strict_types=1);

namespace App\Enums;

enum OrganizationType: string
{
    case Agency = 'agency';
    case Client = 'client';
}
