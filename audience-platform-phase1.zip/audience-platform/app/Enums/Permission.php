<?php

declare(strict_types=1);

namespace App\Enums;

/**
 * Fine-grained permissions. Roles map to sets of these in OrganizationRole.
 * Policies check permissions, never role names, so the matrix lives in one place.
 */
enum Permission: string
{
    case OrganizationView = 'organization.view';
    case OrganizationUpdate = 'organization.update';
    case MembersView = 'members.view';
    case MembersManage = 'members.manage';
    case ClientsManage = 'clients.manage';
    case WebsitesView = 'websites.view';
    case WebsitesManage = 'websites.manage';
    case ApiKeysManage = 'api_keys.manage';
    case AuditView = 'audit.view';
    case RetentionManage = 'retention.manage';
    case BillingManage = 'billing.manage';
    case IntegrationsManage = 'integrations.manage';
    case AudiencesView = 'audiences.view';
    case AudiencesManage = 'audiences.manage';
    case AudiencesActivate = 'audiences.activate';
    case ReportsView = 'reports.view';
    case ReportsManage = 'reports.manage';
}
