<?php

declare(strict_types=1);

namespace App\Exceptions;

use RuntimeException;

/**
 * Raised for tenant-context problems. Rendered as JSON with $status.
 */
class TenantException extends RuntimeException
{
    public function __construct(string $message, public readonly int $status = 403)
    {
        parent::__construct($message);
    }

    public static function missing(): self
    {
        return new self('Select an organization with the '.config('audience.tenancy.header').' header.', 400);
    }

    public static function forbidden(): self
    {
        return new self('You do not have access to this organization.', 403);
    }

    public static function clientRequired(): self
    {
        return new self('This resource belongs to a client organization. Select a client, not an agency.', 422);
    }

    public static function suspended(): self
    {
        return new self('This organization is suspended.', 403);
    }

    public static function mismatch(): self
    {
        return new self('Refusing to write a record that belongs to a different organization than the active tenant.', 500);
    }
}
