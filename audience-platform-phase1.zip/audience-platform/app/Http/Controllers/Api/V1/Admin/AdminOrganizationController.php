<?php

declare(strict_types=1);

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Http\Resources\OrganizationResource;
use App\Models\Organization;
use App\Services\Audit\AuditLogger;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;

/**
 * Super-admin console: every organization on the platform.
 */
class AdminOrganizationController extends Controller
{
    public function index(Request $request): AnonymousResourceCollection
    {
        $request->validate([
            'type' => ['sometimes', 'in:agency,client'],
            'status' => ['sometimes', 'in:active,suspended'],
            'search' => ['sometimes', 'string', 'max:100'],
        ]);

        $organizations = Organization::query()
            ->with('parent')
            ->when($request->filled('type'), fn ($q) => $q->where('type', $request->string('type')->toString()))
            ->when($request->filled('status'), fn ($q) => $q->where('status', $request->string('status')->toString()))
            ->when($request->filled('search'), fn ($q) => $q->where('name', 'like', '%'.addcslashes((string) $request->string('search'), '%_\\').'%'))
            ->orderByDesc('id')
            ->cursorPaginate(100);

        return OrganizationResource::collection($organizations);
    }

    /**
     * Suspending an agency also blocks its clients (checked at tenant resolution).
     */
    public function updateStatus(Request $request, Organization $organization, AuditLogger $audit): OrganizationResource
    {
        $data = $request->validate([
            'status' => ['required', 'in:active,suspended'],
            'reason' => ['required', 'string', 'max:500'],
        ]);

        $before = $organization->status;
        $organization->update(['status' => $data['status']]);

        if ($organization->isAgency()) {
            Organization::query()->where('parent_id', $organization->getKey())->update(['status' => $data['status']]);
        }

        $audit->log('admin.organization_status_changed', $organization, [
            'from' => $before,
            'to' => $data['status'],
            'reason' => $data['reason'],
        ], $organization);

        return OrganizationResource::make($organization->load('parent'));
    }
}
