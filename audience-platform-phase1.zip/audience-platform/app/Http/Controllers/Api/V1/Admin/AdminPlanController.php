<?php

declare(strict_types=1);

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Models\SubscriptionPlan;
use App\Services\Audit\AuditLogger;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

/**
 * Plans are edited as data. Limits: integer or null (unlimited).
 * Prices: {"LKR": {"month": 9900, "year": 99000}, ...} in minor units.
 */
class AdminPlanController extends Controller
{
    public const METRICS = [
        'websites', 'clients', 'users', 'monthly_visitors', 'monthly_events',
        'connected_platforms', 'ai_analyses', 'audience_activations', 'reports',
    ];

    public function index(): JsonResponse
    {
        return response()->json([
            'data' => SubscriptionPlan::query()->orderBy('sort_order')->get(),
            'metrics' => self::METRICS,
        ]);
    }

    public function update(Request $request, SubscriptionPlan $plan, AuditLogger $audit): JsonResponse
    {
        $rules = [
            'name' => ['sometimes', 'string', 'max:80'],
            'is_active' => ['sometimes', 'boolean'],
            'limits' => ['sometimes', 'array'],
            'prices' => ['sometimes', 'nullable', 'array'],
            'prices.*' => ['array'],
            'prices.*.*' => ['integer', 'min:0'],
            'features' => ['sometimes', 'nullable', 'array'],
            'sort_order' => ['sometimes', 'integer', 'min:0'],
        ];

        foreach (self::METRICS as $metric) {
            $rules["limits.{$metric}"] = ['sometimes', 'nullable', 'integer', 'min:0'];
        }

        $data = $request->validate($rules);

        if (isset($data['limits'])) {
            $data['limits'] = array_intersect_key($data['limits'], array_flip(self::METRICS)) + ($plan->limits ?? []);
        }

        $before = $plan->only(array_keys($data));
        $plan->update($data);

        $audit->log('admin.plan_updated', $plan, ['before' => $before, 'after' => $data]);

        return response()->json(['data' => $plan->fresh()]);
    }
}
