<?php

declare(strict_types=1);

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Requests\ApiKeys\StoreApiKeyRequest;
use App\Http\Resources\ApiKeyResource;
use App\Models\ApiKey;
use App\Services\Audit\AuditLogger;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;
use Illuminate\Http\Response;

class ApiKeyController extends Controller
{
    public function __construct(private readonly AuditLogger $audit) {}

    public function index(Request $request): AnonymousResourceCollection
    {
        $this->authorize('viewAny', ApiKey::class);

        $keys = ApiKey::query()
            ->when(! $request->boolean('include_revoked'), fn ($q) => $q->whereNull('revoked_at'))
            ->latest('id')
            ->cursorPaginate(100);

        return ApiKeyResource::collection($keys);
    }

    /**
     * The plaintext key is returned exactly once, in this response.
     */
    public function store(StoreApiKeyRequest $request): JsonResponse
    {
        $data = $request->validated();

        [$key, $plaintext] = ApiKey::generate([
            'name' => $data['name'],
            'abilities' => array_values($data['abilities']),
            'allowed_ips' => $data['allowed_ips'] ?? null,
            'expires_at' => $data['expires_at'] ?? null,
            'created_by' => $request->user()->getKey(),
        ]);
        $key->save();

        $this->audit->log('api_key.created', $key, [
            'name' => $key->name,
            'prefix' => $key->prefix,
            'abilities' => $key->abilities,
        ]);

        return response()->json([
            'data' => ApiKeyResource::make($key),
            'key' => $plaintext,
            'notice' => 'Store this key now. It cannot be shown again.',
        ], 201);
    }

    public function destroy(ApiKey $apiKey): Response
    {
        $this->authorize('delete', $apiKey);

        if ($apiKey->revoked_at === null) {
            $apiKey->forceFill(['revoked_at' => now()])->save();
            $this->audit->log('api_key.revoked', $apiKey, ['prefix' => $apiKey->prefix]);
        }

        return response()->noContent();
    }
}
