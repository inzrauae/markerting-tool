<?php

declare(strict_types=1);

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\ApiKey;
use App\Models\Organization;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

/**
 * GET /api/v1/key — lets an integration verify its key and see what it can do.
 */
class ApiKeyIntrospectionController extends Controller
{
    public function __invoke(Request $request): JsonResponse
    {
        /** @var ApiKey $key */
        $key = $request->attributes->get('api_key');
        /** @var Organization $organization */
        $organization = $request->attributes->get('organization');

        return response()->json([
            'key' => [
                'id' => $key->public_id,
                'name' => $key->name,
                'prefix' => $key->prefix,
                'abilities' => $key->abilities,
                'expires_at' => $key->expires_at?->toIso8601String(),
            ],
            'organization' => [
                'id' => $organization->public_id,
                'name' => $organization->name,
                'type' => $organization->type->value,
            ],
        ]);
    }
}
