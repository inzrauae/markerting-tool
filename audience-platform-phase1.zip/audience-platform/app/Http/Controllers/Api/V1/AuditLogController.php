<?php

declare(strict_types=1);

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Resources\AuditLogResource;
use App\Models\AuditLog;
use App\Models\Organization;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;

class AuditLogController extends Controller
{
    /**
     * An agency's log includes its clients' entries; a client's log is its own.
     */
    public function index(Request $request, Organization $organization): AnonymousResourceCollection
    {
        $this->authorize('viewAudit', $organization);

        $request->validate([
            'action' => ['sometimes', 'string', 'max:100'],
            'from' => ['sometimes', 'date'],
            'to' => ['sometimes', 'date', 'after_or_equal:from'],
        ]);

        $organizationIds = $organization->isAgency()
            ? Organization::query()
                ->where('id', $organization->getKey())
                ->orWhere('parent_id', $organization->getKey())
                ->pluck('id')
            : collect([$organization->getKey()]);

        $logs = AuditLog::query()
            ->with('actorUser')
            ->whereIn('organization_id', $organizationIds)
            ->when($request->filled('action'), fn ($q) => $q->where('action', 'like', addcslashes((string) $request->string('action'), '%_\\').'%'))
            ->when($request->filled('from'), fn ($q) => $q->where('created_at', '>=', $request->date('from')))
            ->when($request->filled('to'), fn ($q) => $q->where('created_at', '<=', $request->date('to')->endOfDay()))
            ->orderByDesc('id')
            ->cursorPaginate(100);

        return AuditLogResource::collection($logs);
    }
}
