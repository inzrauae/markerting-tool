<?php

declare(strict_types=1);

namespace App\Http\Controllers\Api\V1\Auth;

use App\Enums\OrganizationRole;
use App\Http\Controllers\Controller;
use App\Http\Requests\Auth\RegisterRequest;
use App\Http\Resources\OrganizationResource;
use App\Http\Resources\UserResource;
use App\Models\User;
use App\Services\Tenancy\OrganizationProvisioner;
use Illuminate\Auth\Events\Registered;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class RegisterController extends Controller
{
    public function __invoke(RegisterRequest $request, OrganizationProvisioner $provisioner): JsonResponse
    {
        $data = $request->validated();

        [$user, $result] = DB::transaction(function () use ($data, $provisioner): array {
            $user = User::query()->create([
                'name' => $data['name'],
                'email' => $data['email'],
                'password' => $data['password'],
            ]);

            $result = $provisioner->registerAccount(
                $user,
                $data['organization_name'],
                $data['account_type'] === 'agency',
                array_filter([
                    'timezone' => $data['timezone'] ?? null,
                    'currency' => $data['currency'] ?? null,
                ]),
            );

            return [$user, $result];
        });

        event(new Registered($user));

        // First-party SPA requests carry a session; log them straight in.
        if ($request->hasSession()) {
            Auth::guard('web')->login($user);
            $request->session()->regenerate();
        }

        $organizations = collect([$result['agency'], $result['client']])->filter()->values();

        return response()->json([
            'user' => UserResource::make($user),
            'organizations' => $organizations->map(
                fn ($org) => OrganizationResource::make($org)->withRole(OrganizationRole::AgencyAdmin)
            ),
            // The organization to select first: the client for a business, the agency otherwise.
            'default_organization_id' => ($result['client'] ?? $result['agency'])->public_id,
        ], 201);
    }
}
