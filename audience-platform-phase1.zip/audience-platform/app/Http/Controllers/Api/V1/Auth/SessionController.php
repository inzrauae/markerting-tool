<?php

declare(strict_types=1);

namespace App\Http\Controllers\Api\V1\Auth;

use App\Http\Controllers\Controller;
use App\Http\Requests\Auth\LoginRequest;
use App\Http\Resources\UserResource;
use App\Models\User;
use App\Services\Audit\AuditLogger;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\ValidationException;

/**
 * Cookie-session login for the first-party dashboard SPA (Sanctum stateful).
 * The SPA must first GET /sanctum/csrf-cookie.
 */
class SessionController extends Controller
{
    public function store(LoginRequest $request, AuditLogger $audit): JsonResponse
    {
        if (! $request->hasSession()) {
            throw ValidationException::withMessages([
                'email' => 'Session login is only available to the dashboard. API clients should use POST /api/v1/auth/tokens.',
            ]);
        }

        $credentials = $request->only('email', 'password');

        if (! Auth::guard('web')->attempt($credentials)) {
            $audit->log('auth.login_failed', null, ['email' => $credentials['email']]);

            throw ValidationException::withMessages(['email' => __('auth.failed')]);
        }

        $request->session()->regenerate();

        /** @var User $user */
        $user = Auth::guard('web')->user();
        $user->forceFill(['last_login_at' => now()])->save();
        $audit->log('auth.login', $user, null, null, $user);

        return response()->json(['user' => UserResource::make($user)]);
    }

    public function destroy(Request $request, AuditLogger $audit): Response
    {
        $user = $request->user();

        if ($user instanceof User) {
            $audit->log('auth.logout', $user, null, null, $user);
        }

        Auth::guard('web')->logout();

        if ($request->hasSession()) {
            $request->session()->invalidate();
            $request->session()->regenerateToken();
        }

        return response()->noContent();
    }
}
