<?php

declare(strict_types=1);

namespace App\Http\Controllers\Api\V1\Auth;

use App\Http\Controllers\Controller;
use App\Http\Requests\Auth\LoginRequest;
use App\Http\Resources\UserResource;
use App\Models\User;
use App\Services\Audit\AuditLogger;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\ValidationException;
use Laravel\Sanctum\PersonalAccessToken;

/**
 * Personal bearer tokens for scripts/mobile clients acting as a user.
 * Server-to-server integrations should use organization API keys instead.
 */
class TokenController extends Controller
{
    public function store(LoginRequest $request, AuditLogger $audit): JsonResponse
    {
        $user = User::query()->where('email', $request->validated('email'))->first();

        if ($user === null || ! Hash::check((string) $request->validated('password'), $user->password)) {
            $audit->log('auth.token_failed', null, ['email' => $request->validated('email')]);

            throw ValidationException::withMessages(['email' => __('auth.failed')]);
        }

        $token = $user->createToken(
            $request->validated('device_name', 'api'),
            ['*'],
            now()->addDays(30),
        );

        $user->forceFill(['last_login_at' => now()])->save();
        $audit->log('auth.token_issued', $user, ['name' => $token->accessToken->name], null, $user);

        return response()->json([
            'token' => $token->plainTextToken,
            'token_type' => 'Bearer',
            'expires_at' => $token->accessToken->expires_at?->toIso8601String(),
            'user' => UserResource::make($user),
        ], 201);
    }

    /**
     * Revoke the bearer token used for this request.
     */
    public function destroy(Request $request, AuditLogger $audit): Response
    {
        /** @var User $user */
        $user = $request->user();
        $token = $user->currentAccessToken();

        if ($token instanceof PersonalAccessToken) {
            $token->delete();
            $audit->log('auth.token_revoked', $user, null, null, $user);
        }

        return response()->noContent();
    }
}
