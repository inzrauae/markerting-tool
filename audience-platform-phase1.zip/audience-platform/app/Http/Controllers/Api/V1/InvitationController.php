<?php

declare(strict_types=1);

namespace App\Http\Controllers\Api\V1;

use App\Enums\OrganizationRole;
use App\Http\Controllers\Controller;
use App\Http\Requests\Members\AcceptInvitationRequest;
use App\Http\Requests\Members\InviteMemberRequest;
use App\Http\Resources\InvitationResource;
use App\Http\Resources\OrganizationResource;
use App\Models\Organization;
use App\Models\OrganizationInvitation;
use App\Models\User;
use App\Services\Audit\AuditLogger;
use App\Services\Tenancy\MembershipService;
use App\Services\Tenancy\OrganizationAccess;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;
use Illuminate\Http\Response;

class InvitationController extends Controller
{
    public function __construct(private readonly MembershipService $members) {}

    public function index(Request $request, Organization $organization): AnonymousResourceCollection
    {
        $this->authorize('manageMembers', $organization);

        // Tenant scope already limits this to $organization (route-selected tenant).
        $invitations = OrganizationInvitation::query()
            ->whereNull('accepted_at')
            ->whereNull('revoked_at')
            ->where('expires_at', '>', now())
            ->latest('id')
            ->cursorPaginate(100);

        return InvitationResource::collection($invitations);
    }

    public function store(InviteMemberRequest $request, Organization $organization): JsonResponse
    {
        $invitation = $this->members->invite(
            $organization,
            $request->validated('email'),
            OrganizationRole::from($request->validated('role')),
            $request->user(),
        );

        return InvitationResource::make($invitation)->response()->setStatusCode(201);
    }

    public function destroy(Organization $organization, OrganizationInvitation $invitation, AuditLogger $audit): Response
    {
        $this->authorize('manageMembers', $organization);

        if ($invitation->isPending()) {
            $invitation->forceFill(['revoked_at' => now()])->save();
            $audit->log('member.invitation_revoked', $invitation, ['email' => $invitation->email], $organization);
        }

        return response()->noContent();
    }

    /**
     * Public endpoint (rate limited). A signed-in user accepts with their own
     * account; otherwise name + password create one.
     */
    public function accept(AcceptInvitationRequest $request, OrganizationAccess $access): JsonResponse
    {
        $current = $request->user('sanctum');

        $membership = $this->members->accept(
            $request->validated('token'),
            $current instanceof User ? $current : null,
            $request->safe()->only(['name', 'password']),
        );

        $organization = Organization::query()->findOrFail($membership->organization_id);
        $user = User::query()->findOrFail($membership->user_id);

        return response()->json([
            'organization' => OrganizationResource::make($organization)->withRole($access->roleFor($user, $organization)),
            'account_created' => $current === null,
        ], 201);
    }
}
