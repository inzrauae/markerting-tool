<?php

declare(strict_types=1);

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Resources\OrganizationResource;
use App\Http\Resources\UserResource;
use App\Models\Organization;
use App\Models\User;
use App\Services\Tenancy\OrganizationAccess;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class MeController extends Controller
{
    public function __invoke(Request $request, OrganizationAccess $access): JsonResponse
    {
        /** @var User $user */
        $user = $request->user();

        // Super admins can reach every org, but the switcher lists only what
        // they reach through memberships; the admin console lists the rest.
        $query = $access->membershipOrganizations($user);

        $organizations = $query->with('parent')->orderBy('type')->orderBy('name')->limit(500)->get();
        $roles = $access->rolesFor($user, $organizations);

        return response()->json([
            'user' => UserResource::make($user),
            'organizations' => $organizations->map(
                fn (Organization $org) => OrganizationResource::make($org)->withRole($roles[$org->getKey()] ?? null)
            ),
        ]);
    }
}
