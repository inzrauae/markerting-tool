<?php

declare(strict_types=1);

namespace App\Http\Controllers\Api\V1;

use App\Enums\OrganizationRole;
use App\Http\Controllers\Controller;
use App\Http\Requests\Members\UpdateMemberRequest;
use App\Http\Resources\MemberResource;
use App\Models\Organization;
use App\Models\OrganizationMembership;
use App\Models\User;
use App\Services\Tenancy\MembershipService;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;
use Illuminate\Http\Response;

class MemberController extends Controller
{
    public function __construct(private readonly MembershipService $members) {}

    public function index(Request $request, Organization $organization): AnonymousResourceCollection
    {
        $this->authorize('viewMembers', $organization);

        $memberships = OrganizationMembership::query()
            ->with('user')
            ->where('organization_id', $organization->getKey())
            ->orderBy('id')
            ->cursorPaginate(100);

        return MemberResource::collection($memberships);
    }

    public function update(UpdateMemberRequest $request, Organization $organization, User $member): MemberResource
    {
        $membership = $this->members->changeRole(
            $organization,
            $member,
            OrganizationRole::from($request->validated('role')),
            $request->user(),
        );

        return MemberResource::make($membership->load('user'));
    }

    public function destroy(Request $request, Organization $organization, User $member): Response
    {
        $this->authorize('manageMembers', $organization);

        $this->members->remove($organization, $member, $request->user());

        return response()->noContent();
    }
}
