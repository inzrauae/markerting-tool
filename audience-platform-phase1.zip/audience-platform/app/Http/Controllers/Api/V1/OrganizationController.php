<?php

declare(strict_types=1);

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Requests\Organizations\StoreClientRequest;
use App\Http\Requests\Organizations\UpdateOrganizationRequest;
use App\Http\Resources\OrganizationResource;
use App\Models\Organization;
use App\Models\User;
use App\Services\Audit\AuditLogger;
use App\Services\Tenancy\OrganizationAccess;
use App\Services\Tenancy\OrganizationProvisioner;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;

class OrganizationController extends Controller
{
    public function __construct(private readonly OrganizationAccess $access) {}

    /**
     * Organizations the user can select (memberships + agency clients).
     */
    public function index(Request $request): AnonymousResourceCollection
    {
        /** @var User $user */
        $user = $request->user();

        $request->validate([
            'type' => ['sometimes', 'in:agency,client'],
            'search' => ['sometimes', 'string', 'max:100'],
        ]);

        $paginator = $this->access->membershipOrganizations($user)
            ->with('parent')
            ->when($request->filled('type'), fn ($q) => $q->where('type', $request->string('type')->toString()))
            ->when($request->filled('search'), fn ($q) => $q->where('name', 'like', '%'.addcslashes((string) $request->string('search'), '%_\\').'%'))
            ->orderBy('name')
            ->orderBy('id')
            ->cursorPaginate(50);

        $roles = $this->access->rolesFor($user, $paginator->items());
        $paginator->through(fn (Organization $org) => OrganizationResource::make($org)->withRole($roles[$org->getKey()] ?? null));

        return OrganizationResource::collection($paginator);
    }

    public function show(Request $request, Organization $organization): OrganizationResource
    {
        $this->authorize('view', $organization);

        return OrganizationResource::make($organization->load('parent'))
            ->withRole($this->access->roleFor($request->user(), $organization));
    }

    public function update(UpdateOrganizationRequest $request, Organization $organization, AuditLogger $audit): OrganizationResource
    {
        $before = $organization->only(array_keys($request->validated()));
        $organization->update($request->validated());

        $audit->log('organization.updated', $organization, ['before' => $before, 'after' => $request->validated()]);

        return OrganizationResource::make($organization->load('parent'))
            ->withRole($this->access->roleFor($request->user(), $organization));
    }

    /**
     * Agency admins create a client organization under their agency.
     */
    public function storeClient(StoreClientRequest $request, Organization $organization, OrganizationProvisioner $provisioner): JsonResponse
    {
        $data = $request->validated();
        $client = $provisioner->createClient($organization, $data['name'], $data);

        return OrganizationResource::make($client->load('parent'))
            ->withRole($this->access->roleFor($request->user(), $client))
            ->response()
            ->setStatusCode(201);
    }
}
