<?php

declare(strict_types=1);

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Requests\Privacy\UpdateRetentionPolicyRequest;
use App\Http\Resources\RetentionPolicyResource;
use App\Models\DataRetentionPolicy;
use App\Services\Audit\AuditLogger;
use App\Support\Tenancy\TenantContext;

class RetentionPolicyController extends Controller
{
    public function __construct(private readonly TenantContext $tenant) {}

    public function show(): RetentionPolicyResource
    {
        $this->authorize('viewRetention', $this->tenant->get());

        return RetentionPolicyResource::make($this->current());
    }

    public function update(UpdateRetentionPolicyRequest $request, AuditLogger $audit): RetentionPolicyResource
    {
        $policy = $this->current();
        $before = $policy->only(array_keys($request->validated()));

        $policy->fill($request->validated());
        $policy->updated_by = $request->user()->getKey();
        $policy->save();

        $audit->log('retention_policy.updated', $policy, ['before' => $before, 'after' => $request->validated()]);

        return RetentionPolicyResource::make($policy);
    }

    private function current(): DataRetentionPolicy
    {
        return DataRetentionPolicy::query()->firstOrCreate([], DataRetentionPolicy::defaults());
    }
}
