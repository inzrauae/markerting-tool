<?php

declare(strict_types=1);

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Requests\Websites\StoreWebsiteRequest;
use App\Http\Requests\Websites\UpdateWebsiteRequest;
use App\Http\Resources\WebsiteResource;
use App\Models\TrackingDomain;
use App\Models\Website;
use App\Services\Audit\AuditLogger;
use App\Services\Billing\PlanLimits;
use App\Support\Tenancy\TenantContext;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\DB;

class WebsiteController extends Controller
{
    public function __construct(
        private readonly AuditLogger $audit,
        private readonly TenantContext $tenant,
    ) {}

    public function index(Request $request): AnonymousResourceCollection
    {
        $this->authorize('viewAny', Website::class);

        $request->validate(['status' => ['sometimes', 'in:pending,active,paused']]);

        $websites = Website::query()
            ->with('trackingDomains')
            ->when($request->filled('status'), fn ($q) => $q->where('status', $request->string('status')->toString()))
            ->orderBy('name')
            ->orderBy('id')
            ->cursorPaginate(50);

        return WebsiteResource::collection($websites);
    }

    public function store(StoreWebsiteRequest $request, PlanLimits $limits): JsonResponse
    {
        $limits->assertCanAdd($this->tenant->get(), PlanLimits::WEBSITES, 'primary_domain');

        $data = $request->validated();

        $website = DB::transaction(function () use ($data): Website {
            $website = Website::query()->create([
                'name' => $data['name'],
                'primary_domain' => $data['primary_domain'],
                'timezone' => $data['timezone'] ?? $this->tenant->get()->timezone,
                'status' => Website::STATUS_PENDING,
                'settings' => [
                    'bot_filtering' => true,
                    'respect_do_not_track' => false,
                    'consent_mode' => 'require_for_ads',
                ],
            ]);

            $this->syncDomains($website, $data['additional_domains'] ?? []);

            return $website;
        });

        $this->audit->log('website.created', $website, ['name' => $website->name, 'domain' => $website->primary_domain]);

        return WebsiteResource::make($website->load('trackingDomains'))->response()->setStatusCode(201);
    }

    public function show(Website $website): WebsiteResource
    {
        $this->authorize('view', $website);

        return WebsiteResource::make($website->load('trackingDomains'));
    }

    public function update(UpdateWebsiteRequest $request, Website $website): WebsiteResource
    {
        $data = $request->validated();

        DB::transaction(function () use ($website, $data): void {
            $website->update(collect($data)->only(['name', 'status', 'timezone'])->all());

            if (array_key_exists('additional_domains', $data)) {
                $this->syncDomains($website, $data['additional_domains']);
            }
        });

        $this->audit->log('website.updated', $website, $data);

        return WebsiteResource::make($website->load('trackingDomains'));
    }

    public function destroy(Website $website): Response
    {
        $this->authorize('delete', $website);

        $website->delete();
        $this->audit->log('website.deleted', $website, ['domain' => $website->primary_domain]);

        return response()->noContent();
    }

    /**
     * Issue a new site key. The old snippet stops working immediately, so the
     * UI must make the consequence clear before calling this.
     */
    public function rotateKey(Website $website): WebsiteResource
    {
        $this->authorize('rotateKey', $website);

        $website->forceFill(['site_key' => Website::generateSiteKey()])->save();
        $this->audit->log('website.site_key_rotated', $website);

        return WebsiteResource::make($website->load('trackingDomains'));
    }

    /**
     * The primary domain is always allowed; additional domains replace the
     * previous set.
     *
     * @param  list<string>  $additional
     */
    private function syncDomains(Website $website, array $additional): void
    {
        $domains = collect([$website->primary_domain, ...$additional])
            ->filter()
            ->map(fn (string $d) => strtolower($d))
            ->unique()
            ->values();

        $website->trackingDomains()->whereNotIn('domain', $domains)->delete();

        foreach ($domains as $domain) {
            TrackingDomain::query()->firstOrCreate(
                ['website_id' => $website->getKey(), 'domain' => $domain],
                ['include_subdomains' => true],
            );
        }
    }
}
