<?php

declare(strict_types=1);

namespace App\Http\Middleware;

use App\Exceptions\TenantException;
use App\Models\ApiKey;
use App\Models\Organization;
use App\Support\Tenancy\TenantContext;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

/**
 * Authenticates server-to-server requests with an organization API key and
 * pins the tenant to the key's organization. Usage: `api_key:events:write`.
 */
class AuthenticateApiKey
{
    public function __construct(private readonly TenantContext $context) {}

    public function handle(Request $request, Closure $next, string ...$abilities): Response
    {
        $presented = (string) $request->bearerToken();
        $prefix = ApiKey::prefixFrom($presented);

        $key = $prefix === null ? null : ApiKey::withoutTenancy()->where('prefix', $prefix)->first();

        // hash_equals keeps the comparison constant-time.
        if ($key === null || ! hash_equals($key->key_hash, ApiKey::hash($presented)) || ! $key->isUsable()) {
            return $this->deny('Invalid or revoked API key.', 401);
        }

        if (! $key->allowsIp($request->ip())) {
            return $this->deny('This API key is not allowed from your IP address.', 403);
        }

        foreach ($abilities as $ability) {
            if (! $key->can($ability)) {
                return $this->deny("This API key lacks the \"{$ability}\" ability.", 403);
            }
        }

        $organization = Organization::query()->find($key->organization_id);

        if ($organization === null) {
            return $this->deny('Invalid or revoked API key.', 401);
        }

        if (! $organization->isActive()) {
            throw TenantException::suspended();
        }

        $this->context->set($organization);
        $request->attributes->set('organization', $organization);
        $request->attributes->set('api_key', $key);

        // Throttle the "last used" write to once a minute per key.
        if ($key->last_used_at === null || $key->last_used_at->lt(now()->subMinute())) {
            ApiKey::withoutTenancy()->whereKey($key->getKey())->update(['last_used_at' => now()]);
        }

        return $next($request);
    }

    private function deny(string $message, int $status): Response
    {
        return response()->json(['message' => $message], $status);
    }
}
