<?php

declare(strict_types=1);

namespace App\Http\Middleware;

use App\Support\Tenancy\TenantContext;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

/**
 * Global middleware: every request starts with no tenant, so a tenant can
 * never leak from a previous request handled by the same process
 * (long-running workers, Octane, or the test client).
 */
class ClearTenantContext
{
    public function __construct(private readonly TenantContext $context) {}

    public function handle(Request $request, Closure $next): Response
    {
        $this->context->clear();

        try {
            return $next($request);
        } finally {
            $this->context->clear();
        }
    }
}
