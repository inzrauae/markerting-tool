<?php

declare(strict_types=1);

namespace App\Http\Middleware;

use App\Exceptions\TenantException;
use App\Support\Tenancy\TenantContext;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

/**
 * Tracking data (websites, visitors, audiences...) is owned by client
 * organizations. Agency admins must select one of their clients.
 */
class EnsureClientOrganization
{
    public function __construct(private readonly TenantContext $context) {}

    public function handle(Request $request, Closure $next): Response
    {
        $organization = $this->context->get();

        if ($organization === null) {
            throw TenantException::missing();
        }

        if (! $organization->isClient()) {
            throw TenantException::clientRequired();
        }

        return $next($request);
    }
}
