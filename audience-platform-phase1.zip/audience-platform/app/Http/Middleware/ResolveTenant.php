<?php

declare(strict_types=1);

namespace App\Http\Middleware;

use App\Exceptions\TenantException;
use App\Models\Organization;
use App\Models\User;
use App\Services\Audit\AuditLogger;
use App\Services\Tenancy\OrganizationAccess;
use App\Support\Tenancy\TenantContext;
use Closure;
use Illuminate\Auth\AuthenticationException;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

/**
 * Selects the active tenant for an authenticated user.
 *
 * Source, in order: the {organization} route parameter, then the
 * X-Organization-Id header (organization public_id). The user must be able
 * to access that organization (OrganizationAccess) or the request is refused.
 *
 * Runs before SubstituteBindings (see bootstrap/app.php) so tenant-scoped
 * route-model bindings resolve inside the tenant.
 */
class ResolveTenant
{
    public function __construct(
        private readonly TenantContext $context,
        private readonly OrganizationAccess $access,
        private readonly AuditLogger $audit,
    ) {}

    public function handle(Request $request, Closure $next): Response
    {
        $user = $request->user();

        if (! $user instanceof User) {
            throw new AuthenticationException;
        }

        $publicId = $this->requestedOrganizationId($request);

        if ($publicId === null || $publicId === '') {
            throw TenantException::missing();
        }

        $organization = Organization::query()->where('public_id', $publicId)->first();

        if ($organization === null || ! $this->access->canAccess($user, $organization)) {
            throw TenantException::forbidden();
        }

        if (! $organization->isActive() && ! $user->isSuperAdmin()) {
            throw TenantException::suspended();
        }

        $this->context->set($organization);
        $request->attributes->set('organization', $organization);

        if ($user->isSuperAdmin() && ! $this->access->isMember($user, $organization)) {
            $this->audit->log('admin.tenant_accessed', $organization, [
                'method' => $request->method(),
                'path' => $request->path(),
            ], $organization, $user);
        }

        return $next($request);
    }

    private function requestedOrganizationId(Request $request): ?string
    {
        $fromRoute = $request->route('organization');

        if ($fromRoute instanceof Organization) {
            return $fromRoute->public_id;
        }

        if (is_string($fromRoute) && $fromRoute !== '') {
            return $fromRoute;
        }

        $header = $request->header((string) config('audience.tenancy.header'));

        return is_string($header) ? trim($header) : null;
    }
}
