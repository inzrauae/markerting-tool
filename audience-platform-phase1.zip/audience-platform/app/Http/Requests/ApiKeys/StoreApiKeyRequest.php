<?php

declare(strict_types=1);

namespace App\Http\Requests\ApiKeys;

use App\Models\ApiKey;
use App\Rules\IpOrCidr;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class StoreApiKeyRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user()->can('create', ApiKey::class);
    }

    /**
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        return [
            'name' => ['required', 'string', 'max:120'],
            'abilities' => ['required', 'array', 'min:1'],
            'abilities.*' => ['string', 'distinct', Rule::in(config('audience.api_keys.abilities'))],
            'allowed_ips' => ['sometimes', 'nullable', 'array', 'max:50'],
            'allowed_ips.*' => ['string', new IpOrCidr],
            'expires_at' => ['sometimes', 'nullable', 'date', 'after:now'],
        ];
    }
}
