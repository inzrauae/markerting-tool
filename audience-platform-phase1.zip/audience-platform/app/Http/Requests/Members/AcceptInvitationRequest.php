<?php

declare(strict_types=1);

namespace App\Http\Requests\Members;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rules\Password;

class AcceptInvitationRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Name/password are only needed when the invitee has no account yet;
     * MembershipService enforces that.
     *
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        return [
            'token' => ['required', 'string', 'size:48'],
            'name' => ['sometimes', 'string', 'max:120'],
            'password' => ['sometimes', 'confirmed', Password::defaults()],
        ];
    }
}
