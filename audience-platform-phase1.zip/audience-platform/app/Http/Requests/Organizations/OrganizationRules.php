<?php

declare(strict_types=1);

namespace App\Http\Requests\Organizations;

/**
 * Validation fragments shared by organization requests.
 */
final class OrganizationRules
{
    /**
     * Ad-platform restricted categories. When set, the activation flow warns
     * that custom-audience retargeting may be limited.
     */
    public const SPECIAL_AD_CATEGORIES = ['housing', 'employment', 'credit', 'financial_products', 'social_issues'];

    /**
     * @return array<string, mixed>
     */
    public static function profile(bool $partial): array
    {
        $required = $partial ? 'sometimes' : 'required';

        return [
            'name' => [$required, 'string', 'max:160'],
            'timezone' => ['sometimes', 'timezone:all'],
            'currency' => ['sometimes', 'string', 'size:3', 'alpha'],
            'special_ad_category' => ['sometimes', 'nullable', 'in:'.implode(',', self::SPECIAL_AD_CATEGORIES)],
        ];
    }
}
