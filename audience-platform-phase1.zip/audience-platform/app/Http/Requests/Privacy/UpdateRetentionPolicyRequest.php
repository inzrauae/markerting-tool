<?php

declare(strict_types=1);

namespace App\Http\Requests\Privacy;

use App\Support\Tenancy\TenantContext;
use Illuminate\Foundation\Http\FormRequest;

class UpdateRetentionPolicyRequest extends FormRequest
{
    public function authorize(): bool
    {
        $organization = app(TenantContext::class)->get();

        return $organization !== null && $this->user()->can('manageRetention', $organization);
    }

    /**
     * 30 / 90 / 180 / 365 are offered in the UI; any value in range is a
     * "custom" policy.
     *
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        $min = (int) config('audience.retention.min_days');
        $max = (int) config('audience.retention.max_days');

        return [
            'raw_event_days' => ['required', 'integer', "between:{$min},{$max}"],
            'visitor_profile_days' => ['required', 'integer', "between:{$min},{$max}"],
            'aggregate_days' => ['present', 'nullable', 'integer', "between:{$min},{$max}"],
            'anonymize_instead_of_delete' => ['required', 'boolean'],
        ];
    }
}
