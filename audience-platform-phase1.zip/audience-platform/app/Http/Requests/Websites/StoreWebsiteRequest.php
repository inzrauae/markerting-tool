<?php

declare(strict_types=1);

namespace App\Http\Requests\Websites;

use App\Models\Website;
use App\Support\Domain;
use App\Support\Tenancy\TenantContext;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class StoreWebsiteRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user()->can('create', Website::class);
    }

    /**
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        return [
            'name' => ['required', 'string', 'max:160'],
            'primary_domain' => [
                'required', 'string', 'max:253',
                // Includes soft-deleted websites, matching the DB unique index
                // (a deleted site's historical data still references the domain).
                Rule::unique('websites', 'primary_domain')
                    ->where('organization_id', app(TenantContext::class)->id()),
            ],
            'timezone' => ['sometimes', 'timezone:all'],
            'additional_domains' => ['sometimes', 'array', 'max:20'],
            'additional_domains.*' => ['string', 'max:253', 'distinct'],
        ];
    }

    /**
     * Normalise hostnames before validation so "https://Example.com/" and
     * "example.com" are treated as the same domain.
     */
    protected function prepareForValidation(): void
    {
        $merge = [];

        if ($this->has('primary_domain')) {
            $merge['primary_domain'] = Domain::normalize((string) $this->input('primary_domain')) ?? '';
        }

        if (is_array($this->input('additional_domains'))) {
            $merge['additional_domains'] = array_map(
                fn ($d) => Domain::normalize(is_string($d) ? $d : null) ?? '',
                $this->input('additional_domains'),
            );
        }

        $this->merge($merge);
    }

    /**
     * @return array<string, string>
     */
    public function messages(): array
    {
        return [
            'primary_domain.required' => 'Enter a valid domain, for example example.com.',
            'primary_domain.unique' => 'This organization already has (or recently deleted) a website with that domain.',
            'additional_domains.*.string' => 'Each additional domain must be a valid hostname.',
        ];
    }

    public function withValidator($validator): void
    {
        $validator->after(function ($validator): void {
            foreach ((array) $this->input('additional_domains', []) as $i => $domain) {
                if ($domain === '') {
                    $validator->errors()->add("additional_domains.{$i}", 'Each additional domain must be a valid hostname.');
                }
            }
        });
    }
}
