<?php

declare(strict_types=1);

namespace App\Http\Requests\Websites;

use App\Models\Website;
use App\Support\Domain;
use Illuminate\Foundation\Http\FormRequest;

class UpdateWebsiteRequest extends FormRequest
{
    public function authorize(): bool
    {
        /** @var Website $website */
        $website = $this->route('website');

        return $this->user()->can('update', $website);
    }

    /**
     * The primary domain is immutable (it anchors historical data); add the
     * new hostname as an additional domain or create a new website instead.
     *
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        return [
            'name' => ['sometimes', 'string', 'max:160'],
            // "pending" is system-managed (until the first event arrives).
            'status' => ['sometimes', 'in:active,paused'],
            'timezone' => ['sometimes', 'timezone:all'],
            'additional_domains' => ['sometimes', 'array', 'max:20'],
            'additional_domains.*' => ['string', 'max:253', 'distinct'],
        ];
    }

    protected function prepareForValidation(): void
    {
        if (is_array($this->input('additional_domains'))) {
            $this->merge([
                'additional_domains' => array_map(
                    fn ($d) => Domain::normalize(is_string($d) ? $d : null) ?? '',
                    $this->input('additional_domains'),
                ),
            ]);
        }
    }

    public function withValidator($validator): void
    {
        $validator->after(function ($validator): void {
            foreach ((array) $this->input('additional_domains', []) as $i => $domain) {
                if ($domain === '') {
                    $validator->errors()->add("additional_domains.{$i}", 'Each additional domain must be a valid hostname.');
                }
            }
        });
    }
}
