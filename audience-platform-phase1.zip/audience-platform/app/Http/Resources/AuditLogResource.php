<?php

declare(strict_types=1);

namespace App\Http\Resources;

use App\Models\AuditLog;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

/** @mixin AuditLog */
class AuditLogResource extends JsonResource
{
    /**
     * Internal numeric IDs of subjects are not exposed; the action and
     * redacted change set carry the meaning.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'action' => $this->action,
            'actor_type' => $this->actor_type,
            'actor' => $this->when(
                $this->actor_type === 'user' && $this->relationLoaded('actorUser'),
                fn () => $this->actorUser ? ['id' => $this->actorUser->public_id, 'name' => $this->actorUser->name] : null,
            ),
            'subject_type' => $this->subject_type,
            'changes' => $this->changes,
            'ip_address' => $this->ip_address,
            'created_at' => $this->created_at?->toIso8601String(),
        ];
    }
}
