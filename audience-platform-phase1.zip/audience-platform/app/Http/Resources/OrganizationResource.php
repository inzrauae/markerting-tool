<?php

declare(strict_types=1);

namespace App\Http\Resources;

use App\Enums\OrganizationRole;
use App\Models\Organization;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

/** @mixin Organization */
class OrganizationResource extends JsonResource
{
    private ?OrganizationRole $role = null;

    /**
     * Include the requesting user's effective role on this organization.
     */
    public function withRole(?OrganizationRole $role): static
    {
        $this->role = $role;

        return $this;
    }

    /**
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->public_id,
            'type' => $this->type->value,
            'name' => $this->name,
            'slug' => $this->slug,
            'status' => $this->status,
            'timezone' => $this->timezone,
            'currency' => $this->currency,
            'special_ad_category' => $this->special_ad_category,
            'parent_id' => $this->whenLoaded('parent', fn () => $this->parent?->public_id),
            'role' => $this->role?->value,
            'permissions' => $this->role
                ? array_map(fn ($p) => $p->value, $this->role->permissions())
                : null,
            'created_at' => $this->created_at?->toIso8601String(),
        ];
    }
}
