<?php

declare(strict_types=1);

namespace App\Http\Resources;

use App\Models\DataRetentionPolicy;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

/** @mixin DataRetentionPolicy */
class RetentionPolicyResource extends JsonResource
{
    /**
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'raw_event_days' => $this->raw_event_days,
            'visitor_profile_days' => $this->visitor_profile_days,
            'aggregate_days' => $this->aggregate_days,
            'anonymize_instead_of_delete' => $this->anonymize_instead_of_delete,
            'choices' => config('audience.retention.choices'),
            'updated_at' => $this->updated_at?->toIso8601String(),
        ];
    }
}
