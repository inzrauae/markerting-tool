<?php

declare(strict_types=1);

namespace App\Http\Resources;

use App\Models\TrackingDomain;
use App\Models\Website;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

/** @mixin Website */
class WebsiteResource extends JsonResource
{
    /**
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->public_id,
            'name' => $this->name,
            'primary_domain' => $this->primary_domain,
            'site_key' => $this->site_key,
            'status' => $this->status,
            'timezone' => $this->timezone,
            'tracking_domains' => $this->whenLoaded('trackingDomains', fn () => $this->trackingDomains
                ->map(fn (TrackingDomain $d) => [
                    'domain' => $d->domain,
                    'include_subdomains' => $d->include_subdomains,
                ])->values()),
            'tracking_snippet' => $this->trackingSnippet(),
            'last_event_at' => $this->last_event_at?->toIso8601String(),
            'created_at' => $this->created_at?->toIso8601String(),
            'updated_at' => $this->updated_at?->toIso8601String(),
        ];
    }
}
