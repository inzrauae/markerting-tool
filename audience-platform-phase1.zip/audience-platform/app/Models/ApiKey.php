<?php

declare(strict_types=1);

namespace App\Models;

use App\Models\Concerns\BelongsToOrganization;
use App\Models\Concerns\HasPublicId;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Support\Str;

/**
 * Server-to-server credential pinned to one organization.
 *
 * Format: {prefix}{8 char id}_{40 char secret}, e.g. aiq_live_ab12cd34_xxxxxxxx...
 * Only SHA-256(full key) is stored.
 *
 * @property int $id
 * @property string $public_id
 * @property int $organization_id
 * @property string $name
 * @property string $prefix
 * @property string $key_hash
 * @property array<int, string> $abilities
 * @property array<int, string>|null $allowed_ips
 */
class ApiKey extends Model
{
    use BelongsToOrganization, HasPublicId;

    protected $fillable = ['organization_id', 'created_by', 'name', 'abilities', 'allowed_ips', 'expires_at'];

    protected $hidden = ['key_hash'];

    protected function casts(): array
    {
        return [
            'abilities' => 'array',
            'allowed_ips' => 'array',
            'last_used_at' => 'datetime',
            'expires_at' => 'datetime',
            'revoked_at' => 'datetime',
        ];
    }

    /**
     * Generate a new key. Returns [model (unsaved key fields set), plaintext].
     *
     * @return array{0: self, 1: string}
     */
    public static function generate(array $attributes): array
    {
        $id = Str::lower(Str::random(8));
        $prefix = config('audience.api_keys.prefix').$id;
        $plaintext = $prefix.'_'.Str::random(40);

        $key = new self($attributes);
        $key->prefix = $prefix;
        $key->key_hash = self::hash($plaintext);

        return [$key, $plaintext];
    }

    public static function hash(string $plaintext): string
    {
        return hash('sha256', $plaintext);
    }

    /**
     * Extract the lookup prefix from a presented key, or null if malformed.
     */
    public static function prefixFrom(string $presented): ?string
    {
        $base = preg_quote((string) config('audience.api_keys.prefix'), '/');

        return preg_match('/^('.$base.'[a-z0-9]{8})_[A-Za-z0-9]{40}$/', $presented, $m) === 1 ? $m[1] : null;
    }

    public function creator(): BelongsTo
    {
        return $this->belongsTo(User::class, 'created_by');
    }

    public function isUsable(): bool
    {
        return $this->revoked_at === null
            && ($this->expires_at === null || $this->expires_at->isFuture());
    }

    public function can(string $ability): bool
    {
        $abilities = $this->abilities ?? [];

        return in_array('*', $abilities, true) || in_array($ability, $abilities, true);
    }

    public function allowsIp(?string $ip): bool
    {
        $allowed = $this->allowed_ips ?? [];

        if ($allowed === []) {
            return true;
        }

        return $ip !== null && \Symfony\Component\HttpFoundation\IpUtils::checkIp($ip, $allowed);
    }
}
