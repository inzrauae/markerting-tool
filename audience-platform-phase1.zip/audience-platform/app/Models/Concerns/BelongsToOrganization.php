<?php

declare(strict_types=1);

namespace App\Models\Concerns;

use App\Exceptions\TenantException;
use App\Models\Organization;
use App\Models\Scopes\TenantScope;
use App\Support\Tenancy\TenantContext;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * For models whose rows are owned by one (client) organization.
 *
 * - Adds the fail-closed TenantScope.
 * - Fills organization_id from the active tenant on create.
 * - Refuses to save a row into an organization other than the active tenant.
 *
 * @mixin Model
 */
trait BelongsToOrganization
{
    public static function bootBelongsToOrganization(): void
    {
        static::addGlobalScope(new TenantScope);

        static::saving(function (Model $model): void {
            $context = app(TenantContext::class);

            if (! $context->has()) {
                // System code running without a tenant must set organization_id itself.
                if ($model->getAttribute('organization_id') === null) {
                    throw TenantException::missing();
                }

                return;
            }

            if ($model->getAttribute('organization_id') === null) {
                $model->setAttribute('organization_id', $context->id());

                return;
            }

            if ((int) $model->getAttribute('organization_id') !== (int) $context->id()) {
                throw TenantException::mismatch();
            }
        });
    }

    public function organization(): BelongsTo
    {
        return $this->belongsTo(Organization::class);
    }

    /**
     * Query across all tenants. Use only in super-admin or system code.
     */
    public static function withoutTenancy(): Builder
    {
        return static::query()->withoutGlobalScope(TenantScope::class);
    }
}
