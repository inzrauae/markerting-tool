<?php

declare(strict_types=1);

namespace App\Models\Concerns;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

/**
 * Adds a ULID `public_id` used in URLs and API payloads, so sequential
 * internal IDs (which reveal volumes) are never exposed.
 *
 * @mixin Model
 */
trait HasPublicId
{
    public static function bootHasPublicId(): void
    {
        static::creating(function (Model $model): void {
            if (empty($model->getAttribute('public_id'))) {
                $model->setAttribute('public_id', strtolower((string) Str::ulid()));
            }
        });
    }

    public function getRouteKeyName(): string
    {
        return 'public_id';
    }
}
