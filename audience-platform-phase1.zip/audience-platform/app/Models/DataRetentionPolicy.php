<?php

declare(strict_types=1);

namespace App\Models;

use App\Models\Concerns\BelongsToOrganization;
use Illuminate\Database\Eloquent\Model;

/**
 * How long a client's raw tracking data is kept. Enforced by the Phase 2
 * retention job (partition drops + chunked tenant deletes / anonymisation).
 */
class DataRetentionPolicy extends Model
{
    use BelongsToOrganization;

    protected $fillable = [
        'organization_id', 'raw_event_days', 'visitor_profile_days',
        'aggregate_days', 'anonymize_instead_of_delete', 'updated_by',
    ];

    protected function casts(): array
    {
        return [
            'raw_event_days' => 'integer',
            'visitor_profile_days' => 'integer',
            'aggregate_days' => 'integer',
            'anonymize_instead_of_delete' => 'boolean',
        ];
    }

    /**
     * @return array<string, mixed>
     */
    public static function defaults(): array
    {
        return [
            'raw_event_days' => (int) config('audience.retention.default_raw_event_days'),
            'visitor_profile_days' => (int) config('audience.retention.default_visitor_profile_days'),
            'aggregate_days' => null,
            'anonymize_instead_of_delete' => false,
        ];
    }
}
