<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FeatureFlag extends Model
{
    protected $fillable = ['key', 'description', 'enabled', 'rules'];

    protected function casts(): array
    {
        return [
            'enabled' => 'boolean',
            'rules' => 'array',
        ];
    }

    /**
     * Enabled globally, or for this organization, or for its plan.
     */
    public function isEnabledFor(?Organization $organization): bool
    {
        if ($this->enabled) {
            return true;
        }

        if ($organization === null) {
            return false;
        }

        $rules = $this->rules ?? [];

        if (in_array($organization->public_id, $rules['organizations'] ?? [], true)) {
            return true;
        }

        $planCode = $organization->activeSubscription()?->plan?->code;

        return $planCode !== null && in_array($planCode, $rules['plans'] ?? [], true);
    }
}
