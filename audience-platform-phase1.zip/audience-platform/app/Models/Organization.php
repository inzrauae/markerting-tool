<?php

declare(strict_types=1);

namespace App\Models;

use App\Enums\OrganizationType;
use App\Models\Concerns\HasPublicId;
use Database\Factories\OrganizationFactory;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * An agency (billing owner, manages clients) or a client (owns tracking data).
 *
 * @property int $id
 * @property string $public_id
 * @property OrganizationType $type
 * @property int|null $parent_id
 * @property string $name
 * @property string $slug
 * @property string $status
 */
class Organization extends Model
{
    /** @use HasFactory<OrganizationFactory> */
    use HasFactory, HasPublicId, SoftDeletes;

    public const STATUS_ACTIVE = 'active';

    public const STATUS_SUSPENDED = 'suspended';

    protected $fillable = [
        'type',
        'parent_id',
        'name',
        'slug',
        'status',
        'timezone',
        'currency',
        'special_ad_category',
        'branding',
        'settings',
    ];

    protected function casts(): array
    {
        return [
            'type' => OrganizationType::class,
            'branding' => 'array',
            'settings' => 'array',
        ];
    }

    public function parent(): BelongsTo
    {
        return $this->belongsTo(self::class, 'parent_id');
    }

    public function clients(): HasMany
    {
        return $this->hasMany(self::class, 'parent_id')->where('type', OrganizationType::Client->value);
    }

    public function users(): BelongsToMany
    {
        return $this->belongsToMany(User::class, 'organization_users')
            ->using(OrganizationMembership::class)
            ->withPivot('role')
            ->withTimestamps();
    }

    public function memberships(): HasMany
    {
        return $this->hasMany(OrganizationMembership::class);
    }

    public function subscriptions(): HasMany
    {
        return $this->hasMany(Subscription::class);
    }

    public function retentionPolicy(): HasOne
    {
        return $this->hasOne(DataRetentionPolicy::class);
    }

    public function isAgency(): bool
    {
        return $this->type === OrganizationType::Agency;
    }

    public function isClient(): bool
    {
        return $this->type === OrganizationType::Client;
    }

    public function isActive(): bool
    {
        return $this->status === self::STATUS_ACTIVE;
    }

    /**
     * The agency that owns billing for this organization.
     */
    public function billingOwner(): self
    {
        return $this->isAgency() ? $this : $this->parent()->withTrashed()->firstOrFail();
    }

    public function activeSubscription(): ?Subscription
    {
        return $this->billingOwner()
            ->subscriptions()
            ->with('plan')
            ->whereIn('status', [Subscription::STATUS_TRIALING, Subscription::STATUS_ACTIVE, Subscription::STATUS_PAST_DUE])
            ->latest('id')
            ->first();
    }
}
