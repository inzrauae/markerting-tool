<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

/**
 * Plans are data, not code: limits and prices are edited by super admins.
 *
 * @property string $code
 * @property array<string, int|null> $limits
 */
class SubscriptionPlan extends Model
{
    protected $fillable = ['code', 'name', 'is_active', 'limits', 'prices', 'features', 'sort_order'];

    protected function casts(): array
    {
        return [
            'is_active' => 'boolean',
            'limits' => 'array',
            'prices' => 'array',
            'features' => 'array',
        ];
    }

    public function subscriptions(): HasMany
    {
        return $this->hasMany(Subscription::class);
    }

    /**
     * Limit for a metric. null = unlimited. Unknown metric = 0 (deny by default).
     */
    public function limit(string $metric): ?int
    {
        $limits = $this->limits ?? [];

        if (! array_key_exists($metric, $limits)) {
            return 0;
        }

        return $limits[$metric] === null ? null : (int) $limits[$metric];
    }
}
