<?php

declare(strict_types=1);

namespace App\Models;

use App\Models\Concerns\BelongsToOrganization;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * Hostnames allowed to send events for a website (checked against Origin).
 */
class TrackingDomain extends Model
{
    use BelongsToOrganization;

    protected $fillable = ['organization_id', 'website_id', 'domain', 'include_subdomains'];

    protected function casts(): array
    {
        return ['include_subdomains' => 'boolean'];
    }

    public function website(): BelongsTo
    {
        return $this->belongsTo(Website::class);
    }

    public function matches(string $host): bool
    {
        $host = strtolower(rtrim($host, '.'));
        $domain = strtolower($this->domain);

        if ($host === $domain) {
            return true;
        }

        return $this->include_subdomains && str_ends_with($host, '.'.$domain);
    }
}
