<?php

declare(strict_types=1);

namespace App\Models;

use App\Models\Concerns\BelongsToOrganization;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * A tracking-health check result (written by the Phase 2 health checker).
 */
class TrackingInstallation extends Model
{
    use BelongsToOrganization;

    protected $fillable = [
        'organization_id', 'website_id', 'checked_at', 'sdk_detected', 'sdk_version',
        'pixel_detected', 'gtag_detected', 'status', 'details',
    ];

    protected function casts(): array
    {
        return [
            'checked_at' => 'datetime',
            'sdk_detected' => 'boolean',
            'pixel_detected' => 'boolean',
            'gtag_detected' => 'boolean',
            'details' => 'array',
        ];
    }

    public function website(): BelongsTo
    {
        return $this->belongsTo(Website::class);
    }
}
