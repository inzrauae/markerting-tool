<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * Monthly usage counters (monthly_visitors, monthly_events, ai_analyses...).
 * System-written by metering jobs; read by billing and the admin console.
 */
class UsageMetric extends Model
{
    protected $fillable = ['organization_id', 'metric', 'period_start', 'quantity'];

    protected function casts(): array
    {
        return [
            'period_start' => 'date',
            'quantity' => 'integer',
        ];
    }
}
