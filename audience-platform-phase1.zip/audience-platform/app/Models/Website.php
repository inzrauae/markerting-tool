<?php

declare(strict_types=1);

namespace App\Models;

use App\Models\Concerns\BelongsToOrganization;
use App\Models\Concerns\HasPublicId;
use Database\Factories\WebsiteFactory;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Str;

/**
 * @property int $id
 * @property string $public_id
 * @property int $organization_id
 * @property string $name
 * @property string $primary_domain
 * @property string $site_key
 * @property string $status
 */
class Website extends Model
{
    /** @use HasFactory<WebsiteFactory> */
    use BelongsToOrganization, HasFactory, HasPublicId, SoftDeletes;

    public const STATUS_PENDING = 'pending';

    public const STATUS_ACTIVE = 'active';

    public const STATUS_PAUSED = 'paused';

    protected $fillable = [
        'organization_id',
        'name',
        'primary_domain',
        'status',
        'timezone',
        'settings',
    ];

    protected function casts(): array
    {
        return [
            'settings' => 'array',
            'last_event_at' => 'datetime',
        ];
    }

    protected static function booted(): void
    {
        static::creating(function (Website $website): void {
            $website->site_key ??= self::generateSiteKey();
        });
    }

    public static function generateSiteKey(): string
    {
        // 32 lowercase alphanumerics; public by design (embedded in the snippet).
        return Str::lower(Str::random(32));
    }

    public function trackingDomains(): HasMany
    {
        return $this->hasMany(TrackingDomain::class);
    }

    public function installations(): HasMany
    {
        return $this->hasMany(TrackingInstallation::class);
    }

    public function trackingSnippet(): string
    {
        $src = e(config('audience.tracker_url'));
        $key = e($this->site_key);

        return "<script async src=\"{$src}\" data-site=\"{$key}\"></script>";
    }
}
