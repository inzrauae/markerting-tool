<?php

declare(strict_types=1);

namespace App\Notifications;

use App\Enums\OrganizationRole;
use App\Models\Organization;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;
use Illuminate\Support\Carbon;

class OrganizationInvitationNotification extends Notification implements ShouldQueue
{
    use Queueable;

    // Not readonly: queue serialization (SerializesModels) re-assigns properties.
    public function __construct(
        public Organization $organization,
        public OrganizationRole $role,
        public string $token,
        public Carbon $expiresAt,
    ) {}

    /**
     * @return list<string>
     */
    public function via(object $notifiable): array
    {
        return ['mail'];
    }

    public function toMail(object $notifiable): MailMessage
    {
        $url = rtrim((string) config('app.url'), '/').'/invitations/accept?token='.urlencode($this->token);
        $roleLabel = str_replace('_', ' ', $this->role->value);

        return (new MailMessage)
            ->subject("You've been invited to {$this->organization->name}")
            ->line("You have been invited to join {$this->organization->name} as {$roleLabel}.")
            ->action('Accept invitation', $url)
            ->line('This invitation expires '.$this->expiresAt->toDayDateTimeString().' (UTC).')
            ->line('If you were not expecting this, you can ignore this e-mail.');
    }
}
