<?php

declare(strict_types=1);

namespace App\Policies;

use App\Enums\Permission;
use App\Models\ApiKey;
use App\Models\User;

class ApiKeyPolicy extends TenantPolicy
{
    public function viewAny(User $user): bool
    {
        return $this->canInTenant($user, Permission::ApiKeysManage);
    }

    public function create(User $user): bool
    {
        return $this->canInTenant($user, Permission::ApiKeysManage);
    }

    public function delete(User $user, ApiKey $apiKey): bool
    {
        return $this->canOnModel($user, $apiKey, Permission::ApiKeysManage);
    }
}
