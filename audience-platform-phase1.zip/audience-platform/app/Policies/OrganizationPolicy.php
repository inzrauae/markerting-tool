<?php

declare(strict_types=1);

namespace App\Policies;

use App\Enums\Permission;
use App\Models\Organization;
use App\Models\User;

/**
 * Organizations ARE the tenant, so these checks look at the organization
 * itself rather than at the active tenant.
 */
class OrganizationPolicy extends TenantPolicy
{
    public function view(User $user, Organization $organization): bool
    {
        return $this->canOnOrganization($user, $organization, Permission::OrganizationView);
    }

    public function update(User $user, Organization $organization): bool
    {
        return $this->canOnOrganization($user, $organization, Permission::OrganizationUpdate);
    }

    public function viewMembers(User $user, Organization $organization): bool
    {
        return $this->canOnOrganization($user, $organization, Permission::MembersView);
    }

    public function manageMembers(User $user, Organization $organization): bool
    {
        return $this->canOnOrganization($user, $organization, Permission::MembersManage);
    }

    public function createClient(User $user, Organization $organization): bool
    {
        return $organization->isAgency()
            && $this->canOnOrganization($user, $organization, Permission::ClientsManage);
    }

    public function viewAudit(User $user, Organization $organization): bool
    {
        return $this->canOnOrganization($user, $organization, Permission::AuditView);
    }

    public function manageRetention(User $user, Organization $organization): bool
    {
        return $organization->isClient()
            && $this->canOnOrganization($user, $organization, Permission::RetentionManage);
    }

    public function viewRetention(User $user, Organization $organization): bool
    {
        return $organization->isClient()
            && $this->canOnOrganization($user, $organization, Permission::OrganizationView);
    }
}
