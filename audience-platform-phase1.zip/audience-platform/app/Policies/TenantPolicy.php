<?php

declare(strict_types=1);

namespace App\Policies;

use App\Enums\Permission;
use App\Models\Organization;
use App\Models\User;
use App\Services\Tenancy\OrganizationAccess;
use App\Support\Tenancy\TenantContext;
use Illuminate\Database\Eloquent\Model;

/**
 * Shared checks for policies on tenant-owned models.
 *
 * A model is only ever authorized if it belongs to the ACTIVE tenant, even if
 * the user could access its organization some other way. This prevents a
 * confused-deputy bug where a record from org B is acted on while org A is
 * selected.
 */
abstract class TenantPolicy
{
    public function __construct(
        protected readonly TenantContext $tenant,
        protected readonly OrganizationAccess $access,
    ) {}

    protected function canInTenant(User $user, Permission $permission): bool
    {
        $organization = $this->tenant->get();

        return $organization !== null && $this->access->can($user, $organization, $permission);
    }

    protected function canOnModel(User $user, Model $model, Permission $permission): bool
    {
        $organization = $this->tenant->get();

        if ($organization === null || (int) $model->getAttribute('organization_id') !== (int) $organization->getKey()) {
            return false;
        }

        return $this->access->can($user, $organization, $permission);
    }

    protected function canOnOrganization(User $user, Organization $organization, Permission $permission): bool
    {
        return $this->access->can($user, $organization, $permission);
    }
}
