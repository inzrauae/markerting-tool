<?php

declare(strict_types=1);

namespace App\Policies;

use App\Enums\Permission;
use App\Models\User;
use App\Models\Website;

class WebsitePolicy extends TenantPolicy
{
    public function viewAny(User $user): bool
    {
        return $this->canInTenant($user, Permission::WebsitesView);
    }

    public function view(User $user, Website $website): bool
    {
        return $this->canOnModel($user, $website, Permission::WebsitesView);
    }

    public function create(User $user): bool
    {
        return $this->canInTenant($user, Permission::WebsitesManage);
    }

    public function update(User $user, Website $website): bool
    {
        return $this->canOnModel($user, $website, Permission::WebsitesManage);
    }

    public function delete(User $user, Website $website): bool
    {
        return $this->canOnModel($user, $website, Permission::WebsitesManage);
    }

    public function rotateKey(User $user, Website $website): bool
    {
        return $this->canOnModel($user, $website, Permission::WebsitesManage);
    }
}
