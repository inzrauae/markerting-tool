<?php

declare(strict_types=1);

namespace App\Providers;

use App\Support\Tenancy\TenantContext;
use Illuminate\Cache\RateLimiting\Limit;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\ServiceProvider;
use Illuminate\Validation\Rules\Password;

class AppServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        // Scoped: reset per request and per queued job.
        $this->app->scoped(TenantContext::class);
    }

    public function boot(): void
    {
        // Catch lazy-loading / silently discarded attributes / missing attributes early.
        Model::shouldBeStrict(! $this->app->isProduction());

        Password::defaults(fn () => $this->app->isProduction()
            ? Password::min(10)->mixedCase()->numbers()->uncompromised()
            : Password::min(8));

        $this->configureRateLimiting();
    }

    private function configureRateLimiting(): void
    {
        RateLimiter::for('api', function (Request $request) {
            $key = $request->user()?->getAuthIdentifier()
                ?? $request->attributes->get('api_key')?->getKey()
                ?? $request->ip();

            return Limit::perMinute(300)->by('api:'.$key);
        });

        RateLimiter::for('login', function (Request $request) {
            $email = strtolower((string) $request->input('email'));

            return [
                Limit::perMinute(5)->by('login:'.$email.'|'.$request->ip()),
                Limit::perMinute(30)->by('login-ip:'.$request->ip()),
            ];
        });

        RateLimiter::for('register', fn (Request $request) => Limit::perHour(10)->by('register:'.$request->ip()));

        RateLimiter::for('invitations', fn (Request $request) => Limit::perHour(50)->by('invite:'.($request->user()?->getAuthIdentifier() ?? $request->ip())));

        RateLimiter::for('sensitive', fn (Request $request) => Limit::perMinute(10)->by('sensitive:'.($request->user()?->getAuthIdentifier() ?? $request->ip())));
    }
}
