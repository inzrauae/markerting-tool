<?php

declare(strict_types=1);

namespace App\Services\Audit;

use App\Models\ApiKey;
use App\Models\AuditLog;
use App\Models\Organization;
use App\Models\User;
use App\Support\Tenancy\TenantContext;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

/**
 * Writes append-only audit entries. Secrets are redacted from `changes`.
 */
final class AuditLogger
{
    private const REDACT = ['password', 'token', 'secret', 'key_hash', 'token_hash', 'access_token', 'refresh_token', 'api_key'];

    public function __construct(private readonly TenantContext $tenant) {}

    /**
     * @param  array<string, mixed>|null  $changes
     */
    public function log(
        string $action,
        ?Model $subject = null,
        ?array $changes = null,
        ?Organization $organization = null,
        User|ApiKey|null $actor = null,
    ): AuditLog {
        $request = app()->runningInConsole() && ! app()->runningUnitTests()
            ? null
            : (app()->bound('request') ? app('request') : null);
        $actor ??= $this->resolveActor($request);

        [$actorType, $actorId] = match (true) {
            $actor instanceof User => ['user', $actor->getKey()],
            $actor instanceof ApiKey => ['api_key', $actor->getKey()],
            default => ['system', null],
        };

        $organizationId = $organization?->getKey()
            ?? $this->subjectOrganizationId($subject)
            ?? $this->tenant->id();

        return AuditLog::query()->create([
            'organization_id' => $organizationId,
            'actor_type' => $actorType,
            'actor_id' => $actorId,
            'action' => $action,
            'subject_type' => $subject ? $subject->getMorphClass() : null,
            'subject_id' => $subject?->getKey(),
            'changes' => $changes === null ? null : $this->redact($changes),
            'ip_address' => $request?->ip(),
            'user_agent' => $request ? Str::limit((string) $request->userAgent(), 250, '') : null,
        ]);
    }

    private function resolveActor(?Request $request): User|ApiKey|null
    {
        if ($request === null) {
            return null;
        }

        $apiKey = $request->attributes->get('api_key');
        if ($apiKey instanceof ApiKey) {
            return $apiKey;
        }

        $user = $request->user();

        return $user instanceof User ? $user : null;
    }

    private function subjectOrganizationId(?Model $subject): ?int
    {
        if ($subject instanceof Organization) {
            return $subject->getKey();
        }

        $id = $subject?->getAttribute('organization_id');

        return $id === null ? null : (int) $id;
    }

    /**
     * @param  array<string, mixed>  $changes
     * @return array<string, mixed>
     */
    private function redact(array $changes): array
    {
        foreach ($changes as $key => $value) {
            if (is_array($value)) {
                $changes[$key] = $this->redact($value);
            } elseif (is_string($key) && Str::contains(Str::lower($key), self::REDACT)) {
                $changes[$key] = '[redacted]';
            }
        }

        return $changes;
    }
}
