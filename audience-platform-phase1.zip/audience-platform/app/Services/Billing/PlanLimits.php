<?php

declare(strict_types=1);

namespace App\Services\Billing;

use App\Models\Organization;
use App\Models\OrganizationMembership;
use App\Models\Website;
use Illuminate\Validation\ValidationException;

/**
 * Enforces countable plan limits (websites, users, clients) across the whole
 * agency, since the agency is the billing owner. Metered limits (events,
 * visitors, AI analyses) are enforced by the metering pipeline in later phases.
 */
final class PlanLimits
{
    public const WEBSITES = 'websites';

    public const USERS = 'users';

    public const CLIENTS = 'clients';

    public function remaining(Organization $organization, string $metric): ?int
    {
        $plan = $organization->activeSubscription()?->plan;

        if ($plan === null) {
            return 0;
        }

        $limit = $plan->limit($metric);

        return $limit === null ? null : max(0, $limit - $this->currentUsage($organization->billingOwner(), $metric));
    }

    /**
     * @throws ValidationException
     */
    public function assertCanAdd(Organization $organization, string $metric, string $field = 'plan'): void
    {
        $remaining = $this->remaining($organization, $metric);

        if ($remaining !== null && $remaining < 1) {
            throw ValidationException::withMessages([
                $field => "Your plan's {$metric} limit has been reached. Upgrade the plan to add more.",
            ]);
        }
    }

    public function currentUsage(Organization $agency, string $metric): int
    {
        $orgIds = Organization::query()
            ->where('id', $agency->getKey())
            ->orWhere('parent_id', $agency->getKey())
            ->pluck('id');

        return match ($metric) {
            self::WEBSITES => Website::withoutTenancy()->whereIn('organization_id', $orgIds)->count(),
            self::USERS => OrganizationMembership::query()->whereIn('organization_id', $orgIds)->distinct()->count('user_id'),
            self::CLIENTS => Organization::query()->where('parent_id', $agency->getKey())->count(),
            default => 0,
        };
    }
}
