<?php

declare(strict_types=1);

namespace App\Services\Tenancy;

use App\Enums\OrganizationRole;
use App\Models\Organization;
use App\Models\OrganizationInvitation;
use App\Models\OrganizationMembership;
use App\Models\User;
use App\Notifications\OrganizationInvitationNotification;
use App\Services\Audit\AuditLogger;
use App\Services\Billing\PlanLimits;
use App\Support\Tenancy\TenantContext;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Notification;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

final class MembershipService
{
    public function __construct(
        private readonly OrganizationAccess $access,
        private readonly PlanLimits $limits,
        private readonly AuditLogger $audit,
        private readonly TenantContext $tenant,
    ) {}

    public function invite(Organization $organization, string $email, OrganizationRole $role, User $inviter): OrganizationInvitation
    {
        $email = Str::lower(trim($email));
        $this->assertRoleAllowed($organization, $role, $inviter);

        $existing = User::query()->where('email', $email)->first();
        if ($existing !== null && $this->access->isMember($existing, $organization)) {
            throw ValidationException::withMessages(['email' => 'This person is already a member of the organization.']);
        }

        $this->limits->assertCanAdd($organization, PlanLimits::USERS, 'email');

        [$invitation, $token] = $this->tenant->runAs($organization, function () use ($organization, $email, $role, $inviter) {
            // Re-inviting replaces any earlier pending invitation for this e-mail.
            OrganizationInvitation::query()
                ->where('email', $email)
                ->whereNull('accepted_at')
                ->whereNull('revoked_at')
                ->update(['revoked_at' => now()]);

            [$invitation, $token] = OrganizationInvitation::issue([
                'organization_id' => $organization->getKey(),
                'email' => $email,
                'role' => $role,
                'invited_by' => $inviter->getKey(),
                'expires_at' => now()->addHours((int) config('audience.invitation_ttl_hours')),
            ]);
            $invitation->save();

            return [$invitation, $token];
        });

        Notification::route('mail', $email)
            ->notify(new OrganizationInvitationNotification($organization, $role, $token, $invitation->expires_at));

        $this->audit->log('member.invited', $invitation, ['email' => $email, 'role' => $role->value], $organization, $inviter);

        return $invitation;
    }

    /**
     * Accept an invitation. An authenticated user must hold the invited e-mail;
     * otherwise a new account is created from $newUser (name, password).
     *
     * @param  array{name?: string, password?: string}  $newUser
     */
    public function accept(string $token, ?User $current, array $newUser = []): OrganizationMembership
    {
        $invitation = OrganizationInvitation::findPendingByToken($token);

        if ($invitation === null) {
            throw ValidationException::withMessages(['token' => 'This invitation is invalid or has expired.']);
        }

        return DB::transaction(function () use ($invitation, $current, $newUser): OrganizationMembership {
            $user = $current;

            if ($user !== null && Str::lower($user->email) !== Str::lower($invitation->email)) {
                throw ValidationException::withMessages(['token' => 'This invitation was sent to a different e-mail address.']);
            }

            if ($user === null) {
                if (User::query()->where('email', $invitation->email)->exists()) {
                    throw ValidationException::withMessages(['email' => 'An account with this e-mail exists. Log in, then accept the invitation.']);
                }

                if (empty($newUser['name']) || empty($newUser['password'])) {
                    throw ValidationException::withMessages(['name' => 'Name and password are required to create your account.']);
                }

                $user = User::query()->create([
                    'name' => $newUser['name'],
                    'email' => $invitation->email,
                    'password' => $newUser['password'],
                ]);
                // The invitation link was delivered to this address, which verifies it.
                $user->forceFill(['email_verified_at' => now()])->save();
            }

            $membership = OrganizationMembership::query()->firstOrCreate(
                ['organization_id' => $invitation->organization_id, 'user_id' => $user->getKey()],
                ['role' => $invitation->role],
            );

            $organization = Organization::query()->findOrFail($invitation->organization_id);

            $this->tenant->runAs($organization, fn () => $invitation->forceFill(['accepted_at' => now()])->save());
            $this->audit->log('member.joined', $membership, ['role' => $invitation->role->value], $organization, $user);

            return $membership;
        });
    }

    public function changeRole(Organization $organization, User $member, OrganizationRole $role, User $actor): OrganizationMembership
    {
        $this->assertRoleAllowed($organization, $role, $actor);

        $membership = $this->membershipOrFail($organization, $member);
        $this->assertNotLastAdmin($organization, $membership, $role);

        $before = $membership->role->value;
        $membership->update(['role' => $role]);

        $this->audit->log('member.role_changed', $membership, ['from' => $before, 'to' => $role->value], $organization, $actor);

        return $membership;
    }

    public function remove(Organization $organization, User $member, User $actor): void
    {
        $membership = $this->membershipOrFail($organization, $member);
        $this->assertNotLastAdmin($organization, $membership, null);

        $membership->delete();

        $this->audit->log('member.removed', $membership, ['user' => $member->public_id], $organization, $actor);
    }

    private function assertRoleAllowed(Organization $organization, OrganizationRole $role, User $actor): void
    {
        if (! in_array($role, OrganizationRole::assignableTo($organization->type), true)) {
            throw ValidationException::withMessages(['role' => "The {$role->value} role cannot be used on a {$organization->type->value} organization."]);
        }

        $actorRole = $this->access->roleFor($actor, $organization);
        if ($actorRole === null || ! $actorRole->canGrant($role)) {
            throw ValidationException::withMessages(['role' => 'You cannot grant a role higher than your own.']);
        }
    }

    private function membershipOrFail(Organization $organization, User $member): OrganizationMembership
    {
        $membership = OrganizationMembership::query()
            ->where('organization_id', $organization->getKey())
            ->where('user_id', $member->getKey())
            ->first();

        if ($membership === null) {
            throw ValidationException::withMessages(['user' => 'This person is not a member of the organization.']);
        }

        return $membership;
    }

    /**
     * Every organization keeps at least one admin of its own type, so it can
     * never be orphaned (clients are additionally reachable by agency admins).
     */
    private function assertNotLastAdmin(Organization $organization, OrganizationMembership $membership, ?OrganizationRole $newRole): void
    {
        $adminRole = $organization->isAgency() ? OrganizationRole::AgencyAdmin : OrganizationRole::ClientAdmin;

        if ($membership->role !== $adminRole || $newRole === $adminRole) {
            return;
        }

        if (! $organization->isAgency()) {
            return; // Agency admins can always manage a client, so a client may have zero client admins.
        }

        $admins = OrganizationMembership::query()
            ->where('organization_id', $organization->getKey())
            ->where('role', $adminRole->value)
            ->count();

        if ($admins <= 1) {
            throw ValidationException::withMessages(['user' => 'An agency must keep at least one agency admin.']);
        }
    }
}
