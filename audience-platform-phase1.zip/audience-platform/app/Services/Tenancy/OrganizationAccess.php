<?php

declare(strict_types=1);

namespace App\Services\Tenancy;

use App\Enums\OrganizationRole;
use App\Enums\Permission;
use App\Models\Organization;
use App\Models\OrganizationMembership;
use App\Models\User;
use Illuminate\Database\Eloquent\Builder;

/**
 * Single source of truth for "which organizations can this user reach, and
 * with which role". Policies and the tenant middleware both go through here.
 *
 * Rules:
 *  - Direct membership grants the membership's role.
 *  - An agency_admin of an agency is implicitly agency_admin of its clients.
 *  - Super admins act as agency_admin everywhere (access is audit-logged by
 *    ResolveTenant when they enter an org they are not a member of).
 */
final class OrganizationAccess
{
    public function roleFor(User $user, Organization $organization): ?OrganizationRole
    {
        if ($user->isSuperAdmin()) {
            return OrganizationRole::AgencyAdmin;
        }

        $direct = OrganizationMembership::query()
            ->where('user_id', $user->getKey())
            ->where('organization_id', $organization->getKey())
            ->value('role');

        if ($direct !== null) {
            return $direct instanceof OrganizationRole ? $direct : OrganizationRole::from($direct);
        }

        if ($organization->isClient() && $organization->parent_id !== null) {
            $isAgencyAdmin = OrganizationMembership::query()
                ->where('user_id', $user->getKey())
                ->where('organization_id', $organization->parent_id)
                ->where('role', OrganizationRole::AgencyAdmin->value)
                ->exists();

            if ($isAgencyAdmin) {
                return OrganizationRole::AgencyAdmin;
            }
        }

        return null;
    }

    /**
     * Batch version of roleFor() for listings (one query instead of N).
     *
     * @param  iterable<Organization>  $organizations
     * @return array<int, OrganizationRole|null> keyed by organization id
     */
    public function rolesFor(User $user, iterable $organizations): array
    {
        $direct = OrganizationMembership::query()
            ->where('user_id', $user->getKey())
            ->get(['organization_id', 'role'])
            ->mapWithKeys(fn (OrganizationMembership $m) => [$m->organization_id => $m->role])
            ->all();

        $roles = [];

        foreach ($organizations as $organization) {
            $id = $organization->getKey();

            $roles[$id] = match (true) {
                $user->isSuperAdmin() => OrganizationRole::AgencyAdmin,
                isset($direct[$id]) => $direct[$id],
                $organization->isClient()
                    && $organization->parent_id !== null
                    && ($direct[$organization->parent_id] ?? null) === OrganizationRole::AgencyAdmin => OrganizationRole::AgencyAdmin,
                default => null,
            };
        }

        return $roles;
    }

    public function isMember(User $user, Organization $organization): bool
    {
        return OrganizationMembership::query()
            ->where('user_id', $user->getKey())
            ->where('organization_id', $organization->getKey())
            ->exists();
    }

    public function canAccess(User $user, Organization $organization): bool
    {
        return $this->roleFor($user, $organization) !== null;
    }

    public function can(User $user, Organization $organization, Permission $permission): bool
    {
        return $this->roleFor($user, $organization)?->can($permission) ?? false;
    }

    /**
     * Organizations the user can select as tenant.
     *
     * @return Builder<Organization>
     */
    public function accessibleOrganizations(User $user): Builder
    {
        if ($user->isSuperAdmin()) {
            return Organization::query();
        }

        return $this->membershipOrganizations($user);
    }

    /**
     * Organizations reachable through memberships only (ignores the super
     * admin flag): direct memberships plus clients of agencies the user admins.
     *
     * @return Builder<Organization>
     */
    public function membershipOrganizations(User $user): Builder
    {
        $query = Organization::query();

        $memberOf = OrganizationMembership::query()
            ->select('organization_id')
            ->where('user_id', $user->getKey());

        $adminOfAgencies = OrganizationMembership::query()
            ->select('organization_id')
            ->where('user_id', $user->getKey())
            ->where('role', OrganizationRole::AgencyAdmin->value);

        return $query->where(function (Builder $q) use ($memberOf, $adminOfAgencies): void {
            $q->whereIn('id', $memberOf)->orWhereIn('parent_id', $adminOfAgencies);
        });
    }
}
