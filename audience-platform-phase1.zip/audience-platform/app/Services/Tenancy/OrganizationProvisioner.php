<?php

declare(strict_types=1);

namespace App\Services\Tenancy;

use App\Enums\OrganizationRole;
use App\Enums\OrganizationType;
use App\Models\DataRetentionPolicy;
use App\Models\Organization;
use App\Models\OrganizationMembership;
use App\Models\Subscription;
use App\Models\SubscriptionPlan;
use App\Models\User;
use App\Services\Audit\AuditLogger;
use App\Services\Billing\PlanLimits;
use App\Support\Tenancy\TenantContext;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use RuntimeException;

/**
 * Creates agencies and clients with everything they need to be usable:
 * membership, trial subscription and default retention policy.
 */
final class OrganizationProvisioner
{
    public function __construct(
        private readonly PlanLimits $limits,
        private readonly AuditLogger $audit,
        private readonly TenantContext $tenant,
    ) {}

    /**
     * Sign-up. A non-agency business still gets an agency (billing owner)
     * with one client, so there is a single code path for both.
     *
     * @return array{agency: Organization, client: Organization|null}
     */
    public function registerAccount(User $owner, string $organizationName, bool $isAgency, array $attributes = []): array
    {
        return DB::transaction(function () use ($owner, $organizationName, $isAgency, $attributes): array {
            $agency = Organization::query()->create([
                'type' => OrganizationType::Agency,
                'name' => $organizationName,
                'slug' => $this->uniqueSlug($organizationName),
                'status' => Organization::STATUS_ACTIVE,
                'timezone' => $attributes['timezone'] ?? 'UTC',
                'currency' => $attributes['currency'] ?? 'LKR',
            ]);

            OrganizationMembership::query()->create([
                'organization_id' => $agency->getKey(),
                'user_id' => $owner->getKey(),
                'role' => OrganizationRole::AgencyAdmin,
            ]);

            $this->startTrial($agency);

            $client = $isAgency ? null : $this->createClientRecord($agency, $organizationName, $attributes);

            $this->audit->log('organization.registered', $agency, [
                'type' => $isAgency ? 'agency' : 'business',
                'client' => $client?->public_id,
            ], $agency, $owner);

            return ['agency' => $agency, 'client' => $client];
        });
    }

    /**
     * Agency admin adds a client. Enforces the plan's client limit.
     */
    public function createClient(Organization $agency, string $name, array $attributes = []): Organization
    {
        if (! $agency->isAgency()) {
            throw new RuntimeException('Clients can only be created under an agency.');
        }

        $this->limits->assertCanAdd($agency, PlanLimits::CLIENTS, 'name');

        return DB::transaction(function () use ($agency, $name, $attributes): Organization {
            $client = $this->createClientRecord($agency, $name, $attributes);
            $this->audit->log('organization.client_created', $client, ['name' => $name], $agency);

            return $client;
        });
    }

    private function createClientRecord(Organization $agency, string $name, array $attributes): Organization
    {
        $client = Organization::query()->create([
            'type' => OrganizationType::Client,
            'parent_id' => $agency->getKey(),
            'name' => $name,
            'slug' => $this->uniqueSlug($name),
            'status' => Organization::STATUS_ACTIVE,
            'timezone' => $attributes['timezone'] ?? $agency->timezone,
            'currency' => $attributes['currency'] ?? $agency->currency,
            'special_ad_category' => $attributes['special_ad_category'] ?? null,
        ]);

        // Write the client's own rows as the client tenant (the caller may be
        // acting under the agency's context, which the tenant guard would reject).
        $this->tenant->runAs($client, fn () => DataRetentionPolicy::query()->create(
            ['organization_id' => $client->getKey()] + DataRetentionPolicy::defaults()
        ));

        return $client;
    }

    private function startTrial(Organization $agency): void
    {
        $plan = SubscriptionPlan::query()
            ->where('code', config('audience.default_plan'))
            ->where('is_active', true)
            ->first();

        if ($plan === null) {
            throw new RuntimeException('Default subscription plan is missing. Run the database seeder (SubscriptionPlanSeeder).');
        }

        $days = (int) config('audience.trial_days');

        Subscription::query()->create([
            'organization_id' => $agency->getKey(),
            'subscription_plan_id' => $plan->getKey(),
            'status' => Subscription::STATUS_TRIALING,
            'current_period_start' => now(),
            'current_period_end' => now()->addDays($days),
            'trial_ends_at' => now()->addDays($days),
        ]);
    }

    private function uniqueSlug(string $name): string
    {
        $base = Str::slug($name) ?: 'org';
        $base = Str::limit($base, 160, '');
        $slug = $base;

        while (Organization::withTrashed()->where('slug', $slug)->exists()) {
            $slug = $base.'-'.Str::lower(Str::random(5));
        }

        return $slug;
    }
}
