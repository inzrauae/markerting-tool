<?php

declare(strict_types=1);

namespace App\Support;

/**
 * Normalises user-entered website addresses to a bare lowercase hostname:
 * "https://WWW.Example.com:443/path?q" → "www.example.com".
 */
final class Domain
{
    public static function normalize(?string $input): ?string
    {
        $input = trim((string) $input);

        if ($input === '') {
            return null;
        }

        if (! preg_match('#^[a-z][a-z0-9+.-]*://#i', $input)) {
            $input = 'http://'.$input;
        }

        $host = parse_url($input, PHP_URL_HOST);

        if (! is_string($host) || $host === '') {
            return null;
        }

        $host = rtrim(strtolower($host), '.');

        if (function_exists('idn_to_ascii')) {
            $ascii = idn_to_ascii($host, IDNA_DEFAULT, INTL_IDNA_VARIANT_UTS46);
            $host = $ascii === false ? $host : $ascii;
        }

        return self::isValidHostname($host) ? $host : null;
    }

    public static function isValidHostname(string $host): bool
    {
        if ($host === 'localhost') {
            return true;
        }

        if (strlen($host) > 253 || ! str_contains($host, '.')) {
            return false;
        }

        // IP literals are not valid tracking domains.
        if (filter_var($host, FILTER_VALIDATE_IP) !== false) {
            return false;
        }

        return filter_var($host, FILTER_VALIDATE_DOMAIN, FILTER_FLAG_HOSTNAME) !== false;
    }
}
