<?php

declare(strict_types=1);

namespace App\Support\Tenancy;

use App\Models\Organization;
use Closure;

/**
 * The organization whose data the current request/job is allowed to touch.
 *
 * Registered as a *scoped* binding, so it is reset between requests and
 * queued jobs (and between Octane requests). Tenant-owned models read it
 * through the TenantScope global scope.
 */
final class TenantContext
{
    private ?Organization $organization = null;

    public function set(Organization $organization): void
    {
        $this->organization = $organization;
    }

    public function clear(): void
    {
        $this->organization = null;
    }

    public function has(): bool
    {
        return $this->organization !== null;
    }

    public function get(): ?Organization
    {
        return $this->organization;
    }

    public function id(): ?int
    {
        $key = $this->organization?->getKey();

        return $key === null ? null : (int) $key;
    }

    /**
     * Run a callback as the given tenant, restoring the previous one afterwards.
     *
     * @template T
     *
     * @param  Closure(): T  $callback
     * @return T
     */
    public function runAs(Organization $organization, Closure $callback): mixed
    {
        $previous = $this->organization;
        $this->organization = $organization;

        try {
            return $callback();
        } finally {
            $this->organization = $previous;
        }
    }
}
