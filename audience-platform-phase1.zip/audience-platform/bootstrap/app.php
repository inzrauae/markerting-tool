<?php

use App\Exceptions\TenantException;
use App\Http\Middleware\AuthenticateApiKey;
use App\Http\Middleware\ClearTenantContext;
use App\Http\Middleware\EnsureClientOrganization;
use App\Http\Middleware\EnsureSuperAdmin;
use App\Http\Middleware\ResolveTenant;
use App\Http\Middleware\SecurityHeaders;
use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;
use Illuminate\Http\Request;
use Illuminate\Routing\Middleware\SubstituteBindings;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        api: __DIR__.'/../routes/api.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware): void {
        // Sanctum cookie auth for the first-party dashboard SPA.
        $middleware->statefulApi();
        $middleware->throttleApi('api');

        $middleware->prepend(ClearTenantContext::class);
        $middleware->append(SecurityHeaders::class);

        $middleware->alias([
            'tenant' => ResolveTenant::class,
            'tenant.client' => EnsureClientOrganization::class,
            'api_key' => AuthenticateApiKey::class,
            'super_admin' => EnsureSuperAdmin::class,
        ]);

        // The tenant must be resolved (after authentication) BEFORE route model
        // binding runs, otherwise tenant-scoped models would be bound without a
        // tenant and the fail-closed scope would 404 every request.
        // Insertion order matters: each entry is placed directly before
        // SubstituteBindings, so the resulting order is ApiKey → Tenant → Bindings.
        $middleware->prependToPriorityList(SubstituteBindings::class, AuthenticateApiKey::class);
        $middleware->prependToPriorityList(SubstituteBindings::class, ResolveTenant::class);
    })
    ->withExceptions(function (Exceptions $exceptions): void {
        $exceptions->shouldRenderJsonWhen(
            fn (Request $request) => $request->is('api/*') || $request->expectsJson(),
        );

        $exceptions->render(function (TenantException $e, Request $request) {
            return response()->json(['message' => $e->getMessage()], $e->status);
        });
    })->create();
