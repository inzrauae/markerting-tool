<?php

/*
|--------------------------------------------------------------------------
| Audience IQ platform configuration
|--------------------------------------------------------------------------
|
| Platform-wide defaults. Anything commercial (plan limits, prices) lives in
| the database (subscription_plans), never here.
|
*/

return [

    'trial_days' => (int) env('AIQ_TRIAL_DAYS', 14),

    'default_plan' => env('AIQ_DEFAULT_PLAN', 'starter'),

    'invitation_ttl_hours' => (int) env('AIQ_INVITATION_TTL_HOURS', 72),

    'tracker_url' => env('AIQ_TRACKER_URL') ?: rtrim((string) env('APP_URL', 'http://localhost'), '/').'/tracker.js',

    'retention' => [
        // Choices offered in the UI. "custom" lets admins enter any value in range.
        'choices' => [30, 90, 180, 365],
        'min_days' => 1,
        'max_days' => 1095,
        'default_raw_event_days' => (int) env('AIQ_DEFAULT_RAW_EVENT_RETENTION_DAYS', 180),
        'default_visitor_profile_days' => (int) env('AIQ_DEFAULT_VISITOR_RETENTION_DAYS', 365),
    ],

    'api_keys' => [
        // Prefix makes leaked keys easy to recognise by secret scanners.
        'prefix' => 'aiq_live_',

        // Abilities an API key may be granted. Phase 2+ endpoints check these.
        'abilities' => [
            'events:write',
            'conversions:write',
            'visitors:read',
            'audiences:read',
            'reports:read',
            'websites:read',
        ],
    ],

    'tenancy' => [
        // Header the SPA/API clients send to select the active organization.
        'header' => 'X-Organization-Id',
    ],

    'integrations' => [
        'meta' => [
            'app_id' => env('META_APP_ID'),
            'app_secret' => env('META_APP_SECRET'),
            'graph_version' => env('META_GRAPH_VERSION'),
            'redirect_uri' => env('META_OAUTH_REDIRECT_URI'),
        ],
        'google' => [
            'client_id' => env('GOOGLE_CLIENT_ID'),
            'client_secret' => env('GOOGLE_CLIENT_SECRET'),
            'redirect_uri' => env('GOOGLE_OAUTH_REDIRECT_URI'),
            'ads_developer_token' => env('GOOGLE_ADS_DEVELOPER_TOKEN'),
            'ads_login_customer_id' => env('GOOGLE_ADS_LOGIN_CUSTOMER_ID'),
            'ads_api_version' => env('GOOGLE_ADS_API_VERSION'),
        ],
    ],

    'ai' => [
        'provider' => env('AI_PROVIDER', 'anthropic'),
        'model' => env('AI_MODEL'),
        'api_key' => env('ANTHROPIC_API_KEY'),
    ],
];
