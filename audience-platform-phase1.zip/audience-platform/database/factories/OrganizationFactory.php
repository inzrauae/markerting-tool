<?php

declare(strict_types=1);

namespace Database\Factories;

use App\Enums\OrganizationType;
use App\Models\Organization;
use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Str;

/**
 * @extends Factory<Organization>
 */
class OrganizationFactory extends Factory
{
    protected $model = Organization::class;

    /**
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        $name = fake()->unique()->company();

        return [
            'type' => OrganizationType::Agency,
            'parent_id' => null,
            'name' => $name,
            'slug' => Str::slug($name).'-'.Str::lower(Str::random(6)),
            'status' => Organization::STATUS_ACTIVE,
            'timezone' => 'UTC',
            'currency' => 'LKR',
        ];
    }

    public function agency(): static
    {
        return $this->state(['type' => OrganizationType::Agency, 'parent_id' => null]);
    }

    public function clientOf(Organization $agency): static
    {
        return $this->state(['type' => OrganizationType::Client, 'parent_id' => $agency->getKey()]);
    }

    public function suspended(): static
    {
        return $this->state(['status' => Organization::STATUS_SUSPENDED]);
    }
}
