<?php

declare(strict_types=1);

namespace Database\Factories;

use App\Models\Website;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * Pass organization_id explicitly (or create inside TenantContext::runAs()).
 *
 * @extends Factory<Website>
 */
class WebsiteFactory extends Factory
{
    protected $model = Website::class;

    /**
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'name' => fake()->words(2, true).' site',
            'primary_domain' => fake()->unique()->domainWord().'-'.fake()->randomNumber(5).'.example',
            'status' => Website::STATUS_PENDING,
            'timezone' => 'UTC',
            'settings' => ['bot_filtering' => true],
        ];
    }
}
