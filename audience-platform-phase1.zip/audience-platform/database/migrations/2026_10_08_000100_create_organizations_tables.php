<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('organizations', function (Blueprint $table) {
            $table->id();
            $table->char('public_id', 26)->unique();
            $table->enum('type', ['agency', 'client']);
            // Clients always belong to an agency. Agencies have no parent.
            $table->foreignId('parent_id')->nullable()->constrained('organizations')->restrictOnDelete();
            $table->string('name', 160);
            $table->string('slug', 180)->unique();
            $table->enum('status', ['active', 'suspended'])->default('active');
            $table->string('timezone', 64)->default('UTC');
            $table->char('currency', 3)->default('LKR');
            // Meta/Google "special ad category" (housing, credit, employment...)
            // restricts custom-audience use; surfaced in the activation flow.
            $table->string('special_ad_category', 32)->nullable();
            $table->json('branding')->nullable();
            $table->json('settings')->nullable();
            $table->timestamps();
            $table->softDeletes();

            $table->index(['parent_id', 'type']);
            $table->index('status');
        });

        Schema::create('organization_users', function (Blueprint $table) {
            $table->id();
            $table->foreignId('organization_id')->constrained()->cascadeOnDelete();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->enum('role', ['agency_admin', 'client_admin', 'client_user']);
            $table->timestamps();

            $table->unique(['organization_id', 'user_id']);
            $table->index('user_id');
        });

        Schema::create('organization_invitations', function (Blueprint $table) {
            $table->id();
            $table->char('public_id', 26)->unique();
            $table->foreignId('organization_id')->constrained()->cascadeOnDelete();
            $table->string('email');
            $table->enum('role', ['agency_admin', 'client_admin', 'client_user']);
            // Only a SHA-256 hash of the token is stored; the raw token is e-mailed.
            $table->char('token_hash', 64)->unique();
            $table->foreignId('invited_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('expires_at');
            $table->timestamp('accepted_at')->nullable();
            $table->timestamp('revoked_at')->nullable();
            $table->timestamps();

            $table->index(['organization_id', 'email']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('organization_invitations');
        Schema::dropIfExists('organization_users');
        Schema::dropIfExists('organizations');
    }
};
