<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('websites', function (Blueprint $table) {
            $table->id();
            $table->char('public_id', 26)->unique();
            $table->foreignId('organization_id')->constrained()->cascadeOnDelete();
            $table->string('name', 160);
            $table->string('primary_domain', 253);
            // Public identifier embedded in the tracking snippet. It only grants
            // write access to this site's collection endpoint.
            $table->char('site_key', 32)->unique();
            $table->enum('status', ['pending', 'active', 'paused'])->default('pending');
            $table->string('timezone', 64)->default('UTC');
            $table->json('settings')->nullable();
            $table->timestamp('last_event_at')->nullable();
            $table->timestamps();
            $table->softDeletes();

            $table->index(['organization_id', 'status']);
            $table->unique(['organization_id', 'primary_domain']);
        });

        Schema::create('tracking_domains', function (Blueprint $table) {
            $table->id();
            $table->foreignId('organization_id')->constrained()->cascadeOnDelete();
            $table->foreignId('website_id')->constrained()->cascadeOnDelete();
            $table->string('domain', 253);
            $table->boolean('include_subdomains')->default(true);
            $table->timestamps();

            $table->unique(['website_id', 'domain']);
            $table->index(['organization_id', 'website_id']);
        });

        Schema::create('tracking_installations', function (Blueprint $table) {
            $table->id();
            $table->foreignId('organization_id')->constrained()->cascadeOnDelete();
            $table->foreignId('website_id')->constrained()->cascadeOnDelete();
            $table->timestamp('checked_at');
            $table->boolean('sdk_detected')->default(false);
            $table->string('sdk_version', 20)->nullable();
            $table->boolean('pixel_detected')->default(false);
            $table->boolean('gtag_detected')->default(false);
            $table->enum('status', ['healthy', 'warning', 'critical']);
            $table->json('details')->nullable();
            $table->timestamps();

            $table->index(['website_id', 'checked_at']);
            $table->index(['organization_id', 'status']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('tracking_installations');
        Schema::dropIfExists('tracking_domains');
        Schema::dropIfExists('websites');
    }
};
