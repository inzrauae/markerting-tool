<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('api_keys', function (Blueprint $table) {
            $table->id();
            $table->char('public_id', 26)->unique();
            $table->foreignId('organization_id')->constrained()->cascadeOnDelete();
            $table->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->string('name', 120);
            // Non-secret lookup part shown in the UI (e.g. "aiq_live_AB12CD34").
            $table->string('prefix', 32)->unique();
            // SHA-256 of the full key. The plaintext is shown exactly once.
            $table->char('key_hash', 64)->unique();
            $table->json('abilities');
            $table->json('allowed_ips')->nullable();
            $table->timestamp('last_used_at')->nullable();
            $table->timestamp('expires_at')->nullable();
            $table->timestamp('revoked_at')->nullable();
            $table->timestamps();

            $table->index(['organization_id', 'revoked_at']);
        });

        // Append-only. Application code never updates or deletes rows here.
        Schema::create('audit_logs', function (Blueprint $table) {
            $table->id();
            // Null for platform-level events (e.g. super-admin actions on the platform).
            $table->foreignId('organization_id')->nullable()->constrained()->nullOnDelete();
            $table->enum('actor_type', ['user', 'api_key', 'system']);
            $table->unsignedBigInteger('actor_id')->nullable();
            $table->string('action', 100);
            $table->string('subject_type', 100)->nullable();
            $table->unsignedBigInteger('subject_id')->nullable();
            $table->json('changes')->nullable();
            $table->string('ip_address', 45)->nullable();
            $table->string('user_agent', 255)->nullable();
            $table->timestamp('created_at')->useCurrent();

            $table->index(['organization_id', 'created_at']);
            $table->index(['subject_type', 'subject_id']);
            $table->index(['action', 'created_at']);
            $table->index(['actor_type', 'actor_id']);
        });

        Schema::create('data_retention_policies', function (Blueprint $table) {
            $table->id();
            $table->foreignId('organization_id')->unique()->constrained()->cascadeOnDelete();
            $table->unsignedSmallInteger('raw_event_days');
            $table->unsignedSmallInteger('visitor_profile_days');
            // Null keeps aggregated (non-personal) rollups indefinitely.
            $table->unsignedSmallInteger('aggregate_days')->nullable();
            $table->boolean('anonymize_instead_of_delete')->default(false);
            $table->foreignId('updated_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamps();
        });

        Schema::create('feature_flags', function (Blueprint $table) {
            $table->id();
            $table->string('key', 100)->unique();
            $table->string('description')->nullable();
            $table->boolean('enabled')->default(false);
            // Overrides, e.g. {"organizations":["01J..."],"plans":["enterprise"]}
            $table->json('rules')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('feature_flags');
        Schema::dropIfExists('data_retention_policies');
        Schema::dropIfExists('audit_logs');
        Schema::dropIfExists('api_keys');
    }
};
