<?php

declare(strict_types=1);

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Production-safe: only reference data. Demo data is opt-in:
     *   php artisan db:seed --class=DemoSeeder
     */
    public function run(): void
    {
        $this->call(SubscriptionPlanSeeder::class);
    }
}
