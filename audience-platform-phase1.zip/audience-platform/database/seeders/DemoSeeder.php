<?php

declare(strict_types=1);

namespace Database\Seeders;

use App\Enums\OrganizationRole;
use App\Models\OrganizationMembership;
use App\Models\SubscriptionPlan;
use App\Models\User;
use App\Models\Website;
use App\Services\Tenancy\OrganizationProvisioner;
use App\Support\Tenancy\TenantContext;
use Illuminate\Database\Seeder;
use RuntimeException;

/**
 * Local development accounts. Refuses to run in production.
 *
 *   agency@example.com / password  → agency admin of "Demo Agency"
 *   client@example.com / password  → client admin of "Lanka Builders"
 *
 * Websites are created without any tracking data; nothing is fabricated.
 */
class DemoSeeder extends Seeder
{
    public function run(OrganizationProvisioner $provisioner, TenantContext $tenant): void
    {
        if (app()->isProduction()) {
            throw new RuntimeException('DemoSeeder must not run in production.');
        }

        $this->call(SubscriptionPlanSeeder::class);

        $agencyAdmin = User::query()->firstOrCreate(
            ['email' => 'agency@example.com'],
            ['name' => 'Demo Agency Admin', 'password' => 'password'],
        );
        $agencyAdmin->forceFill(['email_verified_at' => now()])->save();

        if ($agencyAdmin->memberships()->exists()) {
            $this->command?->info('Demo data already present; skipping.');

            return;
        }

        ['agency' => $agency] = $provisioner->registerAccount($agencyAdmin, 'Demo Agency', true, ['timezone' => 'Asia/Colombo']);

        // The default trial plan allows one client; the demo needs two.
        $agency->subscriptions()->update([
            'subscription_plan_id' => SubscriptionPlan::query()->where('code', 'agency')->value('id'),
        ]);

        foreach (['Lanka Builders' => 'lankabuilders.example', 'Ceylon Interiors' => 'ceyloninteriors.example'] as $name => $domain) {
            $client = $provisioner->createClient($agency, $name, ['timezone' => 'Asia/Colombo', 'special_ad_category' => null]);

            $tenant->runAs($client, function () use ($name, $domain): void {
                Website::query()->create([
                    'name' => $name.' website',
                    'primary_domain' => $domain,
                    'timezone' => 'Asia/Colombo',
                    'status' => Website::STATUS_PENDING,
                ]);
            });

            if ($name === 'Lanka Builders') {
                $clientAdmin = User::query()->firstOrCreate(
                    ['email' => 'client@example.com'],
                    ['name' => 'Demo Client Admin', 'password' => 'password'],
                );
                $clientAdmin->forceFill(['email_verified_at' => now()])->save();

                OrganizationMembership::query()->firstOrCreate(
                    ['organization_id' => $client->getKey(), 'user_id' => $clientAdmin->getKey()],
                    ['role' => OrganizationRole::ClientAdmin],
                );
            }
        }
    }
}
