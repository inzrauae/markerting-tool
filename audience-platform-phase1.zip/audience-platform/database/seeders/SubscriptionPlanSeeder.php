<?php

declare(strict_types=1);

namespace Database\Seeders;

use App\Models\SubscriptionPlan;
use Illuminate\Database\Seeder;

/**
 * Starting limits for the four plans. These are DATA: super admins change
 * them through the admin API without a deploy. Prices are intentionally left
 * empty: set them per currency in the admin console before taking payments.
 * The seeder never overwrites a plan that already exists.
 */
class SubscriptionPlanSeeder extends Seeder
{
    public function run(): void
    {
        $plans = [
            'starter' => ['Starter', 10, [
                'websites' => 1, 'clients' => 1, 'users' => 3,
                'monthly_visitors' => 10_000, 'monthly_events' => 250_000,
                'connected_platforms' => 2, 'ai_analyses' => 100,
                'audience_activations' => 3, 'reports' => 5,
            ]],
            'professional' => ['Professional', 20, [
                'websites' => 5, 'clients' => 3, 'users' => 10,
                'monthly_visitors' => 100_000, 'monthly_events' => 2_500_000,
                'connected_platforms' => 6, 'ai_analyses' => 1_000,
                'audience_activations' => 20, 'reports' => 50,
            ]],
            'agency' => ['Agency', 30, [
                'websites' => 50, 'clients' => 50, 'users' => 100,
                'monthly_visitors' => 1_000_000, 'monthly_events' => 25_000_000,
                'connected_platforms' => 100, 'ai_analyses' => 10_000,
                'audience_activations' => 500, 'reports' => 1_000,
            ]],
            'enterprise' => ['Enterprise', 40, [
                'websites' => null, 'clients' => null, 'users' => null,
                'monthly_visitors' => null, 'monthly_events' => null,
                'connected_platforms' => null, 'ai_analyses' => null,
                'audience_activations' => null, 'reports' => null,
            ]],
        ];

        foreach ($plans as $code => [$name, $order, $limits]) {
            SubscriptionPlan::query()->firstOrCreate(
                ['code' => $code],
                [
                    'name' => $name,
                    'is_active' => true,
                    'limits' => $limits,
                    'prices' => null,
                    'features' => ['white_label' => in_array($code, ['agency', 'enterprise'], true)],
                    'sort_order' => $order,
                ],
            );
        }
    }
}
