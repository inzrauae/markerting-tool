# AI (Phase 7 design)

## Principle

**Numbers come from code; words come from the model.** Metrics, scores, audience membership, lifts, significance and attribution are deterministic. The model classifies, groups, names, explains and recommends, and only from evidence it is given.

## Provider

`App\Domain\Ai\AiProvider` interface, implemented with the Laravel AI SDK (Laravel 13) and configured for Anthropic Claude through `AI_PROVIDER`, `ANTHROPIC_API_KEY` and `AI_MODEL`. Every call is logged to `ai_requests` (organization, purpose, model, tokens, latency, outcome) for metering, plan limits (`ai_analyses`) and the admin AI-usage view.

## Evidence contract

1. `EvidenceBuilder` (deterministic SQL) produces an evidence pack:
   ```json
   [{"id":"m1","metric":"lead_rate","segment":"pricing_visitors","value":0.071,"n":1840},
    {"id":"m2","metric":"lead_rate","segment":"all_visitors","value":0.017,"n":24820}]
   ```
2. The model must return strict JSON:
   ```json
   {"title":"…","insight":"…","evidence_refs":["m1","m2"],"confidence":"high|medium|low",
    "recommended_action":"…","expected_objective":"…"}
   ```
3. `RecommendationValidator` rejects any output that:
   - cites an evidence ID that wasn't supplied;
   - contains a number not derivable from the cited evidence (every numeric token must match a value, or a ratio/difference of cited values, after rounding);
   - claims more confidence than the sample rule allows (e.g. `high` needs n ≥ 400 per arm and p < 0.01);
   - mentions sensitive categories (health, religion, ethnicity, sexuality, politics and so on).
4. When thresholds aren't met, the system returns **"Insufficient data"** and never calls the model.

## Uses

| Feature | Input | Output |
|---|---|---|
| Intent classification | Visitor feature vector + deterministic score | One of: Informational, Research, Commercial, High Commercial Intent, Transactional, Ready To Buy, Existing Customer, Returning Customer, Low Intent, Unqualified |
| Search-query intent | Internal search queries, GSC queries | Intent class + topic cluster |
| Audience discovery | Candidate segments that passed statistics (min size, BH-corrected two-proportion z-test) | Name, explanation, recommendation |
| Recommendations | Evidence packs (audiences, funnels, campaigns) | Recommendation records (`ai_recommendations`) |
| Analyst chat | User question → fixed set of read-only, tenant-scoped query tools | Answer citing tool results, or "Insufficient data" |
| Competitor hypotheses | Public page topics, keyword-provider data | Audience hypotheses explicitly labelled as hypotheses |

## Guardrails

- The analyst cannot run free-form SQL. Its tools are typed, tenant-scoped and capped in row count.
- Prompts include a policy block: no individual identification, no sensitive inference, no fabricated numbers.
- Nothing the AI proposes is activated on an ad platform without human approval.
- Tests in `tests/Feature/Ai` (Phase 7) feed the validator fabricated numbers and invented evidence IDs and assert rejection.
