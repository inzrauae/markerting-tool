# API (v1)

Base URL: `https://<host>/api/v1`. JSON in and out, snake_case, ISO-8601 UTC timestamps. IDs are ULID `public_id`s; internal numeric IDs are never exposed.

## Authentication

| Client | Method |
|---|---|
| Dashboard SPA (same site) | Sanctum cookie session: `GET /sanctum/csrf-cookie`, then `POST /auth/login`. Send `X-XSRF-TOKEN` on writes. |
| Scripts acting as a user | `POST /auth/tokens` → `Authorization: Bearer <token>` (30-day expiry) |
| Server-to-server integrations | Organization API key → `Authorization: Bearer aiq_live_…` |

## Selecting the tenant

User-authenticated requests to tenant data send `X-Organization-Id: <organization public id>`. Organization-management routes take the organization from the URL instead. API keys are pinned to their organization and ignore the header.

| Status | Meaning |
|---|---|
| 400 | No organization selected |
| 403 | You cannot access that organization (same response whether or not it exists), it is suspended, or your role lacks the permission |
| 404 | The record doesn't exist **in the selected organization** |
| 422 | Validation failed, or an agency was selected for client-owned data |
| 429 | Rate limited |

Errors: `{"message": "...", "errors": {"field": ["..."]}}`.

Lists use cursor pagination: `{"data": [...], "links": {...}, "meta": {"next_cursor": "...", "per_page": 50}}`. Pass `?cursor=` to continue.

## Endpoints (Phase 1)

### Auth

```http
POST /auth/register
{"name":"Nimal Perera","email":"nimal@example.com","password":"…","password_confirmation":"…",
 "organization_name":"Lanka Builders","account_type":"business","timezone":"Asia/Colombo"}
→ 201 {"user":{…},"organizations":[…],"default_organization_id":"01k…"}
```

`account_type`: `business` creates an agency plus one client with the same name; `agency` creates only the agency. New accounts start a trial of the default plan.

```http
POST /auth/tokens        {"email":"…","password":"…","device_name":"ci"}  → 201 {"token":"1|…","expires_at":"…"}
DELETE /auth/tokens/current                                                → 204
POST /auth/login         {"email":"…","password":"…"}   (SPA only)         → 200
POST /auth/logout                                                          → 204
GET  /me   → {"user":{…},"organizations":[{"id","type","name","role","permissions":[…]}, …]}
```

Login endpoints allow 5 attempts per minute per e-mail and IP.

### Organizations

```http
GET   /organizations?type=client&search=lanka
GET   /organizations/{org}
PATCH /organizations/{org}            {"name","timezone","currency","special_ad_category"}
POST  /organizations/{agency}/clients {"name","timezone","currency","special_ad_category"}   (agency admins)
GET   /organizations/{org}/audit-logs?action=website.&from=2026-10-01&to=2026-10-08
```

`special_ad_category`: `housing | employment | credit | financial_products | social_issues | null`. Ad platforms restrict custom-audience retargeting in these categories, and the activation flow (Phase 6) warns accordingly.

### Members and invitations

```http
GET    /organizations/{org}/members
PATCH  /organizations/{org}/members/{user}       {"role":"client_admin"}
DELETE /organizations/{org}/members/{user}
GET    /organizations/{org}/invitations
POST   /organizations/{org}/invitations          {"email":"…","role":"client_user"}  → 201 (e-mail sent)
DELETE /organizations/{org}/invitations/{invitation}
POST   /invitations/accept                       {"token":"…"}                          (signed in)
POST   /invitations/accept                       {"token":"…","name":"…","password":"…","password_confirmation":"…"}  (new account)
```

Agencies hold `agency_admin`; clients hold `client_admin` or `client_user`. Nobody can grant a role above their own, and an agency always keeps at least one admin.

### Websites (header: `X-Organization-Id` = a client)

```http
GET    /websites?status=active
POST   /websites  {"name":"Main site","primary_domain":"https://www.example.lk","additional_domains":["shop.example.lk"]}
GET    /websites/{website}
PATCH  /websites/{website}  {"name","status":"active|paused","timezone","additional_domains":[…]}
DELETE /websites/{website}
POST   /websites/{website}/rotate-key
```

Domains are normalised to bare hostnames. The response includes `site_key` and a ready-to-paste `tracking_snippet`. The primary domain cannot be changed; add a domain or create a new website instead.

### API keys (header: `X-Organization-Id` = a client)

```http
GET    /api-keys?include_revoked=1
POST   /api-keys {"name":"CRM sync","abilities":["events:write"],"allowed_ips":["203.0.113.0/24"],"expires_at":"2027-01-01"}
→ 201 {"data":{…,"prefix":"aiq_live_ab12cd34"},"key":"aiq_live_ab12cd34_…","notice":"Store this key now…"}
DELETE /api-keys/{key}
GET    /key            (authenticated with the API key itself: shows its organization and abilities)
```

Abilities: `events:write`, `conversions:write`, `visitors:read`, `audiences:read`, `reports:read`, `websites:read`.

### Data retention (header: `X-Organization-Id` = a client)

```http
GET /data-retention-policy
PUT /data-retention-policy {"raw_event_days":90,"visitor_profile_days":365,"aggregate_days":null,"anonymize_instead_of_delete":false}
```

Presets are 30/90/180/365 days; any value from 1 to 1095 is accepted as a custom policy.

### Super admin

```http
GET   /admin/organizations?type=agency&status=active&search=
PATCH /admin/organizations/{org}/status   {"status":"suspended","reason":"…"}   (an agency's clients follow)
GET   /admin/plans
PATCH /admin/plans/{code}  {"limits":{"websites":10},"prices":{"LKR":{"month":990000}}}
```
