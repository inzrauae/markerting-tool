# Database Design

MySQL 8.0+, InnoDB, `utf8mb4_unicode_ci`. All timestamps are stored in UTC.

## Conventions

- **Primary keys:** `BIGINT UNSIGNED AUTO_INCREMENT` internally. Resources exposed through the API also have a `public_id` ULID (`CHAR(26)`, unique), so sequential IDs never leak counts across tenants.
- **Tenant column:** every tenant-owned table has `organization_id` (the *client* org that owns the data), and it leads composite indexes: `(organization_id, …)`.
- **Soft deletes** on user-managed configuration (organizations, websites, audiences, integrations, reports). Never on high-volume event tables.
- **Secrets** (OAuth tokens, webhook secrets) are `TEXT` columns holding Laravel-encrypted ciphertext.
- **Event tables** (`page_views`, `events`) are partitioned by month on `occurred_at`, so they have **no foreign keys** (a MySQL restriction) and their primary key includes the partition column.

## Deviations from the brief's table list

| Brief | Implemented as | Why |
|---|---|---|
| `sessions` | `visitor_sessions` | Laravel reserves `sessions` for HTTP sessions. Using a distinct name avoids a collision and confusion. HTTP sessions use Redis. |
| `webhooks` | `webhook_endpoints` + `webhook_deliveries` + `inbound_webhook_receipts` | Separates subscription config, outbound delivery log and inbound idempotency. |
| `ai_scores` | `visitor_scores` (current) + `visitor_score_history` | Scores are deterministic, not AI. The name reflects that. |
| `event_properties` | JSON `properties` column on `events` + `event_definitions` | An EAV table at hundreds of millions of rows is costly. JSON with generated columns for hot keys works better. `event_definitions` holds the custom-event schema. |
| (added) | `scoring_models`, `page_rules`, `visitor_features`, `stats_*` rollups, `ai_requests`, `integration_tokens`, `organization_invitations`, `feature_flags` | Needed by the architecture. |

## ERD (core)

```mermaid
erDiagram
  organizations ||--o{ organizations : "agency has clients (parent_id)"
  organizations ||--o{ organization_users : has
  users ||--o{ organization_users : belongs
  organizations ||--o{ organization_invitations : has
  organizations ||--o{ websites : owns
  websites ||--o{ tracking_domains : allows
  websites ||--o{ tracking_installations : "health checks"
  organizations ||--o{ api_keys : issues
  organizations ||--o{ audit_logs : records
  organizations ||--|| data_retention_policies : configures
  organizations ||--o{ subscriptions : "agency pays"
  subscription_plans ||--o{ subscriptions : defines
  organizations ||--o{ usage_metrics : meters

  websites ||--o{ visitors : tracks
  visitors ||--o{ visitor_sessions : has
  visitor_sessions ||--o{ page_views : contains
  visitor_sessions ||--o{ events : contains
  visitors ||--o{ consent_records : grants
  visitors ||--o{ internal_searches : performs
  visitors ||--|| visitor_features : summarised
  visitors ||--|| visitor_scores : scored
  visitors ||--o{ conversions : converts
  conversions ||--o{ conversion_touches : attributed
  traffic_sources ||--o{ visitor_sessions : "acquired via"
  campaigns ||--o{ campaign_metrics : daily

  organizations ||--o{ audience_segments : defines
  audience_segments ||--o{ audience_rules : "rule tree"
  audience_segments ||--o{ audience_memberships : contains
  visitors ||--o{ audience_memberships : "member of"
  audience_segments ||--o{ audience_exports : "activated to"

  organizations ||--o{ integration_connections : connects
  integration_connections ||--o{ meta_ad_accounts : exposes
  integration_connections ||--o{ meta_pixels : exposes
  integration_connections ||--o{ google_ads_accounts : exposes
  integration_connections ||--o{ search_console_properties : exposes
  search_console_properties ||--o{ search_console_queries : daily
  search_console_properties ||--o{ search_console_pages : daily
  integration_connections ||--o{ crm_contacts : syncs

  organizations ||--o{ ai_recommendations : receives
  organizations ||--o{ alerts : raises
  organizations ||--o{ reports : generates
  organizations ||--o{ webhook_endpoints : subscribes
  webhook_endpoints ||--o{ webhook_deliveries : logs
  organizations ||--o{ competitors : watches
```

`meta_connections`, `google_connections`, `search_console_connections` and `crm_connections` from the brief are unified into `integration_connections(provider)` with provider-specific child tables. This keeps one OAuth/token code path behind the adapter interface.

---

## Phase 1 tables (implemented)

### organizations
| Column | Type | Notes |
|---|---|---|
| id | bigint PK | |
| public_id | char(26) | ULID, unique |
| type | enum(`agency`,`client`) | |
| parent_id | bigint null FK→organizations | required for `client`, null for `agency` |
| name | varchar(160) | |
| slug | varchar(180) | unique |
| status | enum(`active`,`suspended`) | |
| timezone | varchar(64) | default `UTC` |
| currency | char(3) | default `LKR` |
| special_ad_category | varchar(32) null | housing/credit/employment flag (affects activation) |
| branding | json null | logo path, colors (white label) |
| settings | json null | |
| created_at, updated_at, deleted_at | | |

Indexes: `(parent_id, type)`, `(status)`.

### users
Standard Laravel users plus `public_id`, `is_super_admin bool`, `last_login_at`, and `two_factor_*` (Phase 10). Unique `email`.

### organization_users
`organization_id` FK, `user_id` FK, `role enum(agency_admin, client_admin, client_user)`, timestamps. Unique `(organization_id, user_id)`; index `(user_id)`.

### organization_invitations
`organization_id`, `email`, `role`, `token_hash char(64)` unique, `invited_by` FK users, `expires_at`, `accepted_at`. Index `(organization_id, email)`.

### websites
| Column | Type | Notes |
|---|---|---|
| id, public_id | | |
| organization_id | FK→organizations (client) | |
| name | varchar(160) | |
| primary_domain | varchar(253) | |
| site_key | char(32) | unique, public (embedded in snippet) |
| status | enum(`pending`,`active`,`paused`) | |
| timezone | varchar(64) | |
| settings | json | bot filtering, consent mode, page-rule toggles |
| last_event_at | timestamp null | tracking health |
| timestamps, deleted_at | | |

Indexes: `(organization_id, status)`, unique `(organization_id, primary_domain)`.

### tracking_domains
`website_id` FK, `organization_id`, `domain varchar(253)`, `include_subdomains bool`. Unique `(website_id, domain)`.

### tracking_installations
`website_id`, `organization_id`, `checked_at`, `sdk_detected bool`, `sdk_version`, `pixel_detected bool`, `gtag_detected bool`, `status enum(healthy,warning,critical)`, `details json`. Index `(website_id, checked_at)`.

### api_keys
`organization_id`, `created_by` FK users, `name`, `prefix char(12)` unique, `key_hash char(64)` unique, `abilities json`, `allowed_ips json null`, `last_used_at`, `expires_at`, `revoked_at`, timestamps. Index `(organization_id, revoked_at)`.

### audit_logs (append-only)
`id`, `organization_id null` (null = platform-level), `actor_type enum(user,api_key,system)`, `actor_id`, `action varchar(100)`, `subject_type`, `subject_id`, `changes json null` (secrets are redacted), `ip varbinary(16)`, `user_agent varchar(255)`, `created_at`. Indexes `(organization_id, created_at)`, `(subject_type, subject_id)`, `(action, created_at)`. No updates or deletes from app code.

### data_retention_policies
`organization_id` unique, `raw_event_days int` (30/90/180/365/custom), `visitor_profile_days int`, `aggregate_days int null` (null = keep), `anonymize_instead_of_delete bool`, `updated_by`. Defaults come from the plan.

### subscription_plans
`code` unique (`starter`, `professional`, `agency`, `enterprise`), `name`, `is_active`, `limits json` (websites, monthly_visitors, monthly_events, connected_platforms, ai_analyses, activations, reports, users), `prices json` (per currency/interval: no hard-coded pricing in code), `features json`, `sort_order`.

### subscriptions
`organization_id` (agency), `subscription_plan_id`, `status enum(trialing,active,past_due,canceled)`, `provider`, `provider_ref`, `current_period_start`, `current_period_end`, `trial_ends_at`, `canceled_at`. Index `(organization_id, status)`.

### usage_metrics
`organization_id`, `metric varchar(50)`, `period_start date`, `quantity bigint`. Unique `(organization_id, metric, period_start)`. Incremented via Redis counters and flushed hourly.

### feature_flags
`key` unique, `enabled bool`, `rules json` (per org/plan overrides).

---

## Phase 2+ tables (designed, migrations in later phases)

### visitors
`id`, `organization_id`, `website_id`, `visitor_uid char(26)` (anonymous SDK id), `first_seen_at`, `last_seen_at`, `sessions_count`, `pageviews_count`, `engaged_seconds`, `first_source_id`, `last_source_id`, `country char(2) null`, `region varchar(80) null`, `device_category`, `consent_state enum(unknown,granted,denied,partial)`, `is_converted bool`, `converted_at`, `crm_contact_id null`. Unique `(website_id, visitor_uid)`; indexes `(organization_id, website_id, last_seen_at)` and `(website_id, is_converted, last_seen_at)`.

### visitor_sessions
`id`, `organization_id`, `website_id`, `visitor_id`, `session_uid`, `started_at`, `ended_at`, `landing_path`, `exit_path`, `referrer_host`, `traffic_source_id`, `utm_*` (5), `gclid`, `gbraid`, `wbraid`, `fbclid`, `browser`, `os`, `device_category`, `language`, `viewport_w/h`, `pageviews`, `events_count`, `engaged_seconds`, `is_bounce`, `is_bot`. Unique `(website_id, session_uid)`; indexes `(organization_id, website_id, started_at)`, `(visitor_id, started_at)`.

### page_views (partitioned monthly)
PK `(id, occurred_at)`. Columns: `organization_id`, `website_id`, `visitor_id`, `session_id`, `path varchar(512)`, `path_hash binary(16)`, `title`, `page_type enum(other,pricing,product,service,checkout,contact,blog)`, `referrer_path`, `engaged_seconds`, `max_scroll_pct`, `occurred_at`. Indexes `(website_id, occurred_at)`, `(visitor_id, occurred_at)`, `(website_id, path_hash, occurred_at)`.

### events (partitioned monthly)
PK `(id, occurred_at)`. `organization_id`, `website_id`, `visitor_id`, `session_id`, `event_uuid binary(16)` (dedup), `name varchar(64)`, `category enum(auto,custom,server)`, `path`, `properties json`, `value decimal(14,2) null`, `currency char(3) null`, `occurred_at`, `received_at`. Indexes `(website_id, name, occurred_at)`, `(visitor_id, occurred_at)`. Dedup is enforced in Redis plus a unique `(website_id, event_uuid, occurred_at)`.

### event_definitions
Custom event registry per website: `name`, `display_name`, `is_conversion`, `default_value`, `schema json`.

### consent_records
`organization_id`, `website_id`, `visitor_id`, `state`, `analytics bool`, `advertising bool`, `policy_version`, `source enum(sdk,cmp,api)`, `recorded_at`. Index `(visitor_id, recorded_at)`.

### internal_searches
`organization_id`, `website_id`, `visitor_id`, `session_id`, `query varchar(255)`, `query_normalized`, `result_count int null`, `path`, `intent_class null` (AI, Phase 7), `occurred_at`. Index `(website_id, occurred_at)`.

### traffic_sources
Normalised dimension: `organization_id`, `website_id`, `channel enum(organic_search,paid_search,paid_social,organic_social,email,referral,direct,whatsapp,other)`, `source`, `medium`, `campaign`. Unique `(website_id, channel, source, medium, campaign)`.

### page_rules
Per-website URL → page_type classification (`pattern`, `match enum(prefix,contains,regex)`, `page_type`, `priority`). Used at ingest.

### visitor_features / visitor_scores / visitor_score_history
`visitor_features`: one row per visitor of counters (pricing_views, product_views, service_views, distinct_products, searches, commercial_searches, whatsapp_clicks, phone_clicks, form_starts, form_submits, purchases, revenue, return_visits, days_since_last). `visitor_scores`: `intent_score`, `engagement_score`, `purchase_readiness_score`, `conversion_probability null`, `intent_class`, `explanation json`, `scoring_model_id`, `scored_at`. Index `(website_id, intent_score)`.

### scoring_models
Per org/website weights JSON, `version`, `is_active`.

### conversions / conversion_touches
`conversions`: `visitor_id`, `session_id`, `type enum(lead,purchase,signup,custom)`, `event_id`, `value`, `currency`, `crm_contact_id`, `occurred_at`. `conversion_touches`: `conversion_id`, `session_id`, `traffic_source_id`, `campaign_id`, `position`, and weights for `first`, `last`, `linear`, `position_based` and `data_driven` (null unless enough data).

### campaigns / campaign_metrics
`campaigns`: `organization_id`, `platform enum(meta,google_ads,other)`, `external_id`, `account_ref`, `name`, `status`, `objective`. Unique `(organization_id, platform, external_id)`. `campaign_metrics`: daily `spend, impressions, reach, clicks, leads, conversions, revenue, frequency`. Unique `(campaign_id, date)`. Derived CTR/CPC/CPA/ROAS are computed, not stored.

### audience_segments / audience_rules / audience_memberships / audience_exports
`audience_segments`: `name`, `description`, `kind enum(custom,predefined,discovered)`, `rule_tree json` (canonical AST), `website_id null` (null = all org websites), `requires_ad_consent bool`, `size_cached`, `refreshed_at`, `status`. `audience_rules`: flattened rule conditions for search/UI (derived from `rule_tree`). `audience_memberships`: `(audience_segment_id, visitor_id)` unique, `entered_at`, `exited_at null`, with index `(audience_segment_id, exited_at)`. `audience_exports`: `audience_segment_id`, `integration_connection_id`, `platform`, `destination_ref`, `external_audience_id`, `status enum(pending,active,error,paused)`, `last_synced_at`, `platform_size null`, `error`.

### integration_connections (+ provider children)
`organization_id`, `provider enum(meta,google,crm_hubspot,…)`, `external_account_id`, `scopes json`, `status enum(active,expired,revoked,error)`, `connected_by`, `last_synced_at`. `integration_tokens`: `integration_connection_id`, `access_token` (encrypted), `refresh_token` (encrypted), `expires_at`. Children: `meta_ad_accounts`, `meta_pixels`, `meta_campaigns` (view over `campaigns`), `google_ads_accounts`, `search_console_properties`, `search_console_queries` (`date, query, page, country, device, clicks, impressions, ctr, position`), `search_console_pages`, `crm_contacts` (hashed identifiers only plus a CRM reference).

### ai_recommendations / ai_requests
`ai_recommendations`: `organization_id`, `website_id`, `type`, `title`, `insight`, `evidence json` (evidence-pack rows), `confidence enum(low,medium,high)`, `recommended_action`, `expected_objective`, `status enum(proposed,accepted,dismissed,expired)`, `generated_by_model`. `ai_requests`: purpose, model, tokens in/out, latency, status (metering + admin).

### alerts / reports / webhooks / competitors
`alerts` (rule config + fired instances), `reports` (definition, schedule, last file path), `webhook_endpoints` (url, events, encrypted secret), `webhook_deliveries`, `inbound_webhook_receipts` (unique `(source, idempotency_key)`), `competitors`, `competitor_snapshots`.

### Rollups
`stats_daily_site`, `stats_daily_pages`, `stats_daily_sources`, `stats_hourly_site`, `stats_daily_audiences`: keyed `(website_id, date[, dimension_hash])`, written by idempotent upsert jobs.

## Partitioning and retention

```sql
-- example (created by migration in Phase 2)
ALTER TABLE events PARTITION BY RANGE (TO_DAYS(occurred_at)) (
  PARTITION p202610 VALUES LESS THAN (TO_DAYS('2026-11-01')),
  PARTITION pmax    VALUES LESS THAN MAXVALUE
);
```

A scheduled command `partitions:maintain` creates the next 3 months of partitions and drops partitions older than the platform-wide maximum retention. Tenant-specific shorter retention is enforced by the `ApplyRetentionPolicy` job with chunked deletes (`LIMIT 5000`) by `(organization_id, occurred_at)`.
