# Deployment

## Topologies

| Tier | When | Components |
|---|---|---|
| **Docker / VPS (recommended)** | Production at any scale | Nginx + PHP-FPM app containers, Horizon worker(s), scheduler, MySQL 8, Redis |
| **cPanel lite mode** | Small single-agency installs, low traffic | PHP 8.3, MySQL, cron only; database queue; no Horizon |

Horizontal scaling: app containers are stateless (sessions, cache and queues are in Redis), so you can add instances behind a load balancer. Run exactly one scheduler. Scale Horizon by queue (`ingest` and `scoring` get the most workers from Phase 2).

## Docker

```bash
cp .env.example .env
# Fill in: APP_URL, DB_PASSWORD, REDIS_PASSWORD, and an APP_KEY generated with:
php -r "echo 'base64:'.base64_encode(random_bytes(32)).PHP_EOL;"
docker compose up -d --build
docker compose exec app php artisan migrate --force --seed
docker compose exec app php artisan aiq:super-admin you@example.com   # after registering
```

Services in `docker-compose.yml`: `app` (PHP-FPM), `web` (Nginx with the built assets, on :8080), `horizon`, `scheduler`, `mysql`, `redis`. `.env` is passed in as environment variables and is never baked into the image. Data persists in named volumes. Put TLS in front of `web` (a load balancer or a reverse proxy such as Caddy or Traefik).

## VPS (Ubuntu 24.04) without Docker

1. Install PHP 8.3 (fpm, mysql, mbstring, intl, redis, pcntl, xml, curl, zip), MySQL 8, Redis, Nginx, Node 22 and Composer.
2. Deploy the code, then:
   ```bash
   composer install --no-dev --optimize-autoloader
   npm ci && npm run build
   php artisan migrate --force --seed
   php artisan config:cache route:cache view:cache event:cache
   ```
3. Nginx: point `root` at `public/` and pass `index.php` to PHP-FPM. Use the `try_files $uri $uri/ /index.php?$query_string;` rule.
4. Supervisor: `php artisan horizon` (one program per server; `stopwaitsecs=3600`).
5. Cron: `* * * * * cd /srv/app && php artisan schedule:run >> /dev/null 2>&1`.
6. After each deploy: `php artisan horizon:terminate` so workers load new code.

## cPanel lite mode

Limitations: no Horizon (it needs `pcntl` and long-running processes), lower ingestion capacity, and no Redis on most shared hosts.

1. `.env`: `QUEUE_CONNECTION=database`, `CACHE_STORE=database`, `SESSION_DRIVER=database`.
2. Install Composer dependencies, ignoring Horizon's extensions if the host lacks them: `composer install --no-dev --ignore-platform-req=ext-pcntl --ignore-platform-req=ext-posix`.
3. Point the domain's document root at `public/`.
4. Add two cron jobs:
   ```
   * * * * * php /home/USER/app/artisan schedule:run >> /dev/null 2>&1
   * * * * * php /home/USER/app/artisan queue:work --stop-when-empty --max-time=55 >> /dev/null 2>&1
   ```
5. Build assets locally (`npm run build`) and upload `public/build` if the host has no Node.

Move to a VPS before traffic grows. Phase 2 ingestion relies on Redis buffering to absorb bursts.

## Production checklist

- `APP_ENV=production`, `APP_DEBUG=false`, HTTPS everywhere, `SESSION_SECURE_COOKIE=true`
- `SANCTUM_STATEFUL_DOMAINS` set to the dashboard host
- MySQL and Redis are not reachable from the internet, and Redis has a password
- Back up MySQL daily with point-in-time recovery, and test restores
- `APP_KEY` is stored in your secrets manager (losing it makes encrypted OAuth tokens unreadable)
- Mail is configured (invitations)
- Set plan prices in the admin console before taking payments
