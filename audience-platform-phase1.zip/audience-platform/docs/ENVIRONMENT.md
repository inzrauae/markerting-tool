# Environment variables

All configuration comes from `.env` (template: `.env.example`). Never commit `.env`.

## Application

| Variable | Purpose |
|---|---|
| `APP_NAME`, `APP_URL` | Display name; public base URL (used in e-mails and the default tracker URL) |
| `APP_ENV`, `APP_DEBUG` | `production` + `false` in production |
| `APP_KEY` | Encryption key (`php artisan key:generate`). Losing it makes encrypted OAuth tokens unreadable. |
| `APP_PREVIOUS_KEYS` | Old keys during a key rotation |
| `BCRYPT_ROUNDS` | Password hashing cost (12 default) |
| `LOG_*` | Logging; `LOG_STACK=daily` rotates files |

## Database / Redis / queues / sessions

| Variable | Purpose |
|---|---|
| `DB_CONNECTION=mysql`, `DB_HOST`, `DB_PORT`, `DB_DATABASE`, `DB_USERNAME`, `DB_PASSWORD` | Primary MySQL 8 |
| `DB_READ_HOST` | Optional read replica (dashboards, Phase 3) |
| `REDIS_CLIENT`, `REDIS_HOST`, `REDIS_PORT`, `REDIS_PASSWORD` | Redis (phpredis recommended) |
| `CACHE_STORE`, `CACHE_PREFIX` | `redis` in production |
| `QUEUE_CONNECTION` | `redis` (with Horizon) in production; `database` in cPanel lite mode |
| `SESSION_DRIVER`, `SESSION_LIFETIME`, `SESSION_ENCRYPT`, `SESSION_SECURE_COOKIE`, `SESSION_DOMAIN` | Dashboard sessions. `SESSION_SECURE_COOKIE=true` behind HTTPS. |
| `SESSION_TABLE` | `http_sessions` (only used with the database driver) |
| `SANCTUM_STATEFUL_DOMAINS` | Host(s) the dashboard is served from, e.g. `app.example.com` |

## Platform

| Variable | Default | Purpose |
|---|---|---|
| `AIQ_TRIAL_DAYS` | 14 | Trial length for new accounts |
| `AIQ_DEFAULT_PLAN` | `starter` | Plan code new accounts start on (must exist in `subscription_plans`) |
| `AIQ_DEFAULT_RAW_EVENT_RETENTION_DAYS` | 180 | Default raw-event retention for new clients |
| `AIQ_DEFAULT_VISITOR_RETENTION_DAYS` | 365 | Default visitor-profile retention |
| `AIQ_INVITATION_TTL_HOURS` | 72 | Invitation link lifetime |
| `AIQ_TRACKER_URL` | `${APP_URL}/tracker.js` | Where the snippet loads the SDK from (CDN or first-party subdomain) |

## AI (Phase 7)

| Variable | Purpose |
|---|---|
| `AI_PROVIDER` | `anthropic` (via Laravel AI SDK) |
| `ANTHROPIC_API_KEY` | Provider key |
| `AI_MODEL` | Model identifier; set explicitly, never hard-coded |
| `AI_MAX_TOKENS_PER_ORG_MONTH` | Optional per-organization budget |

## Meta (Phase 6)

`META_APP_ID`, `META_APP_SECRET`, `META_GRAPH_VERSION` (e.g. `v24.0`, pinned and upgraded deliberately), `META_OAUTH_REDIRECT_URI`, `META_WEBHOOK_VERIFY_TOKEN`. See [META-INTEGRATION.md](META-INTEGRATION.md).

## Google (Phase 5)

`GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET`, `GOOGLE_OAUTH_REDIRECT_URI`, `GOOGLE_ADS_DEVELOPER_TOKEN`, `GOOGLE_ADS_LOGIN_CUSTOMER_ID` (MCC, digits only), `GOOGLE_ADS_API_VERSION`, `SEARCH_CONSOLE_SYNC_DAYS`. See [GOOGLE-INTEGRATION.md](GOOGLE-INTEGRATION.md).

## CRM, mail, storage

`HUBSPOT_CLIENT_ID`/`SECRET` (later phase); `MAIL_*` (SMTP or provider); `FILESYSTEM_DISK` and `AWS_*` for S3-compatible storage of reports, exports and logos.
