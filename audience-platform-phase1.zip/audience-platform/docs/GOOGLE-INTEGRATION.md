# Google integration (Phase 5)

> Verified against Google's developer documentation on 2026-10-08. Re-check before starting Phase 5.

## Prerequisites (business owner's tasks)

1. A Google Cloud project with an OAuth client (Web). Enable the Google Ads API, Search Console API and Google Analytics Data API.
2. **OAuth consent screen verification.** The `adwords` scope (and possibly others) needs verification before production use by external users.
3. A **Google Ads developer token**. Apply for Basic access from your manager (MCC) account; test-account access works meanwhile.
4. For agencies: a manager account (`GOOGLE_ADS_LOGIN_CUSTOMER_ID`) linked to client accounts.

Scopes: `https://www.googleapis.com/auth/webmasters.readonly`, `https://www.googleapis.com/auth/adwords`, `https://www.googleapis.com/auth/analytics.readonly`.

## Search Console

- Data is **aggregate**: queries, pages, country and device with clicks, impressions, CTR and position. Rare queries are anonymised and omitted, history covers about 16 months, and per-request row limits apply.
- We sync daily into `search_console_queries`/`search_console_pages` and cluster queries into intent topics (Phase 7).
- The product must never present this as what an individual visitor searched.

## Google Ads

- Reporting: campaigns, ad groups, metrics and conversions via GAQL into `campaigns`/`campaign_metrics`.
- **Website remarketing** uses a rule-based user list:
  - `UserListService` → `UserList` with `RuleBasedUserListInfo` → `FlexibleRuleUserListInfo`, matching the custom parameter `aiq_segment` that tracker.js passes to the client's Google tag (ad consent only).
  - Prepopulation (`prepopulation_status = REQUESTED`) adds past visitors. Membership life span is set per list.
  - Google's policy forbids building audiences from sensitive information. Our segments are behavioural and commercial only.
- **Customer Match** (hashed e-mails/phones from CRM leads):
  - Needs account eligibility based on policy-compliance and payment history, and first-party data only.
  - Requires the `consent` field (`ad_user_data`, `ad_personalization`). Jobs with denied consent are rejected, and for EEA users missing consent counts as denied.
  - Normalise then SHA-256 hash: trim, lowercase, E.164 phones, and for Gmail drop dots and plus suffixes.
  - Google recommends at least 5,000 members. Membership life span is at most 540 days.
  - Since **1 April 2026**, accounts without recent Customer Match activity get `CUSTOMER_NOT_ALLOWLISTED_FOR_THIS_FEATURE` and must use the **Data Manager API**. The adapter supports both paths.
- EEA traffic needs Consent Mode v2 signals.

## GA4 (optional)

The GA4 Data API (`runReport`) is used for cross-checking traffic and conversions. It is not required.

## Configuration

`GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET`, `GOOGLE_OAUTH_REDIRECT_URI`, `GOOGLE_ADS_DEVELOPER_TOKEN`, `GOOGLE_ADS_LOGIN_CUSTOMER_ID`, `GOOGLE_ADS_API_VERSION` (pinned), `SEARCH_CONSOLE_SYNC_DAYS`. Calls go through `GoogleAdsAdapter`, `SearchConsoleAdapter` and `Ga4Adapter`.
