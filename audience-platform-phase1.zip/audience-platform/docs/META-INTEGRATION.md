# Meta integration (Phase 6)

> Verified against Meta's developer documentation on 2026-10-08. Meta changes requirements often: re-check every item below before starting Phase 6.

## What we build, and what we never do

**Build:** OAuth connection, listing ad accounts and pixels, campaign insights (spend, reach, frequency, results), Conversions API forwarding for events the client may lawfully send, and audience activation through **Website Custom Audiences** keyed on our segment signal.

**Never:** scrape Facebook or Instagram, try to identify anonymous visitors, upload data the client didn't collect with consent, or bypass Special Ad Category restrictions.

## Prerequisites (business owner's tasks)

1. A Meta developer app (type: Business) owned by your verified Business Manager.
2. **Business Verification** for that Business Manager.
3. **App Review** for Advanced Access to `ads_read`, `ads_management` and `business_management`. This is required to act on other businesses' ad accounts. Expect several weeks, so apply during Phase 2.
4. A privacy policy URL, data deletion instructions URL and app icon (needed for review).
5. Each client must accept the **Custom Audience Terms** in their ad account before audiences can be created.

## Activation flow

```
Visitor qualifies for segment (our audience engine, consented)
  → tracker.js fires fbq('trackCustom','AIQSegment',{aiq_segment:'<slug>'}) via the CLIENT's pixel
  → we create/maintain a Website Custom Audience:
      POST /act_<AD_ACCOUNT_ID>/customaudiences
      rule: event_sources=[{id:<PIXEL_ID>,type:"pixel"}], retention_seconds, filter: aiq_segment eq <slug>
  → Meta matches people and handles eligibility
  → audience status/size shown in our UI as reported by Meta
```

Notes from the docs:

- Website Custom Audience rules can filter on custom data parameters exactly like URLs. Retention is limited: the API reference allows 1–180 days, the FAQ mentions 365, so verify before relying on either. Prefill of past activity is available.
- An audience can only be targeted once it reaches a minimum size that Meta does not publish. Our UI shows "Building / Ready / Too small" from Meta's response and never estimates.
- Up to 10,000 website custom audiences per ad account.
- Deleting an audience that an active campaign uses pauses that campaign, so the UI must warn first.

## Conversions API

- Send only events the client is entitled to send (e.g. a lead who submitted a form with consent). Hash identifiers with SHA-256 after normalisation, include `fbp`/`fbc` when present, and set `event_id` to deduplicate with the Pixel.
- The `action_source`, consent and data-processing options (e.g. Limited Data Use where applicable) must be set per client region.

## Special Ad Categories

Housing, employment, credit/financial products and social issues/politics restrict audience targeting and lookalikes. Construction and real-estate clients often fall under **housing**. Clients have a `special_ad_category` field, and when it is set the activation flow shows the restriction and does not promise delivery.

## Ad Library (competitor module, Phase 8)

The Ad Library API requires identity verification. As we understand it, broad commercial coverage exists only for ads delivered in the EU (DSA transparency), while elsewhere coverage is limited to social-issue, electoral and political ads. Verify this before promising Sri Lankan competitor ad insights.

## Configuration

`META_APP_ID`, `META_APP_SECRET`, `META_GRAPH_VERSION` (pinned, e.g. `v24.0`), `META_OAUTH_REDIRECT_URI`, `META_WEBHOOK_VERIFY_TOKEN`. Tokens are stored encrypted in `integration_tokens`. API calls go through `MetaAdapter` (implements `AdPlatformAdapter`), so Graph version changes stay in one class.
