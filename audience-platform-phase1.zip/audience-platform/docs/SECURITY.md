# Security

## Tenant isolation (defence in depth)

1. **Tenant context**: `ResolveTenant` selects the organization from the URL or `X-Organization-Id` header and checks it with `OrganizationAccess`. API keys pin the tenant to their own organization. `ClearTenantContext` resets it at the start and end of every request, and `TenantContext` is a scoped binding, so it never leaks between requests or queued jobs.
2. **Fail-closed global scope**: models using `BelongsToOrganization` match **nothing** when no tenant is set. Cross-tenant access must be explicit (`Model::withoutTenancy()`), so it is easy to find in code review (`grep withoutTenancy`).
3. **Write guard**: saving a tenant model whose `organization_id` differs from the active tenant throws `TenantException`.
4. **Policies**: every check requires the record to belong to the active tenant *and* the user's role to grant the permission.
5. **Tests**: `TenantIsolationTest` attacks every tenant route from another organization.

Allowed uses of `withoutTenancy()` in Phase 1: API key lookup during authentication, invitation lookup by token, plan-limit counting across an agency, and tests. Any new use needs a review comment.

## Authentication

- Passwords are hashed with bcrypt. Production password policy: minimum 10 characters, mixed case, numbers, and a check against known breaches (`uncompromised`).
- Login: 5 attempts per minute per e-mail + IP, and 30 per minute per IP. Failures are audit-logged.
- SPA: Sanctum cookie sessions (encrypted, `SESSION_SECURE_COOKIE=true` in production) with CSRF protection.
- Personal tokens expire after 30 days, and expired tokens are pruned daily.
- Super admin is a column that can only be set from the console. It is not fillable and has no API.

## API keys

Format `aiq_live_<8>_<40>`. Only SHA-256 is stored and compared in constant time. Keys support abilities, an IP/CIDR allowlist, expiry and revocation, and `last_used_at` is recorded at most once a minute. The plaintext is returned once at creation.

## Secrets

- `.env` only, never committed (`.gitignore`). `.env.example` contains no values.
- OAuth tokens (Phase 5–6) and webhook secrets are stored with Laravel `encrypted` casts (AES-256). Rotate `APP_KEY` by moving the old key to `APP_PREVIOUS_KEYS`.
- Invitation tokens and API keys are stored only as hashes.
- Invitation e-mails are queued, so the raw invitation token sits in the queue backend (Redis) until sent. Keep Redis private and password-protected.

## HTTP

`SecurityHeaders` sets `X-Content-Type-Options`, `X-Frame-Options: DENY`, `Referrer-Policy`, `Permissions-Policy` and `Cross-Origin-Opener-Policy`. It also sets HSTS on HTTPS and a strict CSP on HTML responses outside local development. JSON errors never include traces when `APP_DEBUG=false`.

## Input and output

All input goes through Form Requests. Queries use bound parameters. `LIKE` searches escape wildcards. React escapes output and the code does not use `dangerouslySetInnerHTML`. The snippet HTML is escaped server-side.

## Audit log

The audit log is append-only: the model refuses updates and deletes. It records auth events, membership and invitation changes, website, API key and retention changes, organization changes, super-admin tenant access and admin actions. Values in keys that look like secrets (password, token, secret, key…) are redacted.

## Privacy commitments (enforced in later phases)

There is no fingerprinting and no inference of sensitive characteristics. Consent states are `unknown`, `granted`, `denied` and `partial`, and ad signals are only sent with advertising consent. IPs are truncated before storage. Retention is enforced per tenant, and DSAR export/delete works by anonymous visitor ID.

## Reporting a vulnerability

Report vulnerabilities privately to the platform owner's security contact (configure before launch). Do not open public issues for security bugs.
