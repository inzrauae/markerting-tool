# Tracking (Phase 2 design)

Phase 1 provides websites, site keys, allowed domains and the snippet. This document fixes the Phase 2 contract so the snippet you install today keeps working.

## Snippet

```html
<script async src="https://app.example.com/tracker.js" data-site="SITE_KEY"></script>
```

`AIQ_TRACKER_URL` can point at a CDN or a first-party subdomain (e.g. `insights.client.lk` via CNAME), which keeps tracking first-party. It is never used to evade a visitor's consent choice.

## SDK (`tracker.js`)

- TypeScript compiled to ES2017. Target < 20 KB minified, async, no dependencies, never blocks rendering.
- IDs: `visitor_id` (ULID in a first-party cookie or localStorage, 13 months max) and `session_id` (30-minute inactivity window). Both are created **only** once analytics consent allows it. Before that, the SDK keeps an in-memory session ID only.
- Captured: page path and title, referrer host, UTM parameters (5), `gclid`/`gbraid`/`wbraid`/`fbclid`, device category, browser, OS, language, viewport, timestamp. Country/region is derived server-side from a truncated IP and the IP is then discarded.
- Not captured: form field values, keystrokes, full IP, or any fingerprinting surface (canvas, fonts, audio and the like).

### Automatic events

`page_view`, `session_start`, `scroll` (25/50/75/90%), `outbound_click`, `file_download`, `video_start`/`video_complete` (HTML5, YouTube iframe API), `form_start`/`form_submit` (field values are never read), `phone_click` (`tel:`), `email_click` (`mailto:`), `whatsapp_click` (`wa.me`, `api.whatsapp.com`), plus page-type events (`pricing_view`, `product_view`, `service_view`, `checkout_start`) based on the website's page rules. `purchase`, `lead` and `signup` come from the data layer or `track()`.

### Public API

```js
aiq('track', 'quote_request', { value: 25000, currency: 'LKR' });
aiq('consent', { analytics: true, advertising: false, policy_version: '2026-10' });
aiq('search', { query: 'house construction cost', results: 12 });   // internal site search
```

Internal search is also auto-detected from common query parameters (`q`, `s`, `search`, `query`), configurable per website.

### Consent

| State | Behaviour |
|---|---|
| `unknown` (default) | Configurable per website: `require_for_analytics` sends nothing; `require_for_ads` (default) sends cookieless aggregate page views only |
| `granted` | Full first-party analytics. Ad-platform segment signals only if `advertising` is true. |
| `partial` | Analytics yes, advertising no |
| `denied` | Nothing beyond an anonymous aggregate counter |

The SDK integrates with Google Consent Mode v2 and common CMPs by reading their state. It never overrides them.

## Collection endpoint

`POST /collect/v1` (no cookies, sessions or CSRF; CORS limited to the website's tracking domains).

1. Resolve `site_key` → website config from a Redis cache. Unknown or paused site → 204, dropped.
2. Check that `Origin` matches a tracking domain. Limit body to 32 KB and 20 events per batch. Rate limit per site and IP.
3. Validate the schema, filter bots (UA list plus behavioural rules, admin-configurable), and clamp timestamps (no future dates, and drop anything older than 72 h).
4. Push to Redis stream `ingest:{shard}` and return `202`.
5. Workers batch-insert into partitioned `events`/`page_views`, deduplicate on `event_uuid`, upsert visitors and sessions, and mark visitors for re-scoring.

## Ad-platform segment signal (Phase 6)

When a visitor has granted advertising consent **and** the client's own Meta Pixel / Google tag is on the page, the SDK fetches the visitor's current segment slugs and emits:

```js
fbq('trackCustom', 'AIQSegment', { aiq_segment: 'high_intent_pricing' });
gtag('event', 'aiq_segment', { aiq_segment: 'high_intent_pricing' });
```

Rule-based audiences on each platform match that parameter. No identity is transferred, and Meta/Google do all matching.

## Tracking health

The health checker reports SDK detection, events per hour, last event, Pixel/gtag presence, duplicate and invalid event rates, and consent configuration. Each check is shown as Healthy, Warning or Critical.
