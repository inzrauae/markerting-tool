# Troubleshooting

| Symptom | Cause | Fix |
|---|---|---|
| `400 Select an organization…` | No `X-Organization-Id` header on a tenant route | Send the organization's `id` (from `GET /me`) in the header |
| `422 This resource belongs to a client organization` | An agency is selected for websites, API keys or retention | Select one of the agency's clients |
| `403 You do not have access to this organization` | Wrong ID, no membership, or org belongs to another agency | Check `GET /me`; agency admins see their clients automatically |
| `403` on every request for one org | Organization (or its agency) is suspended | Super admin: `PATCH /api/v1/admin/organizations/{id}/status` |
| `404` for a website you can see in another client | IDs are scoped to the selected client | Switch organization |
| `Default subscription plan is missing` on register | Plans not seeded | `php artisan db:seed --class=SubscriptionPlanSeeder` |
| `422 … limit has been reached` | Plan limits (websites, clients, users) | Upgrade the plan or raise limits in `PATCH /admin/plans/{code}` |
| SPA login returns `419` / CSRF mismatch | Missing CSRF cookie or wrong stateful domain | Call `/sanctum/csrf-cookie` first; add the dashboard host to `SANCTUM_STATEFUL_DOMAINS`; check `SESSION_DOMAIN` |
| SPA login says "Session login is only available to the dashboard" | Request isn't recognised as stateful | Same as above. API clients should use `POST /auth/tokens`. |
| `Vite manifest not found` | Assets not built | `npm run build` (or `npm run dev` locally) |
| Invitations never arrive | Queue not running or mail misconfigured | Run Horizon / `queue:work`; check `MAIL_*`; failed jobs: `php artisan queue:failed` |
| Composer fails on `ext-pcntl` (Windows, cPanel) | Horizon needs pcntl/posix | `composer install --ignore-platform-req=ext-pcntl --ignore-platform-req=ext-posix` and use `queue:work` instead of Horizon |
| `TenantException: Refusing to write a record…` in a job | Job wrote into a different tenant than its context | Wrap the work in `TenantContext::runAs($organization, …)` for the record's own organization |
| Model queries return nothing in a command/job | No tenant set (fail-closed scope) | Set the tenant with `runAs()`; use `withoutTenancy()` only for reviewed system code |
| `MissingAttributeException` / lazy-loading errors in local | Strict mode is on outside production | Select the column or eager-load the relation |
