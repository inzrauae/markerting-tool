import { useState } from 'react';
import { NavLink, Outlet } from 'react-router';
import { useSession } from '@/lib/session';
import { roleLabel } from '@/lib/types';

/** Main navigation from the product brief. Modules ship phase by phase. */
const NAV: { label: string; to?: string; phase?: number }[] = [
    { label: 'Dashboard', to: '/' },
    { label: 'Visitors', phase: 3 },
    { label: 'Sessions', phase: 3 },
    { label: 'Audiences', phase: 4 },
    { label: 'Conversions', phase: 3 },
    { label: 'Campaigns', phase: 5 },
    { label: 'Integrations', phase: 5 },
    { label: 'AI Insights', phase: 7 },
    { label: 'Competitors', phase: 8 },
    { label: 'Reports', phase: 9 },
    { label: 'Tracking', to: '/tracking' },
    { label: 'Settings', to: '/settings' },
    { label: 'Billing', phase: 10 },
];

export default function AppLayout() {
    const { user, organizations, active, switchOrganization, logout } = useSession();
    const [menuOpen, setMenuOpen] = useState(false);

    const agencies = organizations.filter((o) => o.type === 'agency');
    const clients = organizations.filter((o) => o.type === 'client');

    return (
        <div className="flex min-h-full">
            {/* Sidebar */}
            <aside
                className={`${menuOpen ? 'flex' : 'hidden'} fixed inset-y-0 left-0 z-30 w-60 flex-col border-r border-slate-200 bg-white lg:static lg:flex`}
            >
                <div className="flex h-14 items-center gap-2 border-b border-slate-200 px-5">
                    <span className="grid h-7 w-7 place-items-center rounded-md bg-brand-600 text-xs font-bold text-white">IQ</span>
                    <span className="text-sm font-semibold text-slate-900">Audience IQ</span>
                </div>
                <nav className="flex-1 space-y-0.5 overflow-y-auto p-3" aria-label="Main">
                    {NAV.map((item) =>
                        item.to ? (
                            <NavLink
                                key={item.label}
                                to={item.to}
                                end={item.to === '/'}
                                onClick={() => setMenuOpen(false)}
                                className={({ isActive }) =>
                                    `flex items-center rounded-md px-3 py-2 text-sm font-medium ${
                                        isActive ? 'bg-brand-50 text-brand-700' : 'text-slate-700 hover:bg-slate-100'
                                    }`
                                }
                            >
                                {item.label}
                            </NavLink>
                        ) : (
                            <span
                                key={item.label}
                                className="flex cursor-default items-center justify-between rounded-md px-3 py-2 text-sm text-slate-400"
                                title={`Arrives in phase ${item.phase}`}
                            >
                                {item.label}
                                <span className="text-[10px] font-medium uppercase tracking-wide">Phase {item.phase}</span>
                            </span>
                        ),
                    )}
                </nav>
            </aside>

            <div className="flex min-w-0 flex-1 flex-col">
                {/* Top bar */}
                <header className="sticky top-0 z-20 flex h-14 items-center gap-3 border-b border-slate-200 bg-white/90 px-4 backdrop-blur sm:px-6">
                    <button
                        type="button"
                        className="rounded-md p-2 text-slate-600 hover:bg-slate-100 lg:hidden"
                        onClick={() => setMenuOpen((v) => !v)}
                        aria-label="Toggle navigation"
                    >
                        ☰
                    </button>

                    <label className="flex min-w-0 items-center gap-2">
                        <span className="sr-only">Organization</span>
                        <select
                            className="max-w-[16rem] truncate rounded-md border-0 bg-slate-50 py-1.5 pl-3 pr-8 text-sm font-medium text-slate-800 ring-1 ring-slate-200 focus:ring-2 focus:ring-brand-500"
                            value={active?.id ?? ''}
                            onChange={(e) => switchOrganization(e.target.value)}
                        >
                            {agencies.length > 0 && (
                                <optgroup label="Agencies">
                                    {agencies.map((o) => (
                                        <option key={o.id} value={o.id}>
                                            {o.name}
                                        </option>
                                    ))}
                                </optgroup>
                            )}
                            {clients.length > 0 && (
                                <optgroup label="Clients">
                                    {clients.map((o) => (
                                        <option key={o.id} value={o.id}>
                                            {o.name}
                                        </option>
                                    ))}
                                </optgroup>
                            )}
                        </select>
                    </label>
                    {active?.role && <span className="hidden text-xs text-slate-500 sm:inline">{roleLabel[active.role]}</span>}

                    <div className="ml-auto flex items-center gap-3">
                        <span className="hidden text-sm text-slate-600 md:inline">{user?.name}</span>
                        <button type="button" onClick={() => void logout()} className="text-sm font-medium text-slate-600 hover:text-slate-900">
                            Sign out
                        </button>
                    </div>
                </header>

                <main className="mx-auto w-full max-w-6xl flex-1 px-4 py-8 sm:px-6">
                    <Outlet />
                </main>
            </div>
        </div>
    );
}
