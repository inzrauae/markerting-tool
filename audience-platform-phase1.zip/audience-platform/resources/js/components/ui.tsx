import type { ButtonHTMLAttributes, InputHTMLAttributes, ReactNode, SelectHTMLAttributes } from 'react';

export function Button({
    variant = 'primary',
    className = '',
    ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: 'primary' | 'secondary' | 'ghost' }) {
    const styles = {
        primary: 'bg-brand-600 text-white hover:bg-brand-700 disabled:bg-brand-600/50',
        secondary: 'bg-white text-slate-700 ring-1 ring-slate-300 hover:bg-slate-50',
        ghost: 'text-slate-600 hover:bg-slate-100',
    }[variant];

    return (
        <button
            className={`inline-flex items-center justify-center gap-2 rounded-md px-3.5 py-2 text-sm font-medium transition focus:outline-none focus-visible:ring-2 focus-visible:ring-brand-500 focus-visible:ring-offset-2 disabled:cursor-not-allowed ${styles} ${className}`}
            {...props}
        />
    );
}

export function Field({ label, error, hint, children }: { label: string; error?: string; hint?: string; children: ReactNode }) {
    return (
        <label className="block">
            <span className="mb-1 block text-sm font-medium text-slate-700">{label}</span>
            {children}
            {hint && !error && <span className="mt-1 block text-xs text-slate-500">{hint}</span>}
            {error && <span className="mt-1 block text-xs text-red-600">{error}</span>}
        </label>
    );
}

const inputClass =
    'block w-full rounded-md border-0 bg-white px-3 py-2 text-sm text-slate-900 ring-1 ring-slate-300 placeholder:text-slate-400 focus:ring-2 focus:ring-brand-500 focus:outline-none';

export function Input(props: InputHTMLAttributes<HTMLInputElement>) {
    return <input className={inputClass} {...props} />;
}

export function Select(props: SelectHTMLAttributes<HTMLSelectElement>) {
    return <select className={inputClass} {...props} />;
}

export function Card({ title, actions, children }: { title?: string; actions?: ReactNode; children: ReactNode }) {
    return (
        <section className="rounded-lg bg-white shadow-sm ring-1 ring-slate-200">
            {(title || actions) && (
                <header className="flex items-center justify-between border-b border-slate-200 px-5 py-3.5">
                    {title && <h2 className="text-sm font-semibold text-slate-900">{title}</h2>}
                    {actions}
                </header>
            )}
            <div className="p-5">{children}</div>
        </section>
    );
}

export function Badge({ tone = 'slate', children }: { tone?: 'slate' | 'green' | 'amber' | 'blue'; children: ReactNode }) {
    const tones = {
        slate: 'bg-slate-100 text-slate-700',
        green: 'bg-emerald-50 text-emerald-700 ring-emerald-600/20',
        amber: 'bg-amber-50 text-amber-800 ring-amber-600/20',
        blue: 'bg-brand-50 text-brand-700 ring-brand-600/20',
    }[tone];
    return <span className={`inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium ring-1 ring-inset ring-transparent ${tones}`}>{children}</span>;
}

export function Alert({ children, tone = 'red' }: { children: ReactNode; tone?: 'red' | 'amber' | 'blue' }) {
    const tones = {
        red: 'bg-red-50 text-red-800 ring-red-200',
        amber: 'bg-amber-50 text-amber-900 ring-amber-200',
        blue: 'bg-brand-50 text-brand-700 ring-brand-100',
    }[tone];
    return <div className={`rounded-md px-4 py-3 text-sm ring-1 ${tones}`}>{children}</div>;
}

export function PageHeader({ title, description, actions }: { title: string; description?: string; actions?: ReactNode }) {
    return (
        <div className="mb-6 flex flex-wrap items-end justify-between gap-4">
            <div>
                <h1 className="text-xl font-semibold tracking-tight text-slate-900">{title}</h1>
                {description && <p className="mt-1 max-w-2xl text-sm text-slate-500">{description}</p>}
            </div>
            {actions}
        </div>
    );
}
