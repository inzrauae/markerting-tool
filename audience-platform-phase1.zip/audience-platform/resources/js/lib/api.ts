/**
 * Minimal API client for the first-party SPA.
 *
 * Auth is Sanctum's cookie session: we fetch /sanctum/csrf-cookie once, then
 * send the XSRF token header on every state-changing request. The active
 * organization travels in the X-Organization-Id header.
 */

export class ApiError extends Error {
    constructor(
        public status: number,
        message: string,
        public errors: Record<string, string[]> = {},
    ) {
        super(message);
    }

    firstError(): string {
        const first = Object.values(this.errors)[0];
        return first?.[0] ?? this.message;
    }
}

let activeOrganizationId: string | null = null;
let csrfReady = false;

export function setActiveOrganization(id: string | null): void {
    activeOrganizationId = id;
}

function readCookie(name: string): string | null {
    const match = document.cookie.split('; ').find((row) => row.startsWith(`${name}=`));
    return match ? decodeURIComponent(match.slice(name.length + 1)) : null;
}

async function ensureCsrf(): Promise<void> {
    if (csrfReady && readCookie('XSRF-TOKEN')) return;
    await fetch('/sanctum/csrf-cookie', { credentials: 'same-origin' });
    csrfReady = true;
}

type Method = 'GET' | 'POST' | 'PATCH' | 'PUT' | 'DELETE';

export async function api<T>(method: Method, path: string, body?: unknown): Promise<T> {
    if (method !== 'GET') await ensureCsrf();

    const headers: Record<string, string> = {
        Accept: 'application/json',
        'X-Requested-With': 'XMLHttpRequest',
    };
    if (body !== undefined) headers['Content-Type'] = 'application/json';
    if (activeOrganizationId) headers['X-Organization-Id'] = activeOrganizationId;
    const xsrf = readCookie('XSRF-TOKEN');
    if (xsrf) headers['X-XSRF-TOKEN'] = xsrf;

    const response = await fetch(`/api/v1${path}`, {
        method,
        headers,
        credentials: 'same-origin',
        body: body === undefined ? undefined : JSON.stringify(body),
    });

    if (response.status === 204) return undefined as T;

    const payload = await response.json().catch(() => ({}));

    if (!response.ok) {
        throw new ApiError(response.status, payload.message ?? `Request failed (${response.status})`, payload.errors ?? {});
    }

    return payload as T;
}

export const get = <T>(path: string) => api<T>('GET', path);
export const post = <T>(path: string, body?: unknown) => api<T>('POST', path, body ?? {});
export const patch = <T>(path: string, body: unknown) => api<T>('PATCH', path, body);
export const del = (path: string) => api<void>('DELETE', path);
