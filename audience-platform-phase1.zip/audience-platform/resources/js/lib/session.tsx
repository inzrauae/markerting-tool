import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import { ApiError, get, post, setActiveOrganization } from './api';
import type { Organization, User } from './types';

interface SessionState {
    status: 'loading' | 'guest' | 'authenticated';
    user: User | null;
    organizations: Organization[];
    active: Organization | null;
    switchOrganization: (id: string) => void;
    refresh: () => Promise<void>;
    logout: () => Promise<void>;
    can: (permission: string) => boolean;
}

const SessionContext = createContext<SessionState | null>(null);
const STORAGE_KEY = 'aiq.activeOrganization';

function storedOrganizationId(): string | null {
    try {
        return window.localStorage.getItem(STORAGE_KEY);
    } catch {
        return null;
    }
}

function storeOrganizationId(id: string): void {
    try {
        window.localStorage.setItem(STORAGE_KEY, id);
    } catch {
        // Private mode / blocked storage: the switcher still works for this tab.
    }
}

/** Prefer the stored choice, then the first client (where tracking data lives), then anything. */
function pickActive(organizations: Organization[], preferred: string | null): Organization | null {
    return (
        organizations.find((o) => o.id === preferred) ??
        organizations.find((o) => o.type === 'client') ??
        organizations[0] ??
        null
    );
}

export function SessionProvider({ children }: { children: ReactNode }) {
    const [status, setStatus] = useState<SessionState['status']>('loading');
    const [user, setUser] = useState<User | null>(null);
    const [organizations, setOrganizations] = useState<Organization[]>([]);
    const [activeId, setActiveId] = useState<string | null>(storedOrganizationId());

    const refresh = useCallback(async () => {
        try {
            const me = await get<{ user: User; organizations: Organization[] }>('/me');
            setUser(me.user);
            setOrganizations(me.organizations);
            setStatus('authenticated');
        } catch (error) {
            if (error instanceof ApiError && error.status === 401) {
                setUser(null);
                setOrganizations([]);
                setStatus('guest');
                return;
            }
            throw error;
        }
    }, []);

    useEffect(() => {
        void refresh();
    }, [refresh]);

    const active = useMemo(() => pickActive(organizations, activeId), [organizations, activeId]);

    // Keep the API client's tenant header in sync with the selection.
    useEffect(() => {
        setActiveOrganization(active?.id ?? null);
    }, [active]);

    const switchOrganization = useCallback((id: string) => {
        storeOrganizationId(id);
        setActiveId(id);
        setActiveOrganization(id);
    }, []);

    const logout = useCallback(async () => {
        await post('/auth/logout');
        setUser(null);
        setOrganizations([]);
        setStatus('guest');
    }, []);

    const can = useCallback((permission: string) => active?.permissions?.includes(permission) ?? false, [active]);

    const value = useMemo<SessionState>(
        () => ({ status, user, organizations, active, switchOrganization, refresh, logout, can }),
        [status, user, organizations, active, switchOrganization, refresh, logout, can],
    );

    return <SessionContext.Provider value={value}>{children}</SessionContext.Provider>;
}

export function useSession(): SessionState {
    const ctx = useContext(SessionContext);
    if (!ctx) throw new Error('useSession must be used inside <SessionProvider>');
    return ctx;
}
