export type Role = 'agency_admin' | 'client_admin' | 'client_user';

export interface User {
    id: string;
    name: string;
    email: string;
    email_verified: boolean;
    is_super_admin: boolean;
}

export interface Organization {
    id: string;
    type: 'agency' | 'client';
    name: string;
    slug: string;
    status: 'active' | 'suspended';
    timezone: string;
    currency: string;
    special_ad_category: string | null;
    parent_id?: string | null;
    role: Role | null;
    permissions: string[] | null;
}

export interface Website {
    id: string;
    name: string;
    primary_domain: string;
    site_key: string;
    status: 'pending' | 'active' | 'paused';
    timezone: string;
    tracking_domains?: { domain: string; include_subdomains: boolean }[];
    tracking_snippet: string;
    last_event_at: string | null;
    created_at: string;
}

export interface Member {
    user_id: string;
    name: string;
    email: string;
    role: Role;
    joined_at: string;
}

export interface Paginated<T> {
    data: T[];
    meta?: { next_cursor: string | null; prev_cursor: string | null };
}

export const roleLabel: Record<Role, string> = {
    agency_admin: 'Agency admin',
    client_admin: 'Client admin',
    client_user: 'Client user',
};
