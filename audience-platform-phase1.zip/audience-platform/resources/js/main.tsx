import { StrictMode, type ReactNode } from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter, Navigate, Route, Routes } from 'react-router';
import '../css/app.css';
import AppLayout from '@/components/AppLayout';
import { SessionProvider, useSession } from '@/lib/session';
import { AcceptInvitationPage, LoginPage, RegisterPage } from '@/pages/AuthPages';
import DashboardPage from '@/pages/DashboardPage';
import SettingsPage from '@/pages/SettingsPage';
import TrackingPage from '@/pages/TrackingPage';

function RequireAuth({ children }: { children: ReactNode }) {
    const { status } = useSession();
    if (status === 'loading') return <div className="p-8 text-sm text-slate-500">Loading…</div>;
    if (status === 'guest') return <Navigate to="/login" replace />;
    return <>{children}</>;
}

function GuestOnly({ children }: { children: ReactNode }) {
    const { status } = useSession();
    if (status === 'loading') return null;
    if (status === 'authenticated') return <Navigate to="/" replace />;
    return <>{children}</>;
}

const root = document.getElementById('root');

if (root) {
    createRoot(root).render(
        <StrictMode>
            <SessionProvider>
                <BrowserRouter>
                    <Routes>
                        <Route path="/login" element={<GuestOnly><LoginPage /></GuestOnly>} />
                        <Route path="/register" element={<GuestOnly><RegisterPage /></GuestOnly>} />
                        <Route path="/invitations/accept" element={<AcceptInvitationPage />} />
                        <Route element={<RequireAuth><AppLayout /></RequireAuth>}>
                            <Route index element={<DashboardPage />} />
                            <Route path="tracking" element={<TrackingPage />} />
                            <Route path="settings" element={<SettingsPage />} />
                        </Route>
                        <Route path="*" element={<Navigate to="/" replace />} />
                    </Routes>
                </BrowserRouter>
            </SessionProvider>
        </StrictMode>,
    );
}
