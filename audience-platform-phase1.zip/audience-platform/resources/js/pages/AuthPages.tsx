import { useState, type FormEvent, type ReactNode } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router';
import { Alert, Button, Field, Input, Select } from '@/components/ui';
import { ApiError, post } from '@/lib/api';
import { useSession } from '@/lib/session';

function AuthShell({ title, subtitle, children }: { title: string; subtitle?: ReactNode; children: ReactNode }) {
    return (
        <div className="flex min-h-full items-center justify-center px-4 py-12">
            <div className="w-full max-w-md">
                <div className="mb-8 text-center">
                    <span className="mx-auto mb-4 grid h-10 w-10 place-items-center rounded-lg bg-brand-600 text-sm font-bold text-white">IQ</span>
                    <h1 className="text-2xl font-semibold tracking-tight text-slate-900">{title}</h1>
                    {subtitle && <p className="mt-2 text-sm text-slate-500">{subtitle}</p>}
                </div>
                <div className="rounded-lg bg-white p-6 shadow-sm ring-1 ring-slate-200">{children}</div>
            </div>
        </div>
    );
}

function useForm<T extends Record<string, string>>(initial: T) {
    const [values, setValues] = useState(initial);
    const [errors, setErrors] = useState<Record<string, string[]>>({});
    const [message, setMessage] = useState<string | null>(null);
    const [busy, setBusy] = useState(false);

    const bind = (name: keyof T & string) => ({
        name,
        value: values[name],
        onChange: (e: { target: { value: string } }) => setValues((v) => ({ ...v, [name]: e.target.value })),
    });

    async function submit(action: () => Promise<void>) {
        setBusy(true);
        setErrors({});
        setMessage(null);
        try {
            await action();
        } catch (error) {
            if (error instanceof ApiError) {
                setErrors(error.errors);
                setMessage(Object.keys(error.errors).length ? null : error.message);
            } else {
                setMessage('Something went wrong. Please try again.');
            }
        } finally {
            setBusy(false);
        }
    }

    const error = (name: string) => errors[name]?.[0];

    return { values, bind, submit, error, message, busy };
}

export function LoginPage() {
    const { refresh } = useSession();
    const navigate = useNavigate();
    const form = useForm({ email: '', password: '' });

    const onSubmit = (e: FormEvent) => {
        e.preventDefault();
        void form.submit(async () => {
            await post('/auth/login', form.values);
            await refresh();
            navigate('/');
        });
    };

    return (
        <AuthShell title="Sign in" subtitle={<>No account? <Link className="font-medium text-brand-600" to="/register">Create one</Link></>}>
            <form onSubmit={onSubmit} className="space-y-4">
                {form.message && <Alert>{form.message}</Alert>}
                <Field label="E-mail" error={form.error('email')}>
                    <Input type="email" autoComplete="email" required {...form.bind('email')} />
                </Field>
                <Field label="Password" error={form.error('password')}>
                    <Input type="password" autoComplete="current-password" required {...form.bind('password')} />
                </Field>
                <Button type="submit" className="w-full" disabled={form.busy}>
                    {form.busy ? 'Signing in…' : 'Sign in'}
                </Button>
            </form>
        </AuthShell>
    );
}

export function RegisterPage() {
    const { refresh, switchOrganization } = useSession();
    const navigate = useNavigate();
    const form = useForm({
        name: '',
        email: '',
        password: '',
        password_confirmation: '',
        organization_name: '',
        account_type: 'business',
        timezone: Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC',
    });

    const onSubmit = (e: FormEvent) => {
        e.preventDefault();
        void form.submit(async () => {
            const result = await post<{ default_organization_id: string }>('/auth/register', form.values);
            switchOrganization(result.default_organization_id);
            await refresh();
            navigate('/');
        });
    };

    return (
        <AuthShell title="Create your account" subtitle={<>Already registered? <Link className="font-medium text-brand-600" to="/login">Sign in</Link></>}>
            <form onSubmit={onSubmit} className="space-y-4">
                {form.message && <Alert>{form.message}</Alert>}
                <Field label="Your name" error={form.error('name')}>
                    <Input autoComplete="name" required {...form.bind('name')} />
                </Field>
                <Field label="Work e-mail" error={form.error('email')}>
                    <Input type="email" autoComplete="email" required {...form.bind('email')} />
                </Field>
                <div className="grid gap-4 sm:grid-cols-2">
                    <Field label="Password" error={form.error('password')}>
                        <Input type="password" autoComplete="new-password" required {...form.bind('password')} />
                    </Field>
                    <Field label="Confirm password">
                        <Input type="password" autoComplete="new-password" required {...form.bind('password_confirmation')} />
                    </Field>
                </div>
                <Field label="Company name" error={form.error('organization_name')}>
                    <Input required {...form.bind('organization_name')} />
                </Field>
                <Field
                    label="Account type"
                    error={form.error('account_type')}
                    hint="Agencies manage several client businesses from one login."
                >
                    <Select {...form.bind('account_type')}>
                        <option value="business">A single business</option>
                        <option value="agency">An agency with clients</option>
                    </Select>
                </Field>
                <Button type="submit" className="w-full" disabled={form.busy}>
                    {form.busy ? 'Creating account…' : 'Create account'}
                </Button>
            </form>
        </AuthShell>
    );
}

export function AcceptInvitationPage() {
    const [params] = useSearchParams();
    const { status, refresh, switchOrganization } = useSession();
    const navigate = useNavigate();
    const token = params.get('token') ?? '';
    const form = useForm({ name: '', password: '', password_confirmation: '' });
    const signedIn = status === 'authenticated';

    const onSubmit = (e: FormEvent) => {
        e.preventDefault();
        void form.submit(async () => {
            const body = signedIn ? { token } : { token, ...form.values };
            const result = await post<{ organization: { id: string }; account_created: boolean }>('/invitations/accept', body);
            if (result.account_created) {
                navigate('/login');
                return;
            }
            switchOrganization(result.organization.id);
            await refresh();
            navigate('/');
        });
    };

    return (
        <AuthShell title="Join your team" subtitle={signedIn ? 'Accept the invitation with your current account.' : 'Create your account to accept the invitation.'}>
            <form onSubmit={onSubmit} className="space-y-4">
                {!token && <Alert>This link is missing its invitation token.</Alert>}
                {form.message && <Alert>{form.message}</Alert>}
                {form.error('token') && <Alert>{form.error('token')}</Alert>}
                {form.error('email') && <Alert>{form.error('email')}</Alert>}
                {!signedIn && (
                    <>
                        <Field label="Your name" error={form.error('name')}>
                            <Input required {...form.bind('name')} />
                        </Field>
                        <Field label="Password" error={form.error('password')}>
                            <Input type="password" autoComplete="new-password" required {...form.bind('password')} />
                        </Field>
                        <Field label="Confirm password">
                            <Input type="password" autoComplete="new-password" required {...form.bind('password_confirmation')} />
                        </Field>
                    </>
                )}
                <Button type="submit" className="w-full" disabled={form.busy || !token}>
                    Accept invitation
                </Button>
            </form>
        </AuthShell>
    );
}
