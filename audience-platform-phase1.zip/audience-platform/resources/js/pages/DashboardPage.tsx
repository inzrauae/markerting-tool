import { useEffect, useState } from 'react';
import { Link } from 'react-router';
import { Alert, Card, PageHeader } from '@/components/ui';
import { get } from '@/lib/api';
import { useSession } from '@/lib/session';
import type { Paginated, Website } from '@/lib/types';

/**
 * Until tracking data exists (Phase 2+) the dashboard is an honest setup
 * checklist: it never shows sample or invented metrics.
 */
export default function DashboardPage() {
    const { active } = useSession();
    const [websites, setWebsites] = useState<Website[] | null>(null);

    useEffect(() => {
        setWebsites(null);
        if (active?.type !== 'client') return;
        get<Paginated<Website>>('/websites')
            .then((r) => setWebsites(r.data))
            .catch(() => setWebsites([]));
    }, [active?.id, active?.type]);

    if (!active) {
        return <Alert tone="amber">You are not a member of any organization yet. Ask your agency to invite you.</Alert>;
    }

    if (active.type === 'agency') {
        return (
            <>
                <PageHeader title={active.name} description="Agency workspace. Tracking data belongs to clients: pick or create a client to work with its websites." />
                <Card title="Next step">
                    <p className="text-sm text-slate-600">
                        Use the organization switcher above to open a client, or{' '}
                        <Link to="/settings" className="font-medium text-brand-600">
                            create a client
                        </Link>
                        .
                    </p>
                </Card>
            </>
        );
    }

    const hasWebsite = (websites?.length ?? 0) > 0;
    const receivingData = websites?.some((w) => w.last_event_at !== null) ?? false;

    const steps = [
        { done: hasWebsite, label: 'Add your website', to: '/tracking' },
        { done: receivingData, label: 'Install the tracking snippet and receive the first event', to: '/tracking' },
        { done: false, label: 'Connect Google Search Console and Google Ads (Phase 5)' },
        { done: false, label: 'Connect Meta Pixel and Ads (Phase 6)' },
    ];

    return (
        <>
            <PageHeader
                title="Dashboard"
                description="Who should you advertise to, why, and what should you do next? Metrics appear here once your website starts sending events."
            />
            <div className="grid gap-6 lg:grid-cols-3">
                <div className="lg:col-span-2">
                    <Card title="Set up">
                        <ol className="space-y-3">
                            {steps.map((step, i) => (
                                <li key={step.label} className="flex items-start gap-3 text-sm">
                                    <span
                                        className={`mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-full text-[11px] font-semibold ${
                                            step.done ? 'bg-emerald-500 text-white' : 'bg-slate-100 text-slate-500'
                                        }`}
                                        aria-label={step.done ? 'Done' : 'To do'}
                                    >
                                        {step.done ? '✓' : i + 1}
                                    </span>
                                    {step.to && !step.done ? (
                                        <Link to={step.to} className="font-medium text-brand-600 hover:underline">
                                            {step.label}
                                        </Link>
                                    ) : (
                                        <span className={step.done ? 'text-slate-500 line-through' : 'text-slate-700'}>{step.label}</span>
                                    )}
                                </li>
                            ))}
                        </ol>
                    </Card>
                </div>
                <Card title="Data status">
                    {websites === null ? (
                        <p className="text-sm text-slate-500">Checking…</p>
                    ) : receivingData ? (
                        <p className="text-sm text-slate-600">Events are arriving. Analytics land in Phase 3.</p>
                    ) : (
                        <p className="text-sm text-slate-600">No tracking data yet. Nothing on this dashboard is estimated or sampled.</p>
                    )}
                </Card>
            </div>
        </>
    );
}
