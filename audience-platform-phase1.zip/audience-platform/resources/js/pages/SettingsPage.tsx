import { useCallback, useEffect, useState, type FormEvent } from 'react';
import { Alert, Button, Card, Field, Input, PageHeader, Select } from '@/components/ui';
import { ApiError, get, post } from '@/lib/api';
import { useSession } from '@/lib/session';
import { roleLabel, type Member, type Paginated, type Role } from '@/lib/types';

export default function SettingsPage() {
    const { active, can, refresh, switchOrganization } = useSession();
    const [members, setMembers] = useState<Member[] | null>(null);
    const [invite, setInvite] = useState<{ email: string; role: Role }>({ email: '', role: 'client_user' });
    const [inviteErrors, setInviteErrors] = useState<Record<string, string[]>>({});
    const [notice, setNotice] = useState<string | null>(null);
    const [clientName, setClientName] = useState('');
    const [clientError, setClientError] = useState<string | null>(null);

    const loadMembers = useCallback(() => {
        if (!active) return;
        get<Paginated<Member>>(`/organizations/${active.id}/members`)
            .then((r) => setMembers(r.data))
            .catch(() => setMembers([]));
    }, [active]);

    useEffect(() => {
        setMembers(null);
        setInvite({ email: '', role: active?.type === 'agency' ? 'agency_admin' : 'client_user' });
        loadMembers();
    }, [active, loadMembers]);

    if (!active) return null;

    const roles: Role[] = active.type === 'agency' ? ['agency_admin'] : ['client_admin', 'client_user'];

    const onInvite = async (e: FormEvent) => {
        e.preventDefault();
        setInviteErrors({});
        setNotice(null);
        try {
            await post(`/organizations/${active.id}/invitations`, invite);
            setNotice(`Invitation sent to ${invite.email}.`);
            setInvite({ ...invite, email: '' });
        } catch (err) {
            if (err instanceof ApiError) setInviteErrors(err.errors);
        }
    };

    const onCreateClient = async (e: FormEvent) => {
        e.preventDefault();
        setClientError(null);
        try {
            const result = await post<{ data: { id: string } }>(`/organizations/${active.id}/clients`, { name: clientName });
            setClientName('');
            await refresh();
            switchOrganization(result.data.id);
        } catch (err) {
            setClientError(err instanceof ApiError ? err.firstError() : 'Could not create the client.');
        }
    };

    return (
        <>
            <PageHeader title="Settings" description={`${active.name} · ${active.type === 'agency' ? 'Agency' : 'Client'} · ${active.timezone}`} />

            <div className="space-y-6">
                {active.type === 'agency' && can('clients.manage') && (
                    <Card title="Clients">
                        <form onSubmit={(e) => void onCreateClient(e)} className="grid gap-4 sm:grid-cols-[1fr_auto] sm:items-end">
                            <Field label="New client name" error={clientError ?? undefined}>
                                <Input required value={clientName} onChange={(e) => setClientName(e.target.value)} />
                            </Field>
                            <Button type="submit">Create client</Button>
                        </form>
                    </Card>
                )}

                <Card title="Team">
                    {members === null ? (
                        <p className="text-sm text-slate-500">Loading…</p>
                    ) : members.length === 0 ? (
                        <p className="text-sm text-slate-500">
                            No direct members.{active.type === 'client' && ' Agency admins can always manage this client.'}
                        </p>
                    ) : (
                        <div className="overflow-x-auto">
                            <table className="min-w-full text-sm">
                                <thead>
                                    <tr className="text-left text-slate-500">
                                        <th className="pb-2 font-medium">Name</th>
                                        <th className="pb-2 font-medium">E-mail</th>
                                        <th className="pb-2 font-medium">Role</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-slate-100">
                                    {members.map((m) => (
                                        <tr key={m.user_id}>
                                            <td className="py-2 font-medium text-slate-900">{m.name}</td>
                                            <td className="py-2 text-slate-600">{m.email}</td>
                                            <td className="py-2 text-slate-600">{roleLabel[m.role]}</td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    )}
                </Card>

                {can('members.manage') && (
                    <Card title="Invite someone">
                        {notice && <div className="mb-4"><Alert tone="blue">{notice}</Alert></div>}
                        <form onSubmit={(e) => void onInvite(e)} className="grid gap-4 sm:grid-cols-[1fr_12rem_auto] sm:items-end">
                            <Field label="E-mail" error={inviteErrors.email?.[0]}>
                                <Input type="email" required value={invite.email} onChange={(e) => setInvite({ ...invite, email: e.target.value })} />
                            </Field>
                            <Field label="Role" error={inviteErrors.role?.[0]}>
                                <Select value={invite.role} onChange={(e) => setInvite({ ...invite, role: e.target.value as Role })}>
                                    {roles.map((r) => (
                                        <option key={r} value={r}>
                                            {roleLabel[r]}
                                        </option>
                                    ))}
                                </Select>
                            </Field>
                            <Button type="submit">Send invite</Button>
                        </form>
                    </Card>
                )}
            </div>
        </>
    );
}
