import { useCallback, useEffect, useState, type FormEvent } from 'react';
import { Alert, Badge, Button, Card, Field, Input, PageHeader } from '@/components/ui';
import { ApiError, get, post } from '@/lib/api';
import { useSession } from '@/lib/session';
import type { Paginated, Website } from '@/lib/types';

function CopyButton({ text }: { text: string }) {
    const [copied, setCopied] = useState(false);
    return (
        <Button
            type="button"
            variant="secondary"
            onClick={() => {
                void navigator.clipboard?.writeText(text).then(() => {
                    setCopied(true);
                    window.setTimeout(() => setCopied(false), 1500);
                });
            }}
        >
            {copied ? 'Copied' : 'Copy snippet'}
        </Button>
    );
}

const statusTone = { pending: 'amber', active: 'green', paused: 'slate' } as const;

export default function TrackingPage() {
    const { active, can } = useSession();
    const [websites, setWebsites] = useState<Website[] | null>(null);
    const [error, setError] = useState<string | null>(null);
    const [form, setForm] = useState({ name: '', primary_domain: '' });
    const [formErrors, setFormErrors] = useState<Record<string, string[]>>({});
    const [busy, setBusy] = useState(false);

    const load = useCallback(() => {
        setError(null);
        get<Paginated<Website>>('/websites')
            .then((r) => setWebsites(r.data))
            .catch((e: unknown) => setError(e instanceof ApiError ? e.message : 'Could not load websites.'));
    }, []);

    useEffect(() => {
        setWebsites(null);
        if (active?.type === 'client') load();
    }, [active?.id, active?.type, load]);

    if (active?.type !== 'client') {
        return (
            <>
                <PageHeader title="Tracking" />
                <Alert tone="blue">Websites belong to client organizations. Select a client in the switcher above.</Alert>
            </>
        );
    }

    const onCreate = async (e: FormEvent) => {
        e.preventDefault();
        setBusy(true);
        setFormErrors({});
        try {
            await post('/websites', form);
            setForm({ name: '', primary_domain: '' });
            load();
        } catch (err) {
            if (err instanceof ApiError) setFormErrors(err.errors);
        } finally {
            setBusy(false);
        }
    };

    return (
        <>
            <PageHeader
                title="Tracking"
                description="Add each website you want to understand, then paste its snippet before the closing </head> tag. The script is consent-aware and loads asynchronously."
            />

            {error && <div className="mb-6"><Alert>{error}</Alert></div>}

            <div className="space-y-6">
                {websites?.map((site) => (
                    <Card
                        key={site.id}
                        title={site.name}
                        actions={<Badge tone={statusTone[site.status]}>{site.status === 'pending' ? 'Waiting for first event' : site.status}</Badge>}
                    >
                        <dl className="mb-4 grid gap-x-6 gap-y-2 text-sm sm:grid-cols-3">
                            <div>
                                <dt className="text-slate-500">Domain</dt>
                                <dd className="font-medium text-slate-900">{site.primary_domain}</dd>
                            </div>
                            <div>
                                <dt className="text-slate-500">Allowed domains</dt>
                                <dd className="text-slate-900">{site.tracking_domains?.map((d) => d.domain).join(', ')}</dd>
                            </div>
                            <div>
                                <dt className="text-slate-500">Last event</dt>
                                <dd className="text-slate-900">{site.last_event_at ? new Date(site.last_event_at).toLocaleString() : 'None yet'}</dd>
                            </div>
                        </dl>
                        <div className="flex flex-wrap items-start gap-3">
                            <pre className="min-w-0 flex-1 overflow-x-auto rounded-md bg-slate-900 px-4 py-3 text-xs text-slate-100">
                                <code>{site.tracking_snippet}</code>
                            </pre>
                            <CopyButton text={site.tracking_snippet} />
                        </div>
                        <p className="mt-3 text-xs text-slate-500">
                            The tracker itself (event collection, consent handling) ships in Phase 2; the snippet and site key are stable from now.
                        </p>
                    </Card>
                ))}

                {websites?.length === 0 && <Alert tone="blue">No websites yet. Add your first one below.</Alert>}

                {can('websites.manage') && (
                    <Card title="Add a website">
                        <form onSubmit={(e) => void onCreate(e)} className="grid gap-4 sm:grid-cols-[1fr_1fr_auto] sm:items-end">
                            <Field label="Name" error={formErrors.name?.[0]}>
                                <Input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Main website" />
                            </Field>
                            <Field label="Domain" error={formErrors.primary_domain?.[0]}>
                                <Input
                                    required
                                    value={form.primary_domain}
                                    onChange={(e) => setForm({ ...form, primary_domain: e.target.value })}
                                    placeholder="example.lk"
                                />
                            </Field>
                            <Button type="submit" disabled={busy}>
                                Add website
                            </Button>
                        </form>
                    </Card>
                )}
            </div>
        </>
    );
}
