<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex, nofollow">
    <title>{{ config('app.name') }}</title>
    @vite(['resources/js/main.tsx'])
</head>
<body class="h-full bg-slate-50 text-slate-900 antialiased">
    <div id="root" class="h-full"></div>
    <noscript>This dashboard requires JavaScript.</noscript>
</body>
</html>
