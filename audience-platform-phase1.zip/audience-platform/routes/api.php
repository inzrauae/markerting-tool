<?php

use App\Http\Controllers\Api\V1\Admin\AdminOrganizationController;
use App\Http\Controllers\Api\V1\Admin\AdminPlanController;
use App\Http\Controllers\Api\V1\ApiKeyController;
use App\Http\Controllers\Api\V1\ApiKeyIntrospectionController;
use App\Http\Controllers\Api\V1\AuditLogController;
use App\Http\Controllers\Api\V1\Auth\RegisterController;
use App\Http\Controllers\Api\V1\Auth\SessionController;
use App\Http\Controllers\Api\V1\Auth\TokenController;
use App\Http\Controllers\Api\V1\InvitationController;
use App\Http\Controllers\Api\V1\MeController;
use App\Http\Controllers\Api\V1\MemberController;
use App\Http\Controllers\Api\V1\OrganizationController;
use App\Http\Controllers\Api\V1\RetentionPolicyController;
use App\Http\Controllers\Api\V1\WebsiteController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API v1   (prefix: /api/v1)
|--------------------------------------------------------------------------
| Auth:    Sanctum (SPA cookie session or personal bearer token) for users,
|          organization API keys (`api_key:<ability>`) for integrations.
| Tenant:  `tenant` resolves the {organization} route parameter or the
|          X-Organization-Id header. `tenant.client` requires a client org.
*/

Route::prefix('v1')->name('api.v1.')->group(function (): void {

    // ---- Public ---------------------------------------------------------
    Route::post('auth/register', RegisterController::class)->middleware('throttle:register')->name('auth.register');
    Route::post('auth/login', [SessionController::class, 'store'])->middleware('throttle:login')->name('auth.login');
    Route::post('auth/tokens', [TokenController::class, 'store'])->middleware('throttle:login')->name('auth.tokens.store');
    Route::post('invitations/accept', [InvitationController::class, 'accept'])->middleware('throttle:sensitive')->name('invitations.accept');

    // ---- Organization API keys (server-to-server) -----------------------
    Route::middleware('api_key')->group(function (): void {
        Route::get('key', ApiKeyIntrospectionController::class)->name('key.show');
        // Phase 2+: POST events (api_key:events:write), POST conversions, ...
    });

    // ---- Authenticated users -------------------------------------------
    Route::middleware('auth:sanctum')->group(function (): void {
        Route::post('auth/logout', [SessionController::class, 'destroy'])->name('auth.logout');
        Route::delete('auth/tokens/current', [TokenController::class, 'destroy'])->name('auth.tokens.destroy');
        Route::get('me', MeController::class)->name('me');
        Route::get('organizations', [OrganizationController::class, 'index'])->name('organizations.index');

        // Organization-level management. The {organization} parameter selects the tenant.
        Route::middleware('tenant')->prefix('organizations/{organization}')->name('organizations.')->group(function (): void {
            Route::get('/', [OrganizationController::class, 'show'])->name('show');
            Route::patch('/', [OrganizationController::class, 'update'])->name('update');
            Route::post('clients', [OrganizationController::class, 'storeClient'])->name('clients.store');

            Route::get('members', [MemberController::class, 'index'])->name('members.index');
            Route::patch('members/{member}', [MemberController::class, 'update'])->name('members.update');
            Route::delete('members/{member}', [MemberController::class, 'destroy'])->name('members.destroy');

            Route::get('invitations', [InvitationController::class, 'index'])->name('invitations.index');
            Route::post('invitations', [InvitationController::class, 'store'])->middleware('throttle:invitations')->name('invitations.store');
            Route::delete('invitations/{invitation}', [InvitationController::class, 'destroy'])->name('invitations.destroy');

            Route::get('audit-logs', [AuditLogController::class, 'index'])->name('audit-logs.index');
        });

        // Client-owned data. Tenant comes from the X-Organization-Id header.
        Route::middleware(['tenant', 'tenant.client'])->group(function (): void {
            Route::get('websites', [WebsiteController::class, 'index'])->name('websites.index');
            Route::post('websites', [WebsiteController::class, 'store'])->name('websites.store');
            Route::get('websites/{website}', [WebsiteController::class, 'show'])->name('websites.show');
            Route::patch('websites/{website}', [WebsiteController::class, 'update'])->name('websites.update');
            Route::delete('websites/{website}', [WebsiteController::class, 'destroy'])->name('websites.destroy');
            Route::post('websites/{website}/rotate-key', [WebsiteController::class, 'rotateKey'])->middleware('throttle:sensitive')->name('websites.rotate-key');

            Route::get('api-keys', [ApiKeyController::class, 'index'])->name('api-keys.index');
            Route::post('api-keys', [ApiKeyController::class, 'store'])->middleware('throttle:sensitive')->name('api-keys.store');
            Route::delete('api-keys/{apiKey}', [ApiKeyController::class, 'destroy'])->name('api-keys.destroy');

            Route::get('data-retention-policy', [RetentionPolicyController::class, 'show'])->name('retention.show');
            Route::put('data-retention-policy', [RetentionPolicyController::class, 'update'])->name('retention.update');
        });

        // Super admin console.
        Route::middleware('super_admin')->prefix('admin')->name('admin.')->group(function (): void {
            Route::get('organizations', [AdminOrganizationController::class, 'index'])->name('organizations.index');
            Route::patch('organizations/{organization}/status', [AdminOrganizationController::class, 'updateStatus'])->name('organizations.status');
            Route::get('plans', [AdminPlanController::class, 'index'])->name('plans.index');
            Route::patch('plans/{plan:code}', [AdminPlanController::class, 'update'])->name('plans.update');
        });
    });
});
