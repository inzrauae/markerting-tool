<?php

/*
|--------------------------------------------------------------------------
| Console routes & schedule
|--------------------------------------------------------------------------
| Commands in app/Console/Commands are auto-discovered.
| Scheduled jobs are added here as later phases land, e.g.:
|   Schedule::command('partitions:maintain')->daily()->onOneServer();      (Phase 2)
|   Schedule::job(new ApplyRetentionPolicies)->dailyAt('02:00')->onOneServer(); (Phase 2)
|   Schedule::job(new DiscoverAudiences)->dailyAt('03:00')->onOneServer();  (Phase 7)
*/

use Illuminate\Support\Facades\Schedule;

Schedule::command('sanctum:prune-expired --hours=24')->daily()->onOneServer();
