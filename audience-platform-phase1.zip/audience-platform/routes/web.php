<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Dashboard SPA
|--------------------------------------------------------------------------
| Every non-API path returns the React shell; client-side routing takes over.
| Excluded prefixes are served by the API, Sanctum, Horizon or the health check.
*/

Route::view('/{path?}', 'app')
    ->where('path', '^(?!api|sanctum|horizon|up|tracker\.js|collect).*$')
    ->name('spa');
