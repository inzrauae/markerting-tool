<?php

declare(strict_types=1);

namespace Tests\Feature\Admin;

use App\Models\Organization;
use App\Models\SubscriptionPlan;
use App\Models\User;
use PHPUnit\Framework\Attributes\Test;
use Tests\TestCase;

class SuperAdminTest extends TestCase
{
    #[Test]
    public function agency_admins_cannot_use_the_admin_console(): void
    {
        [, $admin] = $this->createAgency();

        $this->actingAsUser($admin)->getJson('/api/v1/admin/organizations')->assertForbidden();
        $this->patchJson('/api/v1/admin/plans/starter', ['limits' => ['websites' => 999]])->assertForbidden();
    }

    #[Test]
    public function super_admins_list_every_organization(): void
    {
        $this->createAgency();
        $this->createAgency();
        $super = User::factory()->superAdmin()->create();

        $this->actingAsUser($super)
            ->getJson('/api/v1/admin/organizations')
            ->assertOk()
            ->assertJsonCount(2, 'data');
    }

    #[Test]
    public function suspending_an_agency_blocks_it_and_its_clients_and_is_audited(): void
    {
        [$agency, $admin] = $this->createAgency();
        $client = $this->createClient($agency);
        $super = User::factory()->superAdmin()->create();

        $this->actingAsUser($super)
            ->patchJson("/api/v1/admin/organizations/{$agency->public_id}/status", [
                'status' => 'suspended',
                'reason' => 'Chargeback',
            ])
            ->assertOk();

        $this->assertSame(Organization::STATUS_SUSPENDED, $client->fresh()->status);
        $this->assertDatabaseHas('audit_logs', ['action' => 'admin.organization_status_changed', 'organization_id' => $agency->id]);

        $this->actingAsUser($admin)
            ->withHeaders($this->tenant($client))
            ->getJson('/api/v1/websites')
            ->assertForbidden();
    }

    #[Test]
    public function plan_limits_are_data_editable_by_super_admins(): void
    {
        $super = User::factory()->superAdmin()->create();

        $this->actingAsUser($super)
            ->patchJson('/api/v1/admin/plans/starter', ['limits' => ['websites' => 2, 'not_a_metric' => 5]])
            ->assertOk();

        $limits = SubscriptionPlan::query()->where('code', 'starter')->firstOrFail()->limits;
        $this->assertSame(2, $limits['websites']);
        $this->assertArrayNotHasKey('not_a_metric', $limits);
        $this->assertSame(3, $limits['users'], 'Untouched limits are preserved.');
    }

    #[Test]
    public function super_admin_access_to_a_tenant_is_audited(): void
    {
        [$agency] = $this->createAgency();
        $client = $this->createClient($agency);
        $super = User::factory()->superAdmin()->create();

        $this->actingAsUser($super)
            ->withHeaders($this->tenant($client))
            ->getJson('/api/v1/websites')
            ->assertOk();

        $this->assertDatabaseHas('audit_logs', [
            'action' => 'admin.tenant_accessed',
            'organization_id' => $client->id,
            'actor_id' => $super->id,
        ]);
    }
}
