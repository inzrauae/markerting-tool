<?php

declare(strict_types=1);

namespace Tests\Feature\ApiKeys;

use App\Enums\OrganizationRole;
use App\Models\ApiKey;
use App\Models\Organization;
use App\Models\User;
use PHPUnit\Framework\Attributes\Test;
use Tests\TestCase;

class ApiKeyTest extends TestCase
{
    private Organization $client;

    private User $admin;

    protected function setUp(): void
    {
        parent::setUp();

        [$agency, $this->admin] = $this->createAgency();
        $this->client = $this->createClient($agency);
    }

    #[Test]
    public function the_plaintext_key_is_shown_once_and_only_its_hash_is_stored(): void
    {
        $response = $this->actingAsUser($this->admin)
            ->withHeaders($this->tenant($this->client))
            ->postJson('/api/v1/api-keys', ['name' => 'CRM sync', 'abilities' => ['events:write', 'websites:read']])
            ->assertCreated();

        $plaintext = $response->json('key');
        $this->assertStringStartsWith('aiq_live_', $plaintext);
        $this->assertNull($response->json('data.key_hash'));

        $stored = ApiKey::withoutTenancy()->firstOrFail();
        $this->assertSame(hash('sha256', $plaintext), $stored->key_hash);
        $this->assertDatabaseMissing('api_keys', ['key_hash' => $plaintext]);

        // Listing never includes the secret.
        $listing = $this->getJson('/api/v1/api-keys')->assertOk()->json('data.0');
        $this->assertArrayNotHasKey('key', $listing);
        $this->assertSame($stored->prefix, $listing['prefix']);
    }

    #[Test]
    public function unknown_abilities_and_bad_ip_ranges_are_rejected(): void
    {
        $this->actingAsUser($this->admin)
            ->withHeaders($this->tenant($this->client))
            ->postJson('/api/v1/api-keys', [
                'name' => 'x',
                'abilities' => ['admin:everything'],
                'allowed_ips' => ['999.1.1.1'],
            ])
            ->assertUnprocessable()
            ->assertJsonValidationErrors(['abilities.0', 'allowed_ips.0']);
    }

    #[Test]
    public function a_key_authenticates_until_it_is_revoked(): void
    {
        [$key, $plaintext] = $this->createApiKey($this->client);

        $this->withToken($plaintext)->getJson('/api/v1/key')
            ->assertOk()
            ->assertJsonPath('key.prefix', $key->prefix)
            ->assertJsonPath('organization.id', $this->client->public_id);

        $this->assertNotNull(ApiKey::withoutTenancy()->findOrFail($key->id)->last_used_at);

        $this->actingAsUser($this->admin)
            ->withHeaders($this->tenant($this->client))
            ->deleteJson("/api/v1/api-keys/{$key->public_id}")
            ->assertNoContent();

        $this->withToken($plaintext)->getJson('/api/v1/key')->assertUnauthorized();
    }

    #[Test]
    public function malformed_tampered_and_expired_keys_are_rejected(): void
    {
        [, $plaintext] = $this->createApiKey($this->client);

        $this->withToken('aiq_live_nope')->getJson('/api/v1/key')->assertUnauthorized();
        $tampered = substr($plaintext, 0, -1).(str_ends_with($plaintext, 'X') ? 'Y' : 'X');
        $this->withToken($tampered)->getJson('/api/v1/key')->assertUnauthorized();

        [, $expired] = $this->createApiKey($this->client, attributes: ['expires_at' => now()->subDay()]);
        $this->withToken($expired)->getJson('/api/v1/key')->assertUnauthorized();
    }

    #[Test]
    public function ip_allowlists_are_enforced(): void
    {
        [, $plaintext] = $this->createApiKey($this->client, attributes: ['allowed_ips' => ['203.0.113.0/24']]);

        $this->withToken($plaintext)->getJson('/api/v1/key')->assertForbidden();

        $this->withServerVariables(['REMOTE_ADDR' => '203.0.113.9'])
            ->withToken($plaintext)
            ->getJson('/api/v1/key')
            ->assertOk();
    }

    #[Test]
    public function only_admins_manage_keys(): void
    {
        $user = $this->addMember($this->client, role: OrganizationRole::ClientUser);

        $this->actingAsUser($user)
            ->withHeaders($this->tenant($this->client))
            ->postJson('/api/v1/api-keys', ['name' => 'x', 'abilities' => ['events:write']])
            ->assertForbidden();

        $this->getJson('/api/v1/api-keys')->assertForbidden();
    }
}
