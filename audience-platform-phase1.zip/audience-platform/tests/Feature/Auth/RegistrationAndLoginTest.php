<?php

declare(strict_types=1);

namespace Tests\Feature\Auth;

use App\Enums\OrganizationRole;
use App\Models\Organization;
use App\Models\User;
use PHPUnit\Framework\Attributes\Test;
use Tests\TestCase;

class RegistrationAndLoginTest extends TestCase
{
    private function registerPayload(array $overrides = []): array
    {
        return array_merge([
            'name' => 'Nimal Perera',
            'email' => 'Nimal@Example.com',
            'password' => 'correct-horse-battery',
            'password_confirmation' => 'correct-horse-battery',
            'organization_name' => 'Lanka Builders',
            'account_type' => 'business',
            'timezone' => 'Asia/Colombo',
        ], $overrides);
    }

    #[Test]
    public function a_business_gets_an_agency_and_one_client_with_trial_and_retention_policy(): void
    {
        $response = $this->postJson('/api/v1/auth/register', $this->registerPayload())
            ->assertCreated()
            ->assertJsonPath('user.email', 'nimal@example.com');

        $user = User::query()->where('email', 'nimal@example.com')->firstOrFail();
        $agency = Organization::query()->where('type', 'agency')->firstOrFail();
        $client = Organization::query()->where('type', 'client')->firstOrFail();

        $this->assertSame($agency->id, $client->parent_id);
        $this->assertSame('Asia/Colombo', $client->timezone);
        $response->assertJsonPath('default_organization_id', $client->public_id);

        $this->assertDatabaseHas('organization_users', [
            'organization_id' => $agency->id,
            'user_id' => $user->id,
            'role' => OrganizationRole::AgencyAdmin->value,
        ]);
        $this->assertDatabaseHas('subscriptions', ['organization_id' => $agency->id, 'status' => 'trialing']);
        $this->assertDatabaseHas('data_retention_policies', ['organization_id' => $client->id, 'raw_event_days' => 180]);
        $this->assertDatabaseHas('audit_logs', ['action' => 'organization.registered', 'organization_id' => $agency->id]);
        $this->assertFalse($user->isSuperAdmin());
    }

    #[Test]
    public function an_agency_starts_with_no_clients(): void
    {
        $this->postJson('/api/v1/auth/register', $this->registerPayload(['account_type' => 'agency']))
            ->assertCreated();

        $this->assertSame(1, Organization::query()->count());
        $this->assertSame('agency', Organization::query()->value('type')->value);
    }

    #[Test]
    public function registration_cannot_grant_super_admin(): void
    {
        $this->postJson('/api/v1/auth/register', $this->registerPayload(['is_super_admin' => true]))
            ->assertCreated();

        $this->assertFalse(User::query()->firstOrFail()->isSuperAdmin());
    }

    #[Test]
    public function registration_validates_input(): void
    {
        User::factory()->create(['email' => 'taken@example.com']);

        $this->postJson('/api/v1/auth/register', $this->registerPayload([
            'email' => 'taken@example.com',
            'password_confirmation' => 'different',
            'account_type' => 'reseller',
        ]))->assertUnprocessable()->assertJsonValidationErrors(['email', 'password', 'account_type']);
    }

    #[Test]
    public function a_token_can_be_issued_used_and_revoked(): void
    {
        $user = User::factory()->create(['email' => 'ops@example.com', 'password' => 'secret-pass-123']);

        $token = $this->postJson('/api/v1/auth/tokens', [
            'email' => 'ops@example.com',
            'password' => 'secret-pass-123',
            'device_name' => 'ci',
        ])->assertCreated()->json('token');

        $this->withToken($token)->getJson('/api/v1/me')
            ->assertOk()
            ->assertJsonPath('user.id', $user->public_id);

        $this->withToken($token)->deleteJson('/api/v1/auth/tokens/current')->assertNoContent();
        $this->assertDatabaseCount('personal_access_tokens', 0);
        $this->assertDatabaseHas('audit_logs', ['action' => 'auth.token_revoked']);
    }

    #[Test]
    public function wrong_credentials_are_rejected_and_audited(): void
    {
        User::factory()->create(['email' => 'ops@example.com', 'password' => 'secret-pass-123']);

        $this->postJson('/api/v1/auth/tokens', ['email' => 'ops@example.com', 'password' => 'nope'])
            ->assertUnprocessable()
            ->assertJsonValidationErrors('email');

        $this->assertDatabaseHas('audit_logs', ['action' => 'auth.token_failed']);
    }

    #[Test]
    public function login_is_rate_limited(): void
    {
        User::factory()->create(['email' => 'ops@example.com']);

        foreach (range(1, 5) as $attempt) {
            $this->postJson('/api/v1/auth/tokens', ['email' => 'ops@example.com', 'password' => 'wrong'])
                ->assertUnprocessable();
        }

        $this->postJson('/api/v1/auth/tokens', ['email' => 'ops@example.com', 'password' => 'wrong'])
            ->assertTooManyRequests();
    }

    #[Test]
    public function protected_routes_require_authentication(): void
    {
        $this->getJson('/api/v1/me')->assertUnauthorized();
        $this->getJson('/api/v1/websites')->assertUnauthorized();
        $this->getJson('/api/v1/admin/organizations')->assertUnauthorized();
    }

    #[Test]
    public function me_returns_effective_roles_including_inherited_agency_access(): void
    {
        [$agency, $admin] = $this->createAgency();
        $client = $this->createClient($agency);

        $organizations = collect(
            $this->actingAsUser($admin)->getJson('/api/v1/me')->assertOk()->json('organizations')
        )->keyBy('id');

        $this->assertSame('agency_admin', $organizations[$agency->public_id]['role']);
        $this->assertSame('agency_admin', $organizations[$client->public_id]['role']);
        $this->assertContains('websites.manage', $organizations[$client->public_id]['permissions']);
    }
}
