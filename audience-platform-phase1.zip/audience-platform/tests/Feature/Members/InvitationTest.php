<?php

declare(strict_types=1);

namespace Tests\Feature\Members;

use App\Enums\OrganizationRole;
use App\Models\Organization;
use App\Models\OrganizationInvitation;
use App\Models\User;
use App\Notifications\OrganizationInvitationNotification;
use Illuminate\Notifications\AnonymousNotifiable;
use Illuminate\Support\Facades\Notification;
use PHPUnit\Framework\Attributes\Test;
use Tests\TestCase;

class InvitationTest extends TestCase
{
    private Organization $agency;

    private Organization $client;

    private User $admin;

    protected function setUp(): void
    {
        parent::setUp();

        Notification::fake();

        [$this->agency, $this->admin] = $this->createAgency();
        $this->client = $this->createClient($this->agency);
    }

    /**
     * Invite through the API and capture the raw token from the e-mail.
     */
    private function inviteAndCaptureToken(string $email, string $role = 'client_user', ?Organization $org = null): string
    {
        $org ??= $this->client;

        $this->actingAsUser($this->admin)
            ->postJson("/api/v1/organizations/{$org->public_id}/invitations", ['email' => $email, 'role' => $role])
            ->assertCreated()
            ->assertJsonPath('data.email', strtolower($email));

        $token = null;
        Notification::assertSentOnDemand(
            OrganizationInvitationNotification::class,
            function (OrganizationInvitationNotification $n, array $channels, AnonymousNotifiable $notifiable) use ($email, &$token) {
                if (($notifiable->routes['mail'] ?? null) !== strtolower($email)) {
                    return false;
                }
                $token = $n->token;

                return true;
            },
        );

        $this->assertNotNull($token);

        return $token;
    }

    #[Test]
    public function an_invited_person_creates_an_account_and_joins_with_the_invited_role(): void
    {
        $token = $this->inviteAndCaptureToken('New.Person@example.com');

        // Only the hash is stored.
        $this->assertDatabaseMissing('organization_invitations', ['token_hash' => $token]);

        app('auth')->forgetGuards();

        $this->postJson('/api/v1/invitations/accept', [
            'token' => $token,
            'name' => 'New Person',
            'password' => 'a-long-password',
            'password_confirmation' => 'a-long-password',
        ])->assertCreated()
            ->assertJsonPath('organization.id', $this->client->public_id)
            ->assertJsonPath('organization.role', 'client_user')
            ->assertJsonPath('account_created', true);

        $user = User::query()->where('email', 'new.person@example.com')->firstOrFail();
        $this->assertNotNull($user->email_verified_at);
        $this->assertDatabaseHas('organization_users', [
            'organization_id' => $this->client->id,
            'user_id' => $user->id,
            'role' => 'client_user',
        ]);

        // Single use.
        $this->postJson('/api/v1/invitations/accept', [
            'token' => $token, 'name' => 'Again', 'password' => 'a-long-password', 'password_confirmation' => 'a-long-password',
        ])->assertUnprocessable()->assertJsonValidationErrors('token');
    }

    #[Test]
    public function an_existing_signed_in_user_accepts_with_their_own_account(): void
    {
        $existing = User::factory()->create(['email' => 'consultant@example.com']);
        $token = $this->inviteAndCaptureToken('consultant@example.com', 'client_admin');

        $this->actingAsUser($existing)
            ->postJson('/api/v1/invitations/accept', ['token' => $token])
            ->assertCreated()
            ->assertJsonPath('organization.role', 'client_admin')
            ->assertJsonPath('account_created', false);
    }

    #[Test]
    public function an_invitation_cannot_be_accepted_by_a_different_signed_in_account(): void
    {
        $token = $this->inviteAndCaptureToken('intended@example.com');
        $someoneElse = User::factory()->create(['email' => 'other@example.com']);

        $this->actingAsUser($someoneElse)
            ->postJson('/api/v1/invitations/accept', ['token' => $token])
            ->assertUnprocessable()
            ->assertJsonValidationErrors('token');

        $this->assertDatabaseMissing('organization_users', ['user_id' => $someoneElse->id]);
    }

    #[Test]
    public function expired_and_revoked_invitations_are_rejected(): void
    {
        $token = $this->inviteAndCaptureToken('late@example.com');
        OrganizationInvitation::withoutTenancy()->update(['expires_at' => now()->subMinute()]);

        app('auth')->forgetGuards();

        $this->postJson('/api/v1/invitations/accept', [
            'token' => $token, 'name' => 'Late', 'password' => 'a-long-password', 'password_confirmation' => 'a-long-password',
        ])->assertUnprocessable();

        $token2 = $this->inviteAndCaptureToken('revoked@example.com');
        $invitation = OrganizationInvitation::withoutTenancy()->where('email', 'revoked@example.com')->firstOrFail();

        $this->actingAsUser($this->admin)
            ->deleteJson("/api/v1/organizations/{$this->client->public_id}/invitations/{$invitation->public_id}")
            ->assertNoContent();

        app('auth')->forgetGuards();

        $this->postJson('/api/v1/invitations/accept', [
            'token' => $token2, 'name' => 'Nope', 'password' => 'a-long-password', 'password_confirmation' => 'a-long-password',
        ])->assertUnprocessable();
    }

    #[Test]
    public function roles_must_fit_the_organization_type_and_the_inviters_rank(): void
    {
        // agency_admin is not a client role.
        $this->actingAsUser($this->admin)
            ->postJson("/api/v1/organizations/{$this->client->public_id}/invitations", ['email' => 'a@example.com', 'role' => 'agency_admin'])
            ->assertUnprocessable()->assertJsonValidationErrors('role');

        // A client user cannot invite anyone.
        $clientUser = $this->addMember($this->client, role: OrganizationRole::ClientUser);
        $this->actingAsUser($clientUser)
            ->postJson("/api/v1/organizations/{$this->client->public_id}/invitations", ['email' => 'b@example.com', 'role' => 'client_user'])
            ->assertForbidden();
    }

    #[Test]
    public function members_can_be_listed_promoted_and_removed(): void
    {
        $member = $this->addMember($this->client, role: OrganizationRole::ClientUser);

        $this->actingAsUser($this->admin);

        $this->getJson("/api/v1/organizations/{$this->client->public_id}/members")
            ->assertOk()
            ->assertJsonPath('data.0.email', $member->email);

        $this->patchJson("/api/v1/organizations/{$this->client->public_id}/members/{$member->public_id}", ['role' => 'client_admin'])
            ->assertOk()
            ->assertJsonPath('data.role', 'client_admin');

        $this->deleteJson("/api/v1/organizations/{$this->client->public_id}/members/{$member->public_id}")
            ->assertNoContent();

        $this->assertDatabaseMissing('organization_users', ['organization_id' => $this->client->id, 'user_id' => $member->id]);
        $this->assertDatabaseHas('audit_logs', ['action' => 'member.removed']);
    }

    #[Test]
    public function the_last_agency_admin_cannot_be_removed(): void
    {
        $this->actingAsUser($this->admin)
            ->deleteJson("/api/v1/organizations/{$this->agency->public_id}/members/{$this->admin->public_id}")
            ->assertUnprocessable();

        $this->assertDatabaseHas('organization_users', ['organization_id' => $this->agency->id, 'user_id' => $this->admin->id]);
    }

    #[Test]
    public function the_plan_user_limit_blocks_new_invitations(): void
    {
        [$agency, $admin] = $this->createAgency(plan: 'starter'); // starter: 3 users
        $client = $this->createClient($agency);
        $this->addMember($client);
        $this->addMember($client);

        $this->actingAsUser($admin)
            ->postJson("/api/v1/organizations/{$client->public_id}/invitations", ['email' => 'fourth@example.com', 'role' => 'client_user'])
            ->assertUnprocessable()
            ->assertJsonValidationErrors('email');
    }
}
