<?php

declare(strict_types=1);

namespace Tests\Feature\Organizations;

use App\Enums\OrganizationRole;
use App\Models\Organization;
use PHPUnit\Framework\Attributes\Test;
use Tests\TestCase;

class OrganizationManagementTest extends TestCase
{
    #[Test]
    public function an_agency_admin_creates_clients_with_a_retention_policy(): void
    {
        [$agency, $admin] = $this->createAgency();

        $response = $this->actingAsUser($admin)
            ->postJson("/api/v1/organizations/{$agency->public_id}/clients", [
                'name' => 'Ceylon Interiors',
                'timezone' => 'Asia/Colombo',
                'special_ad_category' => 'housing',
            ])
            ->assertCreated()
            ->assertJsonPath('data.type', 'client')
            ->assertJsonPath('data.parent_id', $agency->public_id)
            ->assertJsonPath('data.special_ad_category', 'housing')
            ->assertJsonPath('data.role', 'agency_admin');

        $client = Organization::query()->where('public_id', $response->json('data.id'))->firstOrFail();
        $this->assertDatabaseHas('data_retention_policies', ['organization_id' => $client->id]);
    }

    #[Test]
    public function clients_cannot_create_sub_clients_and_client_admins_cannot_create_clients(): void
    {
        [$agency] = $this->createAgency();
        $client = $this->createClient($agency);
        $clientAdmin = $this->addMember($client, role: OrganizationRole::ClientAdmin);

        $this->actingAsUser($clientAdmin)
            ->postJson("/api/v1/organizations/{$client->public_id}/clients", ['name' => 'Nested'])
            ->assertForbidden();

        $this->assertDatabaseMissing('organizations', ['name' => 'Nested']);
    }

    #[Test]
    public function the_plan_client_limit_is_enforced(): void
    {
        [$agency, $admin] = $this->createAgency(plan: 'starter'); // starter: 1 client
        $this->createClient($agency);

        $this->actingAsUser($admin)
            ->postJson("/api/v1/organizations/{$agency->public_id}/clients", ['name' => 'Second'])
            ->assertUnprocessable()
            ->assertJsonValidationErrors('name');
    }

    #[Test]
    public function client_users_cannot_edit_the_organization(): void
    {
        [$agency] = $this->createAgency();
        $client = $this->createClient($agency);
        $user = $this->addMember($client, role: OrganizationRole::ClientUser);

        $this->actingAsUser($user);

        $this->getJson("/api/v1/organizations/{$client->public_id}")->assertOk()->assertJsonPath('data.role', 'client_user');
        $this->patchJson("/api/v1/organizations/{$client->public_id}", ['name' => 'Renamed'])->assertForbidden();
        $this->getJson("/api/v1/organizations/{$client->public_id}/audit-logs")->assertForbidden();
    }

    #[Test]
    public function an_agency_audit_log_includes_its_clients_but_a_client_log_does_not_include_siblings(): void
    {
        [$agency, $admin] = $this->createAgency();
        $clientA = $this->createClient($agency, ['name' => 'Client A']);
        $clientB = $this->createClient($agency, ['name' => 'Client B']);

        $this->actingAsUser($admin)
            ->patchJson("/api/v1/organizations/{$clientA->public_id}", ['name' => 'Client A renamed'])
            ->assertOk();

        $agencyActions = collect($this->getJson("/api/v1/organizations/{$agency->public_id}/audit-logs")->assertOk()->json('data'))->pluck('action');
        $this->assertContains('organization.updated', $agencyActions);

        $clientBActions = collect($this->getJson("/api/v1/organizations/{$clientB->public_id}/audit-logs")->assertOk()->json('data'))->pluck('action');
        $this->assertNotContains('organization.updated', $clientBActions);
    }

    #[Test]
    public function retention_policy_can_be_set_to_a_preset_or_custom_value(): void
    {
        [$agency, $admin] = $this->createAgency();
        $client = $this->createClient($agency);

        $this->actingAsUser($admin)->withHeaders($this->tenant($client));

        $this->getJson('/api/v1/data-retention-policy')
            ->assertOk()
            ->assertJsonPath('data.raw_event_days', 180)
            ->assertJsonPath('data.choices', [30, 90, 180, 365]);

        $this->putJson('/api/v1/data-retention-policy', [
            'raw_event_days' => 45,
            'visitor_profile_days' => 90,
            'aggregate_days' => null,
            'anonymize_instead_of_delete' => true,
        ])->assertOk()->assertJsonPath('data.raw_event_days', 45);

        $this->putJson('/api/v1/data-retention-policy', [
            'raw_event_days' => 0,
            'visitor_profile_days' => 5000,
            'aggregate_days' => null,
            'anonymize_instead_of_delete' => false,
        ])->assertUnprocessable()->assertJsonValidationErrors(['raw_event_days', 'visitor_profile_days']);

        $this->assertDatabaseHas('audit_logs', ['action' => 'retention_policy.updated']);
    }
}
