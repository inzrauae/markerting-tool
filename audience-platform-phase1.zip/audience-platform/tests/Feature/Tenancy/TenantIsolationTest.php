<?php

declare(strict_types=1);

namespace Tests\Feature\Tenancy;

use App\Enums\OrganizationRole;
use App\Exceptions\TenantException;
use App\Models\ApiKey;
use App\Models\Organization;
use App\Models\User;
use App\Models\Website;
use App\Support\Tenancy\TenantContext;
use PHPUnit\Framework\Attributes\DataProvider;
use PHPUnit\Framework\Attributes\Test;
use Tests\TestCase;

/**
 * "Organization A can NEVER access organization B data."
 *
 * Two independent agencies, each with a client, website, API key and
 * pending invitation. Every tenant route is attacked from the other side.
 */
class TenantIsolationTest extends TestCase
{
    private Organization $agencyA;

    private Organization $clientA;

    private User $adminA;

    private Website $websiteA;

    private Organization $agencyB;

    private Organization $clientB;

    private User $adminB;

    private Website $websiteB;

    private ApiKey $keyB;

    private string $keyBPlaintext;

    protected function setUp(): void
    {
        parent::setUp();

        [$this->agencyA, $this->adminA] = $this->createAgency();
        $this->clientA = $this->createClient($this->agencyA);
        $this->websiteA = $this->createWebsite($this->clientA);

        [$this->agencyB, $this->adminB] = $this->createAgency();
        $this->clientB = $this->createClient($this->agencyB);
        $this->websiteB = $this->createWebsite($this->clientB);
        [$this->keyB, $this->keyBPlaintext] = $this->createApiKey($this->clientB);
    }

    #[Test]
    public function organization_listing_never_includes_another_agencys_organizations(): void
    {
        $ids = $this->actingAsUser($this->adminA)
            ->getJson('/api/v1/organizations')
            ->assertOk()
            ->json('data.*.id');

        $this->assertEqualsCanonicalizing([$this->agencyA->public_id, $this->clientA->public_id], $ids);

        $meIds = $this->getJson('/api/v1/me')->assertOk()->json('organizations.*.id');
        $this->assertNotContains($this->clientB->public_id, $meIds);
        $this->assertNotContains($this->agencyB->public_id, $meIds);
    }

    /**
     * @return array<string, array{0: string, 1: string}>
     */
    public static function foreignOrganizationRoutes(): array
    {
        return [
            'show' => ['GET', '/api/v1/organizations/{org}'],
            'update' => ['PATCH', '/api/v1/organizations/{org}'],
            'create client' => ['POST', '/api/v1/organizations/{agency}/clients'],
            'members' => ['GET', '/api/v1/organizations/{org}/members'],
            'invite' => ['POST', '/api/v1/organizations/{org}/invitations'],
            'invitations' => ['GET', '/api/v1/organizations/{org}/invitations'],
            'audit log' => ['GET', '/api/v1/organizations/{org}/audit-logs'],
        ];
    }

    #[Test]
    #[DataProvider('foreignOrganizationRoutes')]
    public function a_user_cannot_reach_another_tenants_organization_routes(string $method, string $uri): void
    {
        $uri = str_replace(['{org}', '{agency}'], [$this->clientB->public_id, $this->agencyB->public_id], $uri);

        $this->actingAsUser($this->adminA)
            ->json($method, $uri, ['name' => 'Hijacked', 'email' => 'x@example.com', 'role' => 'client_user'])
            ->assertForbidden();

        $this->assertDatabaseMissing('organizations', ['name' => 'Hijacked']);
        $this->assertDatabaseMissing('organization_invitations', ['email' => 'x@example.com']);
    }

    #[Test]
    public function selecting_a_foreign_tenant_by_header_is_refused(): void
    {
        $this->actingAsUser($this->adminA)
            ->withHeaders($this->tenant($this->clientB))
            ->getJson('/api/v1/websites')
            ->assertForbidden();

        $this->withHeaders(['X-Organization-Id' => 'does-not-exist'])
            ->getJson('/api/v1/websites')
            ->assertForbidden();
    }

    #[Test]
    public function a_missing_tenant_header_is_a_client_error_not_an_empty_list(): void
    {
        $this->actingAsUser($this->adminA)
            ->getJson('/api/v1/websites')
            ->assertStatus(400);
    }

    /**
     * @return array<string, array{0: string, 1: string}>
     */
    public static function foreignResourceRoutes(): array
    {
        return [
            'show website' => ['GET', '/api/v1/websites/{website}'],
            'update website' => ['PATCH', '/api/v1/websites/{website}'],
            'delete website' => ['DELETE', '/api/v1/websites/{website}'],
            'rotate site key' => ['POST', '/api/v1/websites/{website}/rotate-key'],
            'revoke api key' => ['DELETE', '/api/v1/api-keys/{key}'],
        ];
    }

    #[Test]
    #[DataProvider('foreignResourceRoutes')]
    public function foreign_resource_ids_are_not_found_inside_the_users_own_tenant(string $method, string $uri): void
    {
        $uri = str_replace(['{website}', '{key}'], [$this->websiteB->public_id, $this->keyB->public_id], $uri);

        $this->actingAsUser($this->adminA)
            ->withHeaders($this->tenant($this->clientA))
            ->json($method, $uri, ['name' => 'Hijacked'])
            ->assertNotFound();

        // Organization B's data is untouched.
        $this->assertDatabaseHas('websites', [
            'id' => $this->websiteB->id,
            'name' => $this->websiteB->name,
            'site_key' => $this->websiteB->site_key,
            'deleted_at' => null,
        ]);
        $this->assertDatabaseHas('api_keys', ['id' => $this->keyB->id, 'revoked_at' => null]);
    }

    #[Test]
    public function listings_only_return_the_active_tenants_rows(): void
    {
        $ids = $this->actingAsUser($this->adminA)
            ->withHeaders($this->tenant($this->clientA))
            ->getJson('/api/v1/websites')
            ->assertOk()
            ->json('data.*.id');

        $this->assertSame([$this->websiteA->public_id], $ids);
    }

    #[Test]
    public function a_client_user_cannot_reach_a_sibling_client_or_the_parent_agency(): void
    {
        $siblingClient = $this->createClient($this->agencyA);
        $clientUser = $this->addMember($this->clientA, role: OrganizationRole::ClientUser);

        $this->actingAsUser($clientUser);

        $this->withHeaders($this->tenant($siblingClient))->getJson('/api/v1/websites')->assertForbidden();
        $this->getJson("/api/v1/organizations/{$this->agencyA->public_id}")->assertForbidden();
        $this->withHeaders($this->tenant($this->clientA))->getJson('/api/v1/websites')->assertOk();
    }

    #[Test]
    public function an_agency_admin_reaches_every_client_of_their_agency(): void
    {
        $second = $this->createClient($this->agencyA);
        $secondSite = $this->createWebsite($second);

        $this->actingAsUser($this->adminA)
            ->withHeaders($this->tenant($second))
            ->getJson("/api/v1/websites/{$secondSite->public_id}")
            ->assertOk()
            ->assertJsonPath('data.id', $secondSite->public_id);
    }

    #[Test]
    public function an_api_key_is_pinned_to_its_own_organization_regardless_of_headers(): void
    {
        $this->withHeaders(['Authorization' => 'Bearer '.$this->keyBPlaintext] + $this->tenant($this->clientA))
            ->getJson('/api/v1/key')
            ->assertOk()
            ->assertJsonPath('organization.id', $this->clientB->public_id);
    }

    #[Test]
    public function the_tenant_scope_fails_closed_without_a_tenant(): void
    {
        $context = app(TenantContext::class);
        $context->clear();

        $this->assertSame(0, Website::query()->count());
        $this->assertSame(2, Website::withoutTenancy()->count());

        $context->runAs($this->clientA, function (): void {
            $this->assertSame([$this->websiteA->id], Website::query()->pluck('id')->all());
            $this->assertNull(Website::query()->find($this->websiteB->id));
        });
    }

    #[Test]
    public function writing_a_row_into_another_tenant_is_refused(): void
    {
        $this->expectException(TenantException::class);

        app(TenantContext::class)->runAs($this->clientA, function (): void {
            Website::factory()->create(['organization_id' => $this->clientB->id]);
        });
    }

    #[Test]
    public function moving_an_existing_row_to_another_tenant_is_refused(): void
    {
        $this->expectException(TenantException::class);

        app(TenantContext::class)->runAs($this->clientA, function (): void {
            $website = Website::query()->findOrFail($this->websiteA->id);
            $website->organization_id = $this->clientB->id;
            $website->save();
        });
    }

    #[Test]
    public function a_suspended_organization_is_unreachable_for_its_own_members(): void
    {
        $this->clientA->update(['status' => Organization::STATUS_SUSPENDED]);

        $this->actingAsUser($this->adminA)
            ->withHeaders($this->tenant($this->clientA))
            ->getJson('/api/v1/websites')
            ->assertForbidden();
    }
}
