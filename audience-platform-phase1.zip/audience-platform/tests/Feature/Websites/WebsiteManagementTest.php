<?php

declare(strict_types=1);

namespace Tests\Feature\Websites;

use App\Enums\OrganizationRole;
use App\Models\Organization;
use App\Models\User;
use App\Models\Website;
use PHPUnit\Framework\Attributes\Test;
use Tests\TestCase;

class WebsiteManagementTest extends TestCase
{
    private Organization $agency;

    private Organization $client;

    private User $admin;

    protected function setUp(): void
    {
        parent::setUp();

        [$this->agency, $this->admin] = $this->createAgency();
        $this->client = $this->createClient($this->agency);
    }

    #[Test]
    public function an_admin_creates_a_website_with_normalised_domains_and_a_snippet(): void
    {
        $response = $this->actingAsUser($this->admin)
            ->withHeaders($this->tenant($this->client))
            ->postJson('/api/v1/websites', [
                'name' => 'Main site',
                'primary_domain' => 'https://WWW.LankaBuilders.lk/pricing',
                'additional_domains' => ['shop.lankabuilders.lk', 'http://blog.lankabuilders.lk/'],
            ])
            ->assertCreated()
            ->assertJsonPath('data.primary_domain', 'www.lankabuilders.lk')
            ->assertJsonPath('data.status', 'pending');

        $siteKey = $response->json('data.site_key');
        $this->assertMatchesRegularExpression('/^[a-z0-9]{32}$/', $siteKey);
        $this->assertStringContainsString('data-site="'.$siteKey.'"', $response->json('data.tracking_snippet'));
        $this->assertEqualsCanonicalizing(
            ['www.lankabuilders.lk', 'shop.lankabuilders.lk', 'blog.lankabuilders.lk'],
            array_column($response->json('data.tracking_domains'), 'domain'),
        );

        $website = Website::withoutTenancy()->where('public_id', $response->json('data.id'))->firstOrFail();
        $this->assertSame($this->client->id, $website->organization_id);
        $this->assertDatabaseHas('audit_logs', ['action' => 'website.created', 'subject_id' => $website->id]);
    }

    #[Test]
    public function invalid_and_duplicate_domains_are_rejected(): void
    {
        $this->createWebsite($this->client, ['primary_domain' => 'taken.example']);

        $this->actingAsUser($this->admin)->withHeaders($this->tenant($this->client));

        $this->postJson('/api/v1/websites', ['name' => 'x', 'primary_domain' => 'not a domain'])
            ->assertUnprocessable()->assertJsonValidationErrors('primary_domain');

        $this->postJson('/api/v1/websites', ['name' => 'x', 'primary_domain' => 'https://taken.example/'])
            ->assertUnprocessable()->assertJsonValidationErrors('primary_domain');

        $this->postJson('/api/v1/websites', ['name' => 'x', 'primary_domain' => 'ok.example', 'additional_domains' => ['???']])
            ->assertUnprocessable()->assertJsonValidationErrors('additional_domains.0');
    }

    #[Test]
    public function the_same_domain_may_be_tracked_by_different_clients(): void
    {
        $other = $this->createClient($this->agency);
        $this->createWebsite($other, ['primary_domain' => 'shared.example']);

        $this->actingAsUser($this->admin)
            ->withHeaders($this->tenant($this->client))
            ->postJson('/api/v1/websites', ['name' => 'x', 'primary_domain' => 'shared.example'])
            ->assertCreated();
    }

    #[Test]
    public function websites_belong_to_clients_not_agencies(): void
    {
        $this->actingAsUser($this->admin)
            ->withHeaders($this->tenant($this->agency))
            ->postJson('/api/v1/websites', ['name' => 'x', 'primary_domain' => 'agency.example'])
            ->assertStatus(422);
    }

    #[Test]
    public function a_client_user_can_read_but_not_change_websites(): void
    {
        $website = $this->createWebsite($this->client);
        $user = $this->addMember($this->client, role: OrganizationRole::ClientUser);

        $this->actingAsUser($user)->withHeaders($this->tenant($this->client));

        $this->getJson('/api/v1/websites')->assertOk()->assertJsonCount(1, 'data');
        $this->getJson("/api/v1/websites/{$website->public_id}")->assertOk();
        $this->postJson('/api/v1/websites', ['name' => 'x', 'primary_domain' => 'new.example'])->assertForbidden();
        $this->patchJson("/api/v1/websites/{$website->public_id}", ['name' => 'Renamed'])->assertForbidden();
        $this->deleteJson("/api/v1/websites/{$website->public_id}")->assertForbidden();
        $this->postJson("/api/v1/websites/{$website->public_id}/rotate-key")->assertForbidden();
    }

    #[Test]
    public function a_client_admin_manages_websites(): void
    {
        $website = $this->createWebsite($this->client);
        $clientAdmin = $this->addMember($this->client, role: OrganizationRole::ClientAdmin);

        $this->actingAsUser($clientAdmin)->withHeaders($this->tenant($this->client));

        $this->patchJson("/api/v1/websites/{$website->public_id}", [
            'name' => 'Renamed',
            'status' => 'paused',
            'additional_domains' => ['cdn.example.org'],
        ])->assertOk()->assertJsonPath('data.name', 'Renamed')->assertJsonPath('data.status', 'paused');

        $this->assertEqualsCanonicalizing(
            [$website->primary_domain, 'cdn.example.org'],
            Website::withoutTenancy()->findOrFail($website->id)->trackingDomains()->withoutGlobalScopes()->pluck('domain')->all(),
        );

        $this->patchJson("/api/v1/websites/{$website->public_id}", ['status' => 'pending'])
            ->assertUnprocessable();

        $this->deleteJson("/api/v1/websites/{$website->public_id}")->assertNoContent();
        $this->assertSoftDeleted('websites', ['id' => $website->id]);
        $this->getJson("/api/v1/websites/{$website->public_id}")->assertNotFound();
    }

    #[Test]
    public function rotating_the_site_key_invalidates_the_old_one(): void
    {
        $website = $this->createWebsite($this->client);
        $old = $website->site_key;

        $new = $this->actingAsUser($this->admin)
            ->withHeaders($this->tenant($this->client))
            ->postJson("/api/v1/websites/{$website->public_id}/rotate-key")
            ->assertOk()
            ->json('data.site_key');

        $this->assertNotSame($old, $new);
        $this->assertDatabaseMissing('websites', ['site_key' => $old]);
        $this->assertDatabaseHas('audit_logs', ['action' => 'website.site_key_rotated']);
    }

    #[Test]
    public function the_plan_website_limit_is_enforced_across_the_whole_agency(): void
    {
        [$agency, $admin] = $this->createAgency(plan: 'starter'); // starter: 1 website
        $client = $this->createClient($agency);
        $this->createWebsite($client);

        $this->actingAsUser($admin)
            ->withHeaders($this->tenant($client))
            ->postJson('/api/v1/websites', ['name' => 'Second', 'primary_domain' => 'second.example'])
            ->assertUnprocessable()
            ->assertJsonValidationErrors('primary_domain');
    }
}
