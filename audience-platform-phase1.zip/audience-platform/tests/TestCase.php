<?php

declare(strict_types=1);

namespace Tests;

use App\Enums\OrganizationRole;
use App\Models\ApiKey;
use App\Models\Organization;
use App\Models\OrganizationMembership;
use App\Models\SubscriptionPlan;
use App\Models\User;
use App\Models\Website;
use App\Services\Tenancy\OrganizationProvisioner;
use App\Support\Tenancy\TenantContext;
use Database\Seeders\SubscriptionPlanSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\TestCase as BaseTestCase;
use Laravel\Sanctum\Sanctum;

abstract class TestCase extends BaseTestCase
{
    use RefreshDatabase;

    /** Seed the subscription plans for every test. */
    protected bool $seed = true;

    protected string $seeder = SubscriptionPlanSeeder::class;

    /**
     * An agency with its admin user. Defaults to the generous "agency" plan
     * so limits don't interfere unless a test asks for a smaller plan.
     *
     * @return array{0: Organization, 1: User}
     */
    protected function createAgency(string $plan = 'agency', ?User $admin = null): array
    {
        $admin ??= User::factory()->create();

        ['agency' => $agency] = app(OrganizationProvisioner::class)
            ->registerAccount($admin, fake()->unique()->company(), true);

        $agency->subscriptions()->update([
            'subscription_plan_id' => SubscriptionPlan::query()->where('code', $plan)->value('id'),
        ]);

        return [$agency->fresh(), $admin];
    }

    protected function createClient(Organization $agency, array $attributes = []): Organization
    {
        return app(OrganizationProvisioner::class)
            ->createClient($agency, $attributes['name'] ?? fake()->unique()->company(), $attributes);
    }

    protected function addMember(Organization $organization, ?User $user = null, OrganizationRole $role = OrganizationRole::ClientUser): User
    {
        $user ??= User::factory()->create();

        OrganizationMembership::query()->create([
            'organization_id' => $organization->getKey(),
            'user_id' => $user->getKey(),
            'role' => $role,
        ]);

        return $user;
    }

    protected function createWebsite(Organization $client, array $attributes = []): Website
    {
        return app(TenantContext::class)->runAs(
            $client,
            fn () => Website::factory()->create($attributes),
        );
    }

    /**
     * @return array{0: ApiKey, 1: string}
     */
    protected function createApiKey(Organization $organization, array $abilities = ['websites:read'], array $attributes = []): array
    {
        return app(TenantContext::class)->runAs($organization, function () use ($abilities, $attributes) {
            [$key, $plaintext] = ApiKey::generate(['name' => 'Test key', 'abilities' => $abilities] + $attributes);
            $key->save();

            return [$key, $plaintext];
        });
    }

    protected function actingAsUser(User $user): static
    {
        Sanctum::actingAs($user, ['*']);

        return $this;
    }

    /**
     * @return array<string, string>
     */
    protected function tenant(Organization $organization): array
    {
        return [(string) config('audience.tenancy.header') => $organization->public_id];
    }
}
