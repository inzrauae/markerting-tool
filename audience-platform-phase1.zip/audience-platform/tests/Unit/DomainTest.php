<?php

declare(strict_types=1);

namespace Tests\Unit;

use App\Rules\IpOrCidr;
use App\Support\Domain;
use PHPUnit\Framework\Attributes\DataProvider;
use PHPUnit\Framework\Attributes\Test;
use PHPUnit\Framework\TestCase;

class DomainTest extends TestCase
{
    /**
     * @return array<string, array{0: string, 1: string|null}>
     */
    public static function domains(): array
    {
        return [
            'bare' => ['example.com', 'example.com'],
            'scheme and path' => ['https://Example.com/pricing?x=1', 'example.com'],
            'www kept' => ['WWW.example.lk', 'www.example.lk'],
            'port stripped' => ['http://shop.example.com:8080', 'shop.example.com'],
            'trailing dot' => ['example.com.', 'example.com'],
            'localhost' => ['localhost', 'localhost'],
            'empty' => ['', null],
            'no tld' => ['intranet', null],
            'ip literal' => ['192.168.1.10', null],
            'garbage' => ['not a domain!', null],
        ];
    }

    #[Test]
    #[DataProvider('domains')]
    public function it_normalizes_user_entered_domains(string $input, ?string $expected): void
    {
        $this->assertSame($expected, Domain::normalize($input));
    }

    #[Test]
    public function it_validates_ip_and_cidr_values(): void
    {
        $this->assertTrue(IpOrCidr::isValid('203.0.113.7'));
        $this->assertTrue(IpOrCidr::isValid('203.0.113.0/24'));
        $this->assertTrue(IpOrCidr::isValid('2001:db8::/32'));
        $this->assertFalse(IpOrCidr::isValid('203.0.113.0/33'));
        $this->assertFalse(IpOrCidr::isValid('example.com'));
        $this->assertFalse(IpOrCidr::isValid('10.0.0.0/abc'));
    }
}
