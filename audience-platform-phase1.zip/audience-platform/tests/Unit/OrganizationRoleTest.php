<?php

declare(strict_types=1);

namespace Tests\Unit;

use App\Enums\OrganizationRole;
use App\Enums\OrganizationType;
use App\Enums\Permission;
use PHPUnit\Framework\Attributes\Test;
use PHPUnit\Framework\TestCase;

class OrganizationRoleTest extends TestCase
{
    #[Test]
    public function agency_admin_has_every_permission(): void
    {
        foreach (Permission::cases() as $permission) {
            $this->assertTrue(OrganizationRole::AgencyAdmin->can($permission), $permission->value);
        }
    }

    #[Test]
    public function client_admin_cannot_manage_clients_or_billing(): void
    {
        $this->assertFalse(OrganizationRole::ClientAdmin->can(Permission::ClientsManage));
        $this->assertFalse(OrganizationRole::ClientAdmin->can(Permission::BillingManage));
        $this->assertTrue(OrganizationRole::ClientAdmin->can(Permission::WebsitesManage));
        $this->assertTrue(OrganizationRole::ClientAdmin->can(Permission::MembersManage));
        $this->assertTrue(OrganizationRole::ClientAdmin->can(Permission::ApiKeysManage));
    }

    #[Test]
    public function client_user_is_read_only(): void
    {
        $writes = [
            Permission::OrganizationUpdate, Permission::MembersManage, Permission::ClientsManage,
            Permission::WebsitesManage, Permission::ApiKeysManage, Permission::RetentionManage,
            Permission::BillingManage, Permission::IntegrationsManage, Permission::AudiencesManage,
            Permission::AudiencesActivate, Permission::ReportsManage, Permission::AuditView,
        ];

        foreach ($writes as $permission) {
            $this->assertFalse(OrganizationRole::ClientUser->can($permission), $permission->value);
        }

        $this->assertTrue(OrganizationRole::ClientUser->can(Permission::WebsitesView));
    }

    #[Test]
    public function roles_are_only_assignable_to_matching_organization_types(): void
    {
        $this->assertSame([OrganizationRole::AgencyAdmin], OrganizationRole::assignableTo(OrganizationType::Agency));
        $this->assertSame(
            [OrganizationRole::ClientAdmin, OrganizationRole::ClientUser],
            OrganizationRole::assignableTo(OrganizationType::Client),
        );
    }

    #[Test]
    public function nobody_can_grant_a_role_above_their_own(): void
    {
        $this->assertTrue(OrganizationRole::AgencyAdmin->canGrant(OrganizationRole::ClientAdmin));
        $this->assertTrue(OrganizationRole::ClientAdmin->canGrant(OrganizationRole::ClientAdmin));
        $this->assertTrue(OrganizationRole::ClientAdmin->canGrant(OrganizationRole::ClientUser));
        $this->assertFalse(OrganizationRole::ClientAdmin->canGrant(OrganizationRole::AgencyAdmin));
        $this->assertFalse(OrganizationRole::ClientUser->canGrant(OrganizationRole::ClientAdmin));
    }
}
